using System.Reflection;
using EMF.Core.Contracts;
using EMF.Core.Models;
using EMF.Core.Models.Identities;
using EMF.Extensions.VeteransClaims.Contracts;
using EMF.Extensions.VeteransClaims.Models.Adjudication;
using EMF.Extensions.VeteransClaims.Models;
using EMF.Extensions.VeteransClaims.Models.Identities;
using EMF.Extensions.VeteransClaims.Orchestration;
using EMF.Tests.TestInfrastructure;

namespace EMF.Tests;

public sealed partial class VeteransReviewerPackageDetailsServiceTests
{
    internal static async Task<VeteransReviewerPackageDetails> AssembleNativeSourcePackageAsync(
        Artifact child, IEvidenceRepository evidence, IArtifactPrintRenderer printer, string extractedText)
    {
        var packageId = new EvidencePackageId("native-source-integration");
        var service = new VeteransReviewerPackageDetailsService(
            new RecordingPackageService { Details = CreateDetails(packageId, child.Id) }, evidence,
            new RecordingClassificationRepository
            {
                ExistingClassifications = [new EvidenceClassification
                {
                    Id = new("native-source-classification"), ArtifactId = child.Id,
                    ClaimIssueId = new("issue-1"), Classification = EvidenceClassifications.MedicalEvidence
                }]
            },
            new RecordingTextExtractor(extractedText), printer);
        return (await service.GetAsync(packageId))!;
    }

    [Theory]
    [InlineData("3", true)]
    [InlineData("2,4", true)]
    [InlineData("1", false)]
    public async Task GetAsync_SelectsNativeParentPagesWithoutChangingEvidenceIdentity(string selection, bool valid)
    {
        var packageId = new EvidencePackageId("native-source-package");
        var child = new Artifact
        {
            Id = new("derived-note"), Name = "derived-note.txt", ArtifactType = "derived-text",
            Metadata = new Dictionary<string, object>
            {
                [ArtifactMetadataKeys.FileExtension] = ".txt",
                [VeteransArtifactMetadataKeys.SourceStartPage] = "2",
                [VeteransArtifactMetadataKeys.SourceEndPage] = "4"
            }
        };
        var parent = new Artifact { Id = new("native-parent"), Name = "native-parent.pdf", ArtifactType = "file",
            Metadata = new Dictionary<string, object> { [ArtifactMetadataKeys.FileExtension] = ".pdf" } };
        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(child);
        await evidence.AddArtifactAsync(parent);
        await evidence.AddRelationshipAsync(new Relationship
        {
            SourceArtifactId = child.Id, TargetArtifactId = parent.Id, RelationshipType = RelationshipTypes.DerivedFrom
        });
        var package = CreateDetails(packageId, child.Id);
        var details = new EvidencePackageDetails
        {
            Package = package.Package,
            Artifacts = [new EvidencePackageArtifact { EvidencePackageId = packageId, ArtifactId = child.Id,
                ContentRole = EvidencePackageContentRoles.UnderlyingEvidence, ReviewerPageSelection = selection }]
        };
        var printer = new RecordingPrintRenderer(Enumerable.Range(1, 5).Select(n =>
            new PrintableArtifactPage { PageNumber = n, ContentType = "image/png", Content = new byte[] { (byte)n } }).ToArray());
        var service = new VeteransReviewerPackageDetailsService(new RecordingPackageService { Details = details }, evidence,
            new RecordingClassificationRepository(), new RecordingTextExtractor("b.\nc.\nform fragments"), printer);
        if (!valid)
        {
            await Assert.ThrowsAsync<InvalidDataException>(() => service.GetAsync(packageId));
            return;
        }
        var result = (await service.GetAsync(packageId))!;
        var content = Assert.Single(result.ArtifactContents);
        Assert.Same(child, content.Artifact);
        Assert.Equal(parent.Id, printer.ArtifactId);
        Assert.Equal(parent.Id, content.PrintableSourceArtifactId);
        Assert.Equal(selection.Split(',').Select(int.Parse), content.PrintablePages.Select(p => p.PageNumber));
        Assert.Equal(selection, content.ReviewerPageSelection);
        Assert.Equal("b.\nc.\nform fragments", content.Text);
        Assert.Equal(child.Id, Assert.Single(content.Relationships).SourceArtifactId);
        Assert.False(content.IsExtractedTextFallback);
    }

    [Fact]
    public async Task GetAsync_MissingPackageReturnsNull()
    {
        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService(),
                new InMemoryEvidenceRepository());

        var result =
            await service.GetAsync(
                new EvidencePackageId("missing"));

        Assert.Null(result);
    }

    [Fact]
    public async Task GetAsync_ResolvesPackageArtifacts()
    {
        var packageId = new EvidencePackageId("package-1");
        var artifact = CreateArtifact("artifact-1");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(
                        packageId,
                        artifact.Id)
                },
                evidence);

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);
        Assert.Equal(packageId, result.PackageDetails.Package.Id);
        Assert.Same(artifact, Assert.Single(result.Artifacts));
    }

    [Fact]
    public async Task GetAsync_ExtractsReviewerArtifactContent()
    {
        var packageId = new EvidencePackageId("package-1");
        var artifact = CreateArtifact("artifact-1");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var sourceArtifact = CreateArtifact("derived-1");
        await evidence.AddArtifactAsync(sourceArtifact);

        await evidence.AddRelationshipAsync(
            new Relationship
            {
                SourceArtifactId = artifact.Id,
                TargetArtifactId = new ArtifactId("derived-1"),
                RelationshipType = "DerivedFrom",
                CreatedUtc =
                    new DateTimeOffset(
                        2026, 8, 1, 14, 0, 0, TimeSpan.Zero)
            });

        await evidence.AddProvenanceAsync(
            new Provenance
            {
                ArtifactId = artifact.Id,
                Source = "/records/sleep-study.pdf",
                RecordedBy = "EMF.Discovery",
                RecordedUtc =
                    new DateTimeOffset(
                        2026, 8, 1, 12, 0, 0, TimeSpan.Zero)
            });

        var extractor =
            new RecordingTextExtractor("reviewable text");

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(
                        packageId,
                        artifact.Id)
                },
                evidence,
                extractor);

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);

        var content =
            Assert.Single(result.ArtifactContents);

        Assert.Same(artifact, content.Artifact);
        Assert.Equal("reviewable text", content.Text);

        var provenance = Assert.Single(content.Provenance);
        Assert.Equal("/records/sleep-study.pdf", provenance.Source);
        Assert.Equal("EMF.Discovery", provenance.RecordedBy);

        var relationship = Assert.Single(content.Relationships);
        Assert.Equal(artifact.Id, relationship.SourceArtifactId);
        Assert.Equal(
            new ArtifactId("derived-1"),
            relationship.TargetArtifactId);
        Assert.Equal("DerivedFrom", relationship.RelationshipType);

        Assert.Equal(artifact.Id, extractor.ArtifactId);
    }

    [Fact]
    public async Task GetAsync_RejectsWrongReturnedArtifactIdentity()
    {
        var packageId = new EvidencePackageId("package-1");
        var requestedId = new ArtifactId("artifact-1");
        var returned = CreateArtifact("artifact-other");

        var evidence =
            Proxy<IEvidenceRepository>(
                (method, args) =>
                    method.Name == "GetArtifactAsync"
                        ? Task.FromResult<Artifact?>(returned)
                        : throw new NotSupportedException());

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(
                        packageId,
                        requestedId)
                },
                evidence);

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => service.GetAsync(packageId));
    }

    [Fact]
    public async Task GetAsync_RejectsWrongProvenanceArtifactIdentity()
    {
        var packageId = new EvidencePackageId("package-1");
        var artifact = CreateArtifact("artifact-1");

        var evidence =
            Proxy<IEvidenceRepository>(
                (method, args) =>
                    method.Name switch
                    {
                        "GetArtifactAsync" =>
                            Task.FromResult<Artifact?>(artifact),
                        "GetProvenanceAsync" =>
                            Task.FromResult<IReadOnlyList<Provenance>>(
                            [
                                new Provenance
                                {
                                    ArtifactId =
                                        new ArtifactId("artifact-other"),
                                    Source = "test",
                                    RecordedBy = "test"
                                }
                            ]),
                        "GetRelationshipsAsync" =>
                            Task.FromResult<IReadOnlyList<Relationship>>([]),
                        _ => throw new NotSupportedException()
                    });

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(packageId, artifact.Id)
                },
                evidence,
                new RecordingTextExtractor("reviewable text"));

        var exception =
            await Assert.ThrowsAsync<InvalidOperationException>(
                () => service.GetAsync(packageId));

        Assert.Contains("provenance", exception.Message);
    }

    [Fact]
    public async Task GetAsync_RejectsUnrelatedRelationship()
    {
        var packageId = new EvidencePackageId("package-1");
        var artifact = CreateArtifact("artifact-1");

        var evidence =
            Proxy<IEvidenceRepository>(
                (method, args) =>
                    method.Name switch
                    {
                        "GetArtifactAsync" =>
                            Task.FromResult<Artifact?>(artifact),
                        "GetProvenanceAsync" =>
                            Task.FromResult<IReadOnlyList<Provenance>>([]),
                        "GetRelationshipsAsync" =>
                            Task.FromResult<IReadOnlyList<Relationship>>(
                            [
                                new Relationship
                                {
                                    SourceArtifactId =
                                        new ArtifactId("other-1"),
                                    TargetArtifactId =
                                        new ArtifactId("other-2"),
                                    RelationshipType = "Unrelated"
                                }
                            ]),
                        _ => throw new NotSupportedException()
                    });

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(packageId, artifact.Id)
                },
                evidence,
                new RecordingTextExtractor("reviewable text"));

        var exception =
            await Assert.ThrowsAsync<InvalidOperationException>(
                () => service.GetAsync(packageId));

        Assert.Contains("relationship", exception.Message);
    }

    [Fact]
    public async Task GetAsync_RejectsMissingArtifacts()
    {
        var packageId = new EvidencePackageId("package-1");
        var existing = CreateArtifact("artifact-1");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(existing);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(
                        packageId,
                        existing.Id,
                        new ArtifactId("missing"))
                },
                evidence);

        var exception =
            await Assert.ThrowsAsync<InvalidOperationException>(
                () => service.GetAsync(packageId));

        Assert.Contains(
            packageId.Value,
            exception.Message);

        Assert.Contains(
            "missing",
            exception.Message);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task GetAsync_UsesTextSummaryMetadata(
        bool persistedMetadataShape)
    {
        object summary =
            persistedMetadataShape
                ? global::System.Text.Json.JsonDocument
                    .Parse("\"reviewer summary\"")
                    .RootElement
                    .Clone()
                : "reviewer summary";

        var packageId = new EvidencePackageId("package-1");

        var artifact =
            new Artifact
            {
                Id = new ArtifactId("summary-1"),
                Name = "Reviewer summary",
                ArtifactType = "text-summary",
                Metadata =
                    new Dictionary<string, object>
                    {
                        ["summary"] = summary
                    }
            };

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var extractor =
            new RecordingTextExtractor("extracted text");

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(
                        packageId,
                        artifact.Id)
                },
                evidence,
                extractor);

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);

        var content =
            Assert.Single(result.ArtifactContents);

        Assert.Same(artifact, content.Artifact);
        Assert.Equal("reviewer summary", content.Text);
        Assert.Null(extractor.ArtifactId);
    }

    private static T Proxy<T>(
        Func<MethodInfo, object?[]?, object?> handler)
        where T : class
    {
        var proxy = DispatchProxy.Create<T, TestProxy>();
        ((TestProxy)(object)proxy).Handler = handler;
        return proxy;
    }

    private class TestProxy : DispatchProxy
    {
        public Func<MethodInfo, object?[]?, object?>? Handler
            { get; set; }

        protected override object? Invoke(
            MethodInfo? targetMethod,
            object?[]? args) =>
            Handler!(targetMethod!, args);
    }

    private static Artifact CreateArtifact(string id) =>
        new()
        {
            Id = new ArtifactId(id),
            Name = id,
            ArtifactType = "test"
        };

    private static EvidencePackageDetails CreateDetails(
        EvidencePackageId packageId,
        params ArtifactId[] artifactIds) =>
        new()
        {
            Package = new EvidencePackage
            {
                Id = packageId,
                ClaimIssueId = new ClaimIssueId("issue-1"),
                ServiceConnectionBasisId = new("basis-1"),
                Purpose = "Physician reviewer package",
                ReviewerRole = "MedicalProfessional"
            },
            Artifacts =
                artifactIds
                    .Select(
                        id => new EvidencePackageArtifact
                        {
                            EvidencePackageId = packageId,
                            ArtifactId = id,
                            ContentRole =
                                EvidencePackageContentRoles
                                    .UnderlyingEvidence
                        })
                    .ToArray()
        };
}

file sealed class RecordingTextExtractor(string? text) :
    EMF.Core.Contracts.IArtifactTextExtractor
{
    public ArtifactId? ArtifactId { get; private set; }

    public Task<string?> ExtractTextAsync(
        ArtifactId artifactId,
        CancellationToken cancellationToken = default)
    {
        ArtifactId = artifactId;
        return Task.FromResult(text);
    }
}

file sealed class RecordingPackageService :
    IEvidencePackageService
{
    public EvidencePackageDetails? Details { get; init; }

    public Task<EvidencePackageDetails?> GetAsync(
        EvidencePackageId evidencePackageId,
        CancellationToken cancellationToken = default) =>
        Task.FromResult(Details);

    public Task<EvidencePackage> CreateAsync(
        ClaimIssueId claimIssueId,
        string purpose,
        string reviewerRole,
        CancellationToken cancellationToken = default) =>
        throw new NotSupportedException();

    public Task<EvidencePackageArtifact> AddArtifactAsync(
        EvidencePackageId evidencePackageId,
        ArtifactId artifactId,
        string contentRole,
        CancellationToken cancellationToken = default) =>
        throw new NotSupportedException();

    public Task<IReadOnlyList<EvidencePackageDetails>> GetAsync(
        ClaimIssueId claimIssueId,
        CancellationToken cancellationToken = default) =>
        throw new NotSupportedException();
}

public sealed partial class VeteransReviewerPackageDetailsServiceTests
{
    [Fact]
    public async Task GetAsync_AssignsMedicalEvidenceAppendix()
    {
        var packageId = new EvidencePackageId("package-1");
        var artifact = CreateArtifact("artifact-1");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var classifications =
            new RecordingClassificationRepository
            {
                ExistingClassifications =
                [
                    new EvidenceClassification
                    {
                        Id =
                            new EvidenceClassificationId(
                                "classification-1"),
                        ArtifactId = artifact.Id,
                        ClaimIssueId =
                            new ClaimIssueId("issue-1"),
                        Classification =
                            EvidenceClassifications.MedicalEvidence
                    }
                ]
            };

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(
                        packageId,
                        artifact.Id)
                },
                evidence,
                classifications,
                new RecordingTextExtractor("reviewable text"));

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);

        Assert.Equal(
            VeteransReviewerPackageAppendix.MedicalEvidence,
            Assert.Single(result.ArtifactContents).Appendix);
    }
}

file sealed class RecordingClassificationRepository :
    IEvidenceClassificationRepository
{
    public IReadOnlyList<EvidenceClassification>
        ExistingClassifications { get; init; } = [];

    public bool ReturnAll { get; init; }

    public Task AddEvidenceClassificationAsync(
        EvidenceClassification classification,
        CancellationToken cancellationToken = default) =>
        Task.CompletedTask;

    public Task<EvidenceClassification?> GetEvidenceClassificationAsync(
        EvidenceClassificationId classificationId,
        CancellationToken cancellationToken = default) =>
        Task.FromResult<EvidenceClassification?>(null);

    public Task<IReadOnlyList<EvidenceClassification>>
        GetEvidenceClassificationsAsync(
            ArtifactId artifactId,
            CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<EvidenceClassification>>(
            ReturnAll
                ? ExistingClassifications
                : ExistingClassifications
                    .Where(x => x.ArtifactId == artifactId)
                    .ToArray());

    public Task<EvidenceClassification?> FindEvidenceClassificationAsync(
        ArtifactId artifactId,
        ClaimIssueId? claimIssueId,
        string classification,
        CancellationToken cancellationToken = default) =>
        Task.FromResult<EvidenceClassification?>(null);

    public Task AddEvidenceClassificationRequirementAsync(
        EvidenceClassificationRequirement association,
        CancellationToken cancellationToken = default) =>
        Task.CompletedTask;

    public Task<IReadOnlyList<EvidenceClassificationRequirement>>
        GetEvidenceClassificationRequirementsAsync(
            EvidenceClassificationId classificationId,
            CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<EvidenceClassificationRequirement>>([]);

    public Task<IReadOnlyList<EvidenceClassification>>
        GetEvidenceClassificationsAsync(
            RequirementId requirementId,
            CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<EvidenceClassification>>([]);

    public Task<IReadOnlyList<EvidenceClassification>>
        GetEvidenceClassificationsAsync(
            ClaimIssueId claimIssueId,
            CancellationToken cancellationToken = default) =>
        Task.FromResult(ExistingClassifications);
}

public sealed partial class VeteransReviewerPackageDetailsServiceTests
{
    [Fact]
    public async Task GetAsync_RejectsClassificationForDifferentArtifact()
    {
        var packageId = new EvidencePackageId("package-1");
        var artifact = CreateArtifact("artifact-1");
        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var classifications = new RecordingClassificationRepository
        {
            ReturnAll = true,
            ExistingClassifications =
            [
                new EvidenceClassification
                {
                    Id = new EvidenceClassificationId("classification-wrong"),
                    ArtifactId = new ArtifactId("artifact-other"),
                    ClaimIssueId = new ClaimIssueId("issue-1"),
                    Classification = EvidenceClassifications.MedicalEvidence
                }
            ]
        };

        var service = new VeteransReviewerPackageDetailsService(
            new RecordingPackageService
            {
                Details = CreateDetails(packageId, artifact.Id)
            },
            evidence,
            classifications,
            new RecordingTextExtractor("reviewable text"));

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => service.GetAsync(packageId));
    }

    [Fact]
    public async Task GetAsync_RejectsConflictingAppendixes()
    {
        var packageId = new EvidencePackageId("package-1");
        var artifact = CreateArtifact("artifact-1");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var classifications =
            new RecordingClassificationRepository
            {
                ExistingClassifications =
                [
                    new EvidenceClassification
                    {
                        Id =
                            new EvidenceClassificationId(
                                "classification-medical"),
                        ArtifactId = artifact.Id,
                        ClaimIssueId =
                            new ClaimIssueId("issue-1"),
                        Classification =
                            EvidenceClassifications.MedicalEvidence
                    },
                    new EvidenceClassification
                    {
                        Id =
                            new EvidenceClassificationId(
                                "classification-lay"),
                        ArtifactId = artifact.Id,
                        ClaimIssueId =
                            new ClaimIssueId("issue-1"),
                        Classification =
                            EvidenceClassifications.LayEvidence
                    }
                ]
            };

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(
                        packageId,
                        artifact.Id)
                },
                evidence,
                classifications,
                new RecordingTextExtractor("reviewable text"));

        var exception =
            await Assert.ThrowsAsync<InvalidOperationException>(
                () => service.GetAsync(packageId));

        Assert.Contains(
            artifact.Id.Value,
            exception.Message);
    }
}

public sealed partial class VeteransReviewerPackageDetailsServiceTests
{
    [Fact]
    public async Task GetAsync_RendersUnderlyingEvidenceForPrinting()
    {
        var packageId = new EvidencePackageId("package-print-1");
        var artifact = CreateArtifact("artifact-print-1");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var printRenderer =
            new RecordingPrintRenderer(
            [
                new PrintableArtifactPage
                {
                    PageNumber = 1,
                    ContentType = "image/png",
                    Content = new byte[] { 1, 2, 3 }
                }
            ]);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(packageId, artifact.Id)
                },
                evidence,
                new RecordingClassificationRepository(),
                new RecordingTextExtractor("reviewable text"),
                printRenderer);

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);

        var content = Assert.Single(result.ArtifactContents);
        var page = Assert.Single(content.PrintablePages);

        Assert.Equal(artifact.Id, printRenderer.ArtifactId);
        Assert.Equal(1, page.PageNumber);
        Assert.Equal("image/png", page.ContentType);
    }

    [Fact]
    public async Task GetAsync_ReplacesOscarCsvWithPapAnalysis()
    {
        var packageId = new EvidencePackageId("package-oscar");

        var artifact = new Artifact
        {
            Id = new ArtifactId("artifact-oscar"),
            Name = "OSCAR_Mike_Gould_by_Session_full.csv",
            ArtifactType = "test"
        };

        const string csv =
            "Date,Start,AHI,RDI,OA,UA,H,CA,RERA," +
            "Pressure_Avg,Pressure_Min,Pressure_Max,Pressure_95th," +
            "Leak_Avg,Leak_Max,Leak_95th,SpO2_Avg,SpO2_Min," +
            "Pulse_Avg,Hours,Hours_Used,Machine\n" +
            "2025-07-30,22:02:12,0.31,0,0,0,1,0,0," +
            "8.89,6,15.84,13.18,0,0,0,,,," +
            "0.7,0.7,AirCurve11ASV\n";

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var printRenderer = new RecordingPrintRenderer([]);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(packageId, artifact.Id)
                },
                evidence,
                new RecordingClassificationRepository(),
                new RecordingTextExtractor(csv),
                printRenderer);

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);

        var content = Assert.Single(result.ArtifactContents);
        var page = Assert.Single(content.PrintablePages);

        Assert.Contains("PAP Therapy Analysis", content.Text);
        Assert.Contains("Sessions: 1", content.Text);
        Assert.DoesNotContain("Pressure_Avg", content.Text);
        Assert.DoesNotContain("Hours_Used", content.Text);

        var printable =
            global::System.Text.Encoding.UTF8.GetString(
                page.Content.Span);

        Assert.Contains("PAP Therapy Analysis", printable);
        Assert.Contains("Sessions: 1", printable);
        Assert.DoesNotContain("Pressure_Avg", printable);
        Assert.DoesNotContain("Hours_Used", printable);

        Assert.Equal(0, printRenderer.CallCount);
    }

    [Fact]
    public async Task GetAsync_ReplacesSnoreJsonWithPapAnalysis()
    {
        var packageId = new EvidencePackageId("package-snore");

        var artifact = new Artifact
        {
            Id = new ArtifactId("artifact-snore"),
            Name = "SNORE_Mike_Gould_sessions.json",
            ArtifactType = "test"
        };

        const string json = """
        {
          "snore_export_format": "1.0",
          "session_count": 1,
          "sessions": [{
            "device_session_id": "20250730_220208_merged",
            "date": "2025-07-30",
            "start_time": "2025-07-30T22:02:57",
            "duration_hours": 10.82,
            "device": { "model": "AirCurve11ASV" },
            "statistics": {
              "ahi": 9.592476489028213,
              "unclassified_apneas": 44,
              "hypopneas": 58,
              "usage_hours": 10.633333333333333
            }
          }]
        }
        """;

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var printRenderer = new RecordingPrintRenderer([]);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(packageId, artifact.Id)
                },
                evidence,
                new RecordingClassificationRepository(),
                new RecordingTextExtractor(json),
                printRenderer);

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);

        var content = Assert.Single(result.ArtifactContents);
        var page = Assert.Single(content.PrintablePages);

        Assert.Contains("PAP Therapy Analysis", content.Text);
        Assert.Contains("Sessions: 1", content.Text);
        Assert.Contains("retained SNORE session export", content.Text);
        Assert.DoesNotContain("device_session_id", content.Text);

        var printable =
            global::System.Text.Encoding.UTF8.GetString(
                page.Content.Span);

        Assert.Contains("PAP Therapy Analysis", printable);
        Assert.Contains("Sessions: 1", printable);
        Assert.Contains("retained SNORE session export", printable);
        Assert.DoesNotContain("device_session_id", printable);

        Assert.Equal(0, printRenderer.CallCount);
    }

    [Fact]
    public async Task GetAsync_RejectsUnderlyingEvidenceWithoutPrintablePages()
    {
        var packageId = new EvidencePackageId("package-print-2");
        var artifact = CreateArtifact("artifact-print-2");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(packageId, artifact.Id)
                },
                evidence,
                new RecordingClassificationRepository(),
                new RecordingTextExtractor("reviewable text"),
                new RecordingPrintRenderer([]));

        var exception =
            await Assert.ThrowsAsync<InvalidOperationException>(
                () => service.GetAsync(packageId));

        Assert.Contains(artifact.Id.Value, exception.Message);
        Assert.Contains("printable", exception.Message);
    }
}

public sealed partial class VeteransReviewerPackageDetailsServiceTests
{
    [Fact]
    public async Task GetAsync_RetainsTextlessUnderlyingEvidenceWhenPrintable()
    {
        var packageId = new EvidencePackageId("package-print-3");
        var artifact = CreateArtifact("artifact-print-3");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService
                {
                    Details = CreateDetails(packageId, artifact.Id)
                },
                evidence,
                new RecordingClassificationRepository(),
                new RecordingTextExtractor(null),
                new RecordingPrintRenderer(
                [
                    new PrintableArtifactPage
                    {
                        PageNumber = 1,
                        ContentType = "image/png",
                        Content = new byte[] { 4, 5, 6 }
                    }
                ]));

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);

        var content = Assert.Single(result.ArtifactContents);

        Assert.Equal(string.Empty, content.Text);
        Assert.Single(content.PrintablePages);
    }

    [Fact]
    public async Task GetAsync_DoesNotPrintGeneratedOrganizationalMaterial()
    {
        var packageId = new EvidencePackageId("package-print-4");
        var artifact = CreateArtifact("artifact-print-4");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var details =
            new EvidencePackageDetails
            {
                Package = new EvidencePackage
                {
                    Id = packageId,
                    ClaimIssueId = new ClaimIssueId("issue-1"),
                    ServiceConnectionBasisId = new("basis-1"),
                Purpose = "Physician reviewer package",
                    ReviewerRole = "MedicalProfessional"
                },
                Artifacts =
                [
                    new EvidencePackageArtifact
                    {
                        EvidencePackageId = packageId,
                        ArtifactId = artifact.Id,
                        ContentRole =
                            EvidencePackageContentRoles
                                .GeneratedOrganizationalMaterial
                    }
                ]
            };

        var printRenderer = new RecordingPrintRenderer([]);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService { Details = details },
                evidence,
                new RecordingClassificationRepository(),
                new RecordingTextExtractor("generated content"),
                printRenderer);

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);
        Assert.Single(result.ArtifactContents);
        Assert.Equal(0, printRenderer.CallCount);
    }
}

public sealed partial class VeteransReviewerPackageDetailsServiceTests
{
    [Fact]
    public async Task GetAsync_AppliesReviewerPageSelectionAfterRendering()
    {
        var packageId =
            new EvidencePackageId("package-page-selection");

        var artifact =
            CreateArtifact("artifact-page-selection");

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var details =
            new EvidencePackageDetails
            {
                Package = new EvidencePackage
                {
                    Id = packageId,
                    ClaimIssueId = new ClaimIssueId("issue-1"),
                    ServiceConnectionBasisId = new("basis-1"),
                Purpose = "Physician reviewer package",
                    ReviewerRole = "MedicalProfessional"
                },
                Artifacts =
                [
                    new EvidencePackageArtifact
                    {
                        EvidencePackageId = packageId,
                        ArtifactId = artifact.Id,
                        ContentRole =
                            EvidencePackageContentRoles.UnderlyingEvidence,
                        ReviewerPageSelection = "11,13-17"
                    }
                ]
            };

        var renderedPages =
            Enumerable.Range(1, 17)
                .Select(
                    number =>
                        new PrintableArtifactPage
                        {
                            PageNumber = number,
                            ContentType = "image/png",
                            Content = ReadOnlyMemory<byte>.Empty
                        })
                .ToArray();

        var printRenderer =
            new RecordingPrintRenderer(renderedPages);

        var service =
            new VeteransReviewerPackageDetailsService(
                new RecordingPackageService { Details = details },
                evidence,
                new RecordingClassificationRepository(),
                new RecordingTextExtractor("reviewable text"),
                printRenderer);

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);
        Assert.Equal(17, renderedPages.Length);
        Assert.Equal(1, printRenderer.CallCount);

        var content = Assert.Single(result.ArtifactContents);

        Assert.Equal(
            [11, 13, 14, 15, 16, 17],
            content.PrintablePages.Select(x => x.PageNumber));
    }
}

file sealed class RecordingPrintRenderer(
    IReadOnlyList<PrintableArtifactPage> pages) :
    IArtifactPrintRenderer
{
    public ArtifactId? ArtifactId { get; private set; }

    public int CallCount { get; private set; }

    public Task<IReadOnlyList<PrintableArtifactPage>> RenderAsync(
        ArtifactId artifactId,
        CancellationToken cancellationToken = default)
    {
        ArtifactId = artifactId;
        CallCount++;
        return Task.FromResult(pages);
    }
}

public sealed partial class VeteransReviewerPackageDetailsServiceTests
{
    [Theory]
    [InlineData("basis-1", true, true)]
    [InlineData("basis-other", false, true)]
    [InlineData("basis-1", false, false)]
    public async Task GetAsync_AssignsMedicalLiteratureAppendixOnlyToStoredPackageMembers(
        string reviewBasis, bool included, bool packageMember)
    {
        var packageId = new EvidencePackageId("package-literature");
        var artifact = new Artifact
        {
            Id = new ArtifactId("artifact-literature"),
            Name = "artifact-literature.pdf",
            ArtifactType = "test"
        };

        var evidence = new InMemoryEvidenceRepository();
        await evidence.AddArtifactAsync(artifact);

        var classifications = new RecordingClassificationRepository
        {
            ExistingClassifications =
            [
                new EvidenceClassification
                {
                    Id = new EvidenceClassificationId("classification-lit"),
                    ArtifactId = artifact.Id,
                    ClaimIssueId = new ClaimIssueId("issue-1"),
                    Classification = EvidenceClassifications.MedicalEvidence
                }
            ]
        };

        var literature = new RecordingMedicalLiteratureRepository
        {
            ArtifactId = artifact.Id,
            SourceId = new MedicalLiteratureSourceId("study-1"),
            Source = new MedicalLiteratureSource
            {
                Id = new MedicalLiteratureSourceId("study-1"),
                Title = "PTSD and Obstructive Sleep Apnea",
                Authors = "Chinoy et al.",
                Publication = "Sleep Medicine",
                PublicationYear = 2022
            },
            StoredReviewerText = new MedicalLiteratureReviewerText
            {
                MedicalLiteratureSourceId =
                    new MedicalLiteratureSourceId("study-1"),
                ArtifactId = artifact.Id,
                Text = "stale normalized reviewer text",
                ExtractionMethod =
                    "artifact-text-extractor-pdf-normalized-v4",
                ExtractedUtc =
                    new DateTimeOffset(
                        2026, 9, 19, 17, 59, 18, TimeSpan.Zero)
            },
            ReviewedClassifications =
            [
                new ReviewedMedicalLiteratureClassification
                {
                    Association = new RequirementMedicalLiterature
                    {
                        ServiceConnectionBasisId = new(reviewBasis),
                        RequirementId = new RequirementId("requirement-lit"),
                        MedicalLiteratureSourceId =
                            new MedicalLiteratureSourceId("study-1"),
                        GuidanceRole =
                            EvidenceGuidanceRoles.SupportsRequirement,
                        Description = "Supports the medical mechanism."
                    },
                    ArtifactId = artifact.Id,
                    PromotedBy = "promotion-test",
                    PromotedUtc =
                        new DateTimeOffset(
                            2026, 9, 12, 12, 5, 0, TimeSpan.Zero),
                    ReviewedBy = "reviewer@example.test",
                    ReviewedUtc =
                        new DateTimeOffset(
                            2026, 9, 12, 12, 0, 0, TimeSpan.Zero),
                    IntelligenceOutput = "{}",
                    CapabilityId = "TextStructuredExtraction",
                    ProviderId = "test-provider",
                    CorrelationId = "details-reviewed-lit",
                    EngineName = "test-engine",
                    StartedUtc =
                        new DateTimeOffset(
                            2026, 9, 12, 11, 58, 0, TimeSpan.Zero),
                    CompletedUtc =
                        new DateTimeOffset(
                            2026, 9, 12, 11, 59, 0, TimeSpan.Zero),
                    RequiresReview = true,
                    Warnings = [],
                    SourceExcerpts =
                    [
                        new MedicalLiteratureSourceExcerpt
                        {
                            ArtifactId = artifact.Id,
                            Text = "Exact accepted literature excerpt."
                        }
                    ]
                }
            ]
        };

        var packageDetails = packageMember
            ? CreateDetails(packageId, artifact.Id)
            : CreateDetails(packageId);
        var basis = new EMF.Extensions.VeteransClaims.Models.Service.ServiceConnectionBasis
        {
            Id = new("basis-1"), ClaimIssueId = packageDetails.Package.ClaimIssueId,
            ServiceConnectionTheoryId = new("theory-1")
        };
        var claimDetails = new ClaimIssueAdjudicationDetails
        {
            ClaimIssue = new EMF.Extensions.VeteransClaims.Models.Claims.ClaimIssue
            {
                Id = basis.ClaimIssueId, ClaimId = new("claim-1"),
                ClaimIssueType = "ServiceConnection"
            },
            ClaimedConditions = [], ServiceConnectionTheories = [],
            ServiceConnectionBases = [basis], ServiceConnectedConditions = [],
            ServiceEvents = [], Timeline = [], Evidence = null!,
            Requirements = [new ServiceConnectionBasisRequirementDetails
            {
                Basis = basis,
                Requirement = new EMF.Extensions.VeteransClaims.Regulatory.Requirement
                {
                    Id = new("requirement-lit"), RegulatoryProvisionId = new("provision-1"),
                    Description = "Medical evidence"
                },
                RegulatoryProvision = null!, Responsiveness = null!, DevelopmentChecklist = null!
            }]
        };
        var service = new VeteransReviewerPackageDetailsService(
            new RecordingPackageService { Details = packageDetails },
            evidence, classifications, new RecordingTextExtractor("literature text"),
            literature,
            Proxy<IClaimIssueAdjudicationDetailsService>((_, _) =>
                Task.FromResult<ClaimIssueAdjudicationDetails?>(claimDetails)));

        var result = await service.GetAsync(packageId);

        Assert.NotNull(result);
        Assert.Same(packageDetails, result.PackageDetails);
        if (!included)
        {
            Assert.Empty(result.ArtifactContents);
            Assert.Empty(result.Artifacts);
            return;
        }
        var content =
            Assert.Single(result.ArtifactContents);

        Assert.Equal(
            VeteransReviewerPackageAppendix.MedicalLiterature,
            content.Appendix);

        Assert.Equal(
            "PTSD and Obstructive Sleep Apnea",
            content.Artifact.Metadata[
                VeteransArtifactMetadataKeys.EvidenceTitle]);

        Assert.Equal(
            "2022",
            content.Artifact.Metadata[
                VeteransArtifactMetadataKeys.EvidenceDate]);

        var reviewed =
            Assert.Single(
                content.ReviewedMedicalLiteratureClassifications);

        Assert.Equal(
            "requirement-lit",
            reviewed.Association.RequirementId.Value);
        Assert.Equal(
            "Exact accepted literature excerpt.",
            Assert.Single(reviewed.SourceExcerpts).Text);

        Assert.Equal(
            "literature text",
            content.MedicalLiteratureReviewerText);
        Assert.NotNull(literature.UpsertedReviewerText);
        Assert.Equal(
            "artifact-text-extractor-pdf-normalized-v8",
            literature.UpsertedReviewerText!.ExtractionMethod);
        Assert.Equal(
            "literature text",
            literature.UpsertedReviewerText.Text);
    }
}

public sealed partial class VeteransReviewerPackageDetailsServiceTests
{
    [Fact]
    public void NormalizePdfMedicalLiteratureReviewerText_DehyphenatesPdfLineBreakArtifacts()
    {
        var input =
            "These drugs indi-\nrectly increase gastroesoph-\nageal symptoms. " +
            "A double-\nblind case-\ncontrol study reported anti-\ninflammatory effects. " +
            "Patients were pre- scribed therapy in a study in- volving 2,251 participants; " +
            "heartburn de- veloped in 68%. Ruigó- mez et al. reported that reflux in-\n" +
            "creased ap\uFFFEproximately four times with anti\uFFFEasthmatic therapy.\n\n" +
            "In a randomized study, theophylline and a pla- S41 S42 Mungan and Pınarbaşı Şimşek. Drugs and\n" +
            "gastroesophageal reflux disease cebo were compared with placebo.\n\n" +
            "Symptoms decreased over time (20). Bisphosphonates Although gastrointestinal side\n" +
            "effects of bisphosphonates have been found to be similar to those of placebos in clinical\n\n" +
            "trials, side effects occur in approximately one in three patients.\n" +
            "It can be said that the use of bisphosphonate alone does not lead to an\n" +
            "•\n•\n•\n•\n•\n•\n" +
            "Turk J Gastroenterol 2017; 28(Suppl 1): S38-S43\n" +
            "increase in the development risk of GERD symptoms.\n" +
            "A placebo was used. Nitrates and Calcium Channel Blockers Nitrates and Calcium Channel Blockers (CCBs) decrease LESP.\n" +
            "Tanaka M. High incidence of newly-developed gastroesophageal\n" +
            "24. 25. 26. 27. 28. 29. 30. 31. 32. 33. 34. 35. 36. 37. 38. 39. 40. 41.\n" +
            "reflux disease in the Japanese community.\n" +
            "• Beta-adrenergic agonists\n• Anticholinergics\n" +
            "In a randomized study in which a to-\nS39\nS40\n" +
            "Mungan and Pınarbaşı Şimşek. Drugs and gastroesophageal reflux disease\n" +
            "tal of 40 centers participated.\n" +
            "Address for Correspondence: Author E-mail: example@example.com © Copyright 2017 by The Turkish Society of Gastroenterology • Available online at example.org • DOI: 10.5152/tjg.2017.11\n" +
            "Gastrointestinal side effects can regress when the uses of\n\n" +
            "bisphosphonates\n\nchanges from weekly preparations.\n" +
            "Symptoms improved.Similarly, treatment continued.\n" +
            "• The use of hormone replacement therapy (HRT) containing only estrogen increases the risk of GERD development. " +
            "The use of HRT preparations with combined\n\nestrogen and progesterone and the use of oral contraceptive (OC) therapeutic agents " +
            "does not lead to a significant increase in the risk of GERD development (Level of evidence: 2b).\n" +
            "• It can be said in light of the limited data available that\n\nthe use of bisphosphonate alone does not lead to an increase in GERD symptoms.\n" +
            "Antidepressant Drugs The use of antidepressant drugs was evaluated.\n" +
            "S43";

        var normalized =
            VeteransReviewerPackageDetailsService
                .NormalizePdfMedicalLiteratureReviewerText(input);

        Assert.Contains("indirectly", normalized);
        Assert.Contains("gastroesophageal", normalized);
        Assert.Contains("double-blind", normalized);
        Assert.Contains("case-control", normalized);
        Assert.Contains("anti-inflammatory", normalized);
        Assert.Contains("prescribed", normalized);
        Assert.Contains("involving", normalized);
        Assert.Contains("developed", normalized);
        Assert.Contains("Ruigómez", normalized);
        Assert.Contains("increased", normalized);
        Assert.Contains("approximately", normalized);
        Assert.Contains("anti-asthmatic", normalized);
        Assert.Contains(
            "theophylline and a placebo were compared with placebo",
            normalized);
        Assert.Contains(
            "Symptoms decreased over time (20).\n\nBisphosphonates\n\nAlthough gastrointestinal side effects of bisphosphonates have been found to be similar to those of placebos in clinical trials, side effects occur",
            normalized);
        Assert.Contains(
            "bisphosphonate alone does not lead to an increase in the development risk of GERD symptoms",
            normalized);
        Assert.Contains(
            "A placebo was used.\n\nNitrates and Calcium Channel Blockers\n\nNitrates and Calcium Channel Blockers (CCBs) decrease LESP.",
            normalized);
        Assert.Contains(
            "newly-developed gastroesophageal reflux disease in the Japanese community",
            normalized);
        Assert.Contains("• Beta-adrenergic agonists", normalized);
        Assert.Contains("• Anticholinergics", normalized);
        Assert.Contains("a total of 40 centers participated.", normalized);
        Assert.Contains(
            "the uses of bisphosphonates changes from weekly preparations.",
            normalized);
        Assert.Contains(
            "Symptoms improved. Similarly, treatment continued.",
            normalized);
        Assert.Contains(
            "• The use of hormone replacement therapy (HRT) containing only estrogen increases the risk of GERD development. " +
            "The use of HRT preparations with combined estrogen and progesterone and the use of oral contraceptive (OC) therapeutic agents " +
            "does not lead to a significant increase in the risk of GERD development (Level of evidence: 2b).",
            normalized);
        Assert.DoesNotContain("combined\n\nestrogen", normalized);
        Assert.Contains(
            "• It can be said in light of the limited data available that the use of bisphosphonate alone does not lead to an increase in GERD symptoms.",
            normalized);
        Assert.Contains(
            "Antidepressant Drugs\n\nThe use of antidepressant drugs was evaluated.",
            normalized);
        Assert.DoesNotContain("S41 S42 Mungan", normalized);
        Assert.DoesNotContain("S39", normalized);
        Assert.DoesNotContain("S40", normalized);
        Assert.DoesNotContain("S43", normalized);
        Assert.DoesNotContain("Address for Correspondence", normalized);
        Assert.DoesNotContain("Turk J Gastroenterol 2017", normalized);
        Assert.DoesNotContain("24. 25. 26. 27.", normalized);
        Assert.DoesNotContain("\n•\n", normalized);
        Assert.DoesNotContain("indi-\nrectly", normalized);
        Assert.DoesNotContain("gastroesoph-\nageal", normalized);
        Assert.DoesNotContain("pre- scribed", normalized);
        Assert.DoesNotContain("in- volving", normalized);
        Assert.DoesNotContain("de- veloped", normalized);
    }

}

file sealed class RecordingMedicalLiteratureRepository :
    IMedicalLiteratureRepository
{
    public required ArtifactId ArtifactId { get; init; }
    public required MedicalLiteratureSourceId SourceId { get; init; }
    public required MedicalLiteratureSource Source { get; init; }

    public IReadOnlyList<ReviewedMedicalLiteratureClassification>
        ReviewedClassifications { get; init; } = [];

    public MedicalLiteratureReviewerText? StoredReviewerText
        { get; set; }

    public MedicalLiteratureReviewerText? UpsertedReviewerText
        { get; private set; }

    public Task AddMedicalLiteratureSourceAsync(
        MedicalLiteratureSource source,
        CancellationToken cancellationToken = default) =>
        throw new NotSupportedException();

    public Task<MedicalLiteratureSource?> GetMedicalLiteratureSourceAsync(
        MedicalLiteratureSourceId sourceId,
        CancellationToken cancellationToken = default) =>
        Task.FromResult<MedicalLiteratureSource?>(
            sourceId == SourceId ? Source : null);

    public Task AddRequirementMedicalLiteratureAsync(
        RequirementMedicalLiterature literature,
        CancellationToken cancellationToken = default) =>
        throw new NotSupportedException();

    public Task<IReadOnlyList<RequirementMedicalLiterature>>
        GetRequirementMedicalLiteratureAsync(
            RequirementId requirementId,
            CancellationToken cancellationToken = default) =>
        throw new NotSupportedException();

    public Task<IReadOnlyList<MedicalLiteratureSourceId>>
        GetMedicalLiteratureSourceIdsAsync(
            ArtifactId artifactId,
            CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<MedicalLiteratureSourceId>>(
            artifactId == ArtifactId ? [SourceId] : []);

    public Task<IReadOnlyList<ReviewedMedicalLiteratureClassification>>
        GetReviewedClassificationsAsync(
            ServiceConnectionBasisId basisId,
            ArtifactId artifactId,
            CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<ReviewedMedicalLiteratureClassification>>(
            ReviewedClassifications.Where(x => x.Association.ServiceConnectionBasisId == basisId &&
                x.ArtifactId == artifactId).ToArray());

    public Task<IReadOnlyList<ReviewedMedicalLiteratureClassification>>
        GetReviewedClassificationsAsync(
            ArtifactId artifactId,
            CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<ReviewedMedicalLiteratureClassification>>(
            artifactId == ArtifactId ? ReviewedClassifications : []);

    public Task UpsertReviewerTextAsync(
        MedicalLiteratureReviewerText reviewerText,
        CancellationToken cancellationToken = default)
    {
        UpsertedReviewerText = reviewerText;
        StoredReviewerText = reviewerText;
        return Task.CompletedTask;
    }

    public Task<MedicalLiteratureReviewerText?> GetReviewerTextAsync(
        MedicalLiteratureSourceId sourceId,
        ArtifactId artifactId,
        CancellationToken cancellationToken = default) =>
        Task.FromResult(
            sourceId == SourceId && artifactId == ArtifactId
                ? StoredReviewerText
                : null);
}
