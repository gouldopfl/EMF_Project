using EMF.Common;
using EMF.Core.Contracts.Storage;
using EMF.Core.Models.Identities;
using EMF.Extensions.VeteransClaims.Models.Adjudication;
using EMF.Extensions.VeteransClaims.Models.Clinical;
using EMF.Extensions.VeteransClaims.Models.Conditions;
using EMF.Extensions.VeteransClaims.Models.Service;
using EMF.Extensions.VeteransClaims.Regulatory;
using EMF.Extensions.VeteransClaims.Models.Identities;
using EMF.Extensions.VeteransClaims.Models.Medications;
using EMF.Intelligence.Models;
using EMF.Intelligence.Models.Identities;
using EMF.Integrity;
using EMF.Extensions.VeteransClaims.Orchestration;
using EMF.Extensions.VeteransClaims.Persistence.Sqlite;
using EMF.Extensions.VeteransClaims.Persistence.Sqlite.Repositories;
using EMF.Extensions.VeteransClaims.Services;
using EMF.Orchestration.Services;
using EMF.Persistence.Repositories;

namespace EMF.ConsoleApplication;

public static class VeteransConsoleCommand
{
    public static Task<int> RunAsync(
        string[] args)
    {
        return RunAsync(
            args,
            TextSummarizationConsoleRuntimeFactory.CreateAsync);
    }

    internal static async Task<int> RunAsync(
        string[] args,
        Func<Task<TextSummarizationConsoleRuntime>> runtimeFactory,
        Func<IArtifactContentStore?>? contentStoreFactory = null)
    {
        ArgumentNullException.ThrowIfNull(runtimeFactory);

        contentStoreFactory ??=
            ArtifactContentStoreFactory.Create;

        if (args.Length == 3 &&
            args[0] == "schema" &&
            args[1] == "migrate")
        {
            var path = Path.GetFullPath(args[2]);

            if (!File.Exists(path))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {path}");
                return 2;
            }

            await new VeteransClaimsSqliteSchema(path)
                .InitializeAsync();

            global::System.Console.WriteLine(
                "Veterans Claims schema migration complete.");

            return 0;
        }

        if (args.Length == 4 &&
            args[0] == "adjudication" &&
            args[1] == "assess")
        {
            var adjudicationDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(adjudicationDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {adjudicationDatabasePath}");

                return 2;
            }

            return await RunAdjudicationAssessmentAsync(
                adjudicationDatabasePath,
                new ClaimIssueId(args[3]),
                global::System.Console.Out);
        }

        if (args.Length == 4 &&
            args[0] == "adjudication" &&
            args[1] == "claim")
        {
            var adjudicationClaimDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(adjudicationClaimDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {adjudicationClaimDatabasePath}");

                return 2;
            }

            return await RunClaimAdjudicationAssessmentAsync(
                adjudicationClaimDatabasePath,
                new ClaimId(args[3]),
                global::System.Console.Out);
        }

        if (args.Length == 4 &&
            args[0] == "decision" &&
            args[1] == "history")
        {
            var decisionHistoryDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(decisionHistoryDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {decisionHistoryDatabasePath}");

                return 2;
            }

            return await RunDecisionHistoryAsync(
                decisionHistoryDatabasePath,
                new ClaimId(args[3]),
                global::System.Console.Out);
        }

        if (args.Length == 4 &&
            args[0] == "decision" &&
            args[1] == "review")
        {
            var decisionReviewDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(decisionReviewDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {decisionReviewDatabasePath}");

                return 2;
            }

            return await RunDecisionReviewAsync(
                decisionReviewDatabasePath,
                new ClaimIssueId(args[3]),
                global::System.Console.Out);
        }

        if (args.Length == 4 &&
            args[0] == "decision" &&
            args[1] == "interpret")
        {
            var decisionDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(decisionDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {decisionDatabasePath}");

                return 2;
            }

            return await RunDecisionInterpretAsync(
                decisionDatabasePath,
                new ArtifactId(args[3]),
                runtimeFactory,
                ArtifactContentStoreFactory.Create(),
                global::System.Console.Out);
        }

        if (args.Length == 7 &&
            args[0] == "condition" &&
            args[1] == "service-connected")
        {
            var conditionDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(conditionDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {conditionDatabasePath}");

                return 2;
            }

            return await RunAddServiceConnectedConditionAsync(
                conditionDatabasePath,
                new VeteranId(args[3]),
                new ServiceConnectionBasisId(args[4]),
                new MedicalConditionId(args[5]),
                args[6],
                global::System.Console.Out);
        }

        if (args.Length == 14 &&
            args[0] == "regulatory" &&
            args[1] == "requirement")
        {
            var regulatoryDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(regulatoryDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {regulatoryDatabasePath}");

                return 2;
            }

            return await RunAddRegulatoryRequirementAsync(
                regulatoryDatabasePath,
                new ServiceConnectionBasisId(args[3]),
                new RegulatoryAuthorityId(args[4]),
                args[5],
                args[6],
                new RegulatoryProvisionId(args[7]),
                args[8],
                args[9],
                args[10],
                args[11],
                new RequirementId(args[12]),
                args[13],
                global::System.Console.Out);
        }

        if (args.Length == 10 &&
            args[0] == "evidence" &&
            args[1] == "recognition" &&
            args[2] == "add")
        {
            var recognitionDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(recognitionDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {recognitionDatabasePath}");

                return 2;
            }

            return await RunAddEvidenceRecognitionTermAsync(
                recognitionDatabasePath,
                new RequirementId(args[4]),
                args[5],
                args[6],
                args[7],
                args[8] == "-" ? null : args[8],
                args[9],
                global::System.Console.Out);
        }

        if ((args.Length == 5 || args.Length == 6) &&
            args[0] == "evidence" &&
            args[1] == "recognition" &&
            args[2] == "replay")
        {
            var replaySnapshotPath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(replaySnapshotPath))
            {
                global::System.Console.Error.WriteLine(
                    $"Recognition replay snapshot not found: {replaySnapshotPath}");

                return 2;
            }

            var qualifiedOutputPath =
                args.Length == 6
                    ? Path.GetFullPath(args[5])
                    : null;

            return await RunEvidenceRecognitionTermReplayAsync(
                replaySnapshotPath,
                new ArtifactId(args[4]),
                contentStoreFactory(),
                global::System.Console.Out,
                qualifiedOutputPath);
        }

        if (args.Length == 7 &&
            args[0] == "evidence" &&
            args[1] == "recognition" &&
            args[2] == "persist")
        {
            var persistenceDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(persistenceDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {persistenceDatabasePath}");

                return 2;
            }

            var persistenceSnapshotPath =
                Path.GetFullPath(args[4]);

            if (!File.Exists(persistenceSnapshotPath))
            {
                global::System.Console.Error.WriteLine(
                    $"Recognition replay snapshot not found: {persistenceSnapshotPath}");

                return 2;
            }

            return await RunEvidenceRecognitionPersistAsync(
                persistenceDatabasePath,
                persistenceSnapshotPath,
                new ClaimIssueId(args[5]),
                new ArtifactId(args[6]),
                contentStoreFactory(),
                global::System.Console.Out);
        }

        if (args.Length == 8 &&
            args[0] == "evidence" &&
            args[1] == "bounded" &&
            args[2] == "list")
        {
            var boundedDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(boundedDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {boundedDatabasePath}");

                return 2;
            }

            return await RunBoundedEvidenceListAsync(
                boundedDatabasePath,
                new ClaimIssueId(args[4]),
                new ServiceConnectionBasisId(args[5]),
                new RequirementId(args[6]),
                new ArtifactId(args[7]),
                global::System.Console.Out);
        }

        var supersedeBoundedReview =
            args.Length == 12 &&
            args[0] == "evidence" &&
            args[1] == "bounded" &&
            args[2] == "review" &&
            args[3] == "--supersede";

        if ((args.Length == 10 || supersedeBoundedReview) &&
            args[0] == "evidence" &&
            args[1] == "bounded" &&
            args[2] == "review")
        {
            var reviewArgOffset = supersedeBoundedReview ? 2 : 0;
            var supersedesCorrelationId =
                supersedeBoundedReview ? args[4] : null;
            var boundedReviewDatabasePath =
                Path.GetFullPath(args[3 + reviewArgOffset]);
            var auditDatabasePath =
                Path.GetFullPath(args[4 + reviewArgOffset]);
            var receiptPath =
                Path.GetFullPath(args[9 + reviewArgOffset]);

            if (!File.Exists(boundedReviewDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {boundedReviewDatabasePath}");
                return 2;
            }

            if (!File.Exists(auditDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Intelligence audit database not found: {auditDatabasePath}");
                return 2;
            }

            if (!File.Exists(receiptPath))
            {
                global::System.Console.Error.WriteLine(
                    $"Interpretation receipt not found: {receiptPath}");
                return 2;
            }

            return await VeteransBoundedEvidenceReviewConsoleService.ReviewAsync(
                boundedReviewDatabasePath,
                auditDatabasePath,
                new ClaimIssueId(args[5 + reviewArgOffset]),
                new ServiceConnectionBasisId(args[6 + reviewArgOffset]),
                new RequirementId(args[7 + reviewArgOffset]),
                new ArtifactId(args[8 + reviewArgOffset]),
                receiptPath,
                contentStoreFactory(),
                Environment.GetEnvironmentVariable("EMF_REVIEWED_BY"),
                global::System.Console.Out,
                supersedesCorrelationId);
        }

        if (args.Length == 6 &&
            args[0] == "evidence" &&
            args[1] == "bounded" &&
            args[2] == "reviewed")
        {
            var boundedReviewDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(boundedReviewDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {boundedReviewDatabasePath}");
                return 2;
            }

            return await VeteransBoundedEvidenceReviewConsoleService.ListAsync(
                boundedReviewDatabasePath,
                args[4],
                args[5],
                global::System.Console.Out);
        }

        if ((args.Length == 8 || args.Length == 9) &&
            args[0] == "evidence" &&
            args[1] == "bounded" &&
            args[2] == "interpret")
        {
            var boundedDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(boundedDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {boundedDatabasePath}");

                return 2;
            }

            ArtifactId? boundedArtifactId =
                args.Length == 9
                    ? new ArtifactId(args[8])
                    : null;

            return await RunBoundedEvidenceInterpretAsync(
                boundedDatabasePath,
                new ClaimIssueId(args[4]),
                new ServiceConnectionBasisId(args[5]),
                new RequirementId(args[6]),
                new ArtifactId(args[7]),
                runtimeFactory,
                contentStoreFactory(),
                global::System.Console.Out,
                boundedArtifactId);
        }

        if (args.Length == 6 &&
            args[0] == "evidence" &&
            args[1] == "recognition" &&
            args[2] == "audit")
        {
            var recognitionDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(recognitionDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {recognitionDatabasePath}");

                return 2;
            }

            return await RunEvidenceRecognitionTermAuditAsync(
                recognitionDatabasePath,
                new ClaimIssueId(args[4]),
                new ArtifactId(args[5]),
                runtimeFactory,
                contentStoreFactory(),
                global::System.Console.Out);
        }

        if (args.Length == 5 &&
            args[0] == "evidence" &&
            args[1] == "recognition" &&
            args[2] == "propose")
        {
            var recognitionDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(recognitionDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {recognitionDatabasePath}");

                return 2;
            }

            return await RunEvidenceRecognitionTermProposalsAsync(
                recognitionDatabasePath,
                new ClaimIssueId(args[4]),
                runtimeFactory,
                global::System.Console.Out);
        }

        if (args.Length == 4 &&
            args[0] == "evidence" &&
            args[1] == "ingest")
        {
            var ingestDatabasePath =
                Path.GetFullPath(args[2]);

            var ingestSourcePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(ingestDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {ingestDatabasePath}");

                return 2;
            }

            if (!File.Exists(ingestSourcePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Evidence file not found: {ingestSourcePath}");

                return 2;
            }

            return await RunEvidenceIngestAsync(
                ingestDatabasePath,
                ingestSourcePath,
                ArtifactContentStoreFactory.Create(),
                global::System.Console.Out);
        }

        if (args.Length == 5 &&
            args[0] == "evidence" &&
            args[1] == "supersede")
        {
            var supersedeDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(supersedeDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {supersedeDatabasePath}");

                return 2;
            }

            return await RunEvidenceSupersedeAsync(
                supersedeDatabasePath,
                new ArtifactId(args[3]),
                new ArtifactId(args[4]),
                global::System.Console.Out);
        }

        if (args.Length == 6 &&
            args[0] == "evidence" &&
            args[1] == "clinical-note-record")
        {
            var clinicalNoteRecordDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(clinicalNoteRecordDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{clinicalNoteRecordDatabasePath}");
                return 2;
            }

            if (!DateOnly.TryParseExact(
                    args[4],
                    "yyyy-MM-dd",
                    out var noteRecordDate))
            {
                global::System.Console.Error.WriteLine(
                    "Clinical note record date must use yyyy-MM-dd.");
                return 2;
            }

            return await RunEvidenceClinicalNoteRecordAsync(
                clinicalNoteRecordDatabasePath,
                new ArtifactId(args[3]),
                noteRecordDate,
                args[5],
                contentStoreFactory(),
                global::System.Console.Out);
        }

        if (args.Length == 8 &&
            args[0] == "evidence" &&
            args[1] == "clinical-note")
        {
            var clinicalNoteDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(clinicalNoteDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{clinicalNoteDatabasePath}");
                return 2;
            }

            if (!int.TryParse(args[4], out var startPage) ||
                !int.TryParse(args[5], out var endPage) ||
                startPage <= 0 ||
                endPage < startPage)
            {
                global::System.Console.Error.WriteLine(
                    "Clinical note page range is invalid.");
                return 2;
            }

            if (!DateOnly.TryParseExact(
                    args[6],
                    "yyyy-MM-dd",
                    out var noteDate))
            {
                global::System.Console.Error.WriteLine(
                    "Clinical note date must use yyyy-MM-dd.");
                return 2;
            }

            return await RunEvidenceClinicalNoteAsync(
                clinicalNoteDatabasePath,
                new ArtifactId(args[3]),
                startPage,
                endPage,
                noteDate,
                args[7],
                contentStoreFactory(),
                global::System.Console.Out);
        }

        if (args.Length == 8 &&
            args[0] == "evidence" &&
            args[1] == "clarification" &&
            args[2] == "reviewer-correction")
        {
            var clarificationDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(clarificationDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{clarificationDatabasePath}");
                return 2;
            }

            return await RunEvidenceSourceClarificationReviewerCorrectionAsync(
                clarificationDatabasePath,
                new ClaimIssueId(args[4]),
                new SourceClarificationId(args[5]),
                args[6],
                args[7],
                global::System.Console.Out);
        }

        if (args.Length == 12 &&
            args[0] == "evidence" &&
            args[1] == "clarification")
        {
            var clarificationDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(clarificationDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{clarificationDatabasePath}");
                return 2;
            }

            if (!DateOnly.TryParseExact(
                    args[5],
                    "yyyy-MM-dd",
                    out var clarificationDate))
            {
                global::System.Console.Error.WriteLine(
                    "Source clarification date must use yyyy-MM-dd.");
                return 2;
            }

            if (!int.TryParse(args[6], out var clarificationStartPage) ||
                clarificationStartPage <= 0 ||
                !int.TryParse(args[7], out var clarificationEndPage) ||
                clarificationEndPage < clarificationStartPage)
            {
                global::System.Console.Error.WriteLine(
                    "Source clarification internal page range is invalid.");
                return 2;
            }

            return await RunEvidenceSourceClarificationAsync(
                clarificationDatabasePath,
                new ClaimIssueId(args[3]),
                new ArtifactId(args[4]),
                clarificationDate,
                clarificationStartPage,
                clarificationEndPage,
                args[8],
                args[9],
                args[10],
                args[11],
                global::System.Console.Out);
        }

        if (args.Length == 12 &&
            args[0] == "evidence" &&
            args[1] == "clinical" &&
            args[2] == "progression")
        {
            var progressionDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(progressionDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{progressionDatabasePath}");
                return 2;
            }

            if (!DateOnly.TryParseExact(
                    args[6],
                    "yyyy-MM-dd",
                    out var progressionDate))
            {
                global::System.Console.Error.WriteLine(
                    "Clinical progression date must use yyyy-MM-dd.");
                return 2;
            }

            int? progressionStartPage = null;
            int? progressionEndPage = null;

            var noProgressionPages =
                args[7] == "-" && args[8] == "-";

            if (!noProgressionPages)
            {
                if (!int.TryParse(args[7], out var parsedStartPage) ||
                    parsedStartPage <= 0 ||
                    !int.TryParse(args[8], out var parsedEndPage) ||
                    parsedEndPage < parsedStartPage)
                {
                    global::System.Console.Error.WriteLine(
                        "Clinical progression internal page range is invalid. " +
                        "Use '-' for both page arguments when the source is not paged.");
                    return 2;
                }

                progressionStartPage = parsedStartPage;
                progressionEndPage = parsedEndPage;
            }

            return await RunEvidenceClinicalProgressionAsync(
                progressionDatabasePath,
                new ClaimIssueId(args[4]),
                new ArtifactId(args[5]),
                progressionDate,
                progressionStartPage,
                progressionEndPage,
                args[9],
                args[10],
                args[11],
                global::System.Console.Out);
        }

        if (args.Length == 6 &&
            args[0] == "evidence" &&
            args[1] == "medication" &&
            args[2] == "ledger" &&
            args[3] == "current")
        {
            var currentMedicationLedgerDatabasePath =
                Path.GetFullPath(args[4]);

            if (!File.Exists(currentMedicationLedgerDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{currentMedicationLedgerDatabasePath}");
                return 2;
            }

            return await RunEvidenceCurrentMedicationLedgerAsync(
                currentMedicationLedgerDatabasePath,
                new VeteranId(args[5]),
                global::System.Console.Out);
        }

        if ((args.Length == 9 || args.Length == 10) &&
            args[0] == "evidence" &&
            args[1] == "medication" &&
            args[2] == "reconcile")
        {
            var reconciliationDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(reconciliationDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{reconciliationDatabasePath}");
                return 2;
            }

            if (!DateOnly.TryParseExact(
                    args[6],
                    "yyyy-MM-dd",
                    out var reconciliationDate))
            {
                global::System.Console.Error.WriteLine(
                    "Medication reconciliation date must use yyyy-MM-dd.");
                return 2;
            }

            return await RunEvidenceMedicationReconciliationAsync(
                reconciliationDatabasePath,
                new VeteranId(args[4]),
                new MedicationLedgerEntryId(args[5]),
                reconciliationDate,
                args[7],
                args[8],
                args.Length == 10 ? args[9] : null,
                global::System.Console.Out);
        }

        if (args.Length == 7 &&
            args[0] == "evidence" &&
            args[1] == "medication" &&
            args[2] == "ledger" &&
            args[3] == "import")
        {
            var medicationLedgerDatabasePath =
                Path.GetFullPath(args[4]);

            if (!File.Exists(medicationLedgerDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{medicationLedgerDatabasePath}");
                return 2;
            }

            return await RunEvidenceMedicationLedgerImportAsync(
                medicationLedgerDatabasePath,
                new VeteranId(args[5]),
                new ArtifactId(args[6]),
                contentStoreFactory(),
                global::System.Console.Out);
        }

        if (args.Length == 6 &&
            args[0] == "evidence" &&
            args[1] == "medication" &&
            args[2] == "basis")
        {
            var medicationBasisDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(medicationBasisDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{medicationBasisDatabasePath}");
                return 2;
            }

            return await RunEvidenceMedicationBasisAsync(
                medicationBasisDatabasePath,
                new ServiceConnectionBasisId(args[4]),
                args[5],
                global::System.Console.Out);
        }

        if (args.Length == 8 &&
            args[0] == "evidence" &&
            args[1] == "medication" &&
            args[2] == "context" &&
            args[3] == "supersede")
        {
            var contextSupersedeDatabasePath =
                Path.GetFullPath(args[4]);

            if (!File.Exists(contextSupersedeDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {contextSupersedeDatabasePath}");
                return 2;
            }

            return await RunEvidenceMedicationClinicalContextSupersedeAsync(
                contextSupersedeDatabasePath,
                new MedicationClinicalContextId(args[5]),
                new MedicationClinicalContextId(args[6]),
                args[7],
                global::System.Console.Out);
        }

        if ((args.Length == 13 || args.Length == 14) &&
            args[0] == "evidence" &&
            args[1] == "medication" &&
            args[2] == "context")
        {
            if (args.Length != 14)
            {
                global::System.Console.Error.WriteLine(
                    "Medication clinical context requires a human-readable record title.");
                return 2;
            }

            var contextDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(contextDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {contextDatabasePath}");
                return 2;
            }

            if (!DateOnly.TryParseExact(
                    args[6],
                    "yyyy-MM-dd",
                    out var contextEventDate))
            {
                global::System.Console.Error.WriteLine(
                    "Medication clinical context date must use yyyy-MM-dd.");
                return 2;
            }

            if (!int.TryParse(args[7], out var contextStartPage) ||
                contextStartPage <= 0 ||
                !int.TryParse(args[8], out var contextEndPage) ||
                contextEndPage < contextStartPage)
            {
                global::System.Console.Error.WriteLine(
                    "Medication clinical context page range is invalid.");
                return 2;
            }

            return await RunEvidenceMedicationClinicalContextAsync(
                contextDatabasePath,
                new VeteranId(args[4]),
                new ArtifactId(args[5]),
                contextEventDate,
                contextStartPage,
                contextEndPage,
                args[9],
                args[10],
                args[11],
                args[12],
                args[13],
                global::System.Console.Out);
        }

        if (args.Length == 9 && args[0] == "evidence" && args[1] == "medication" && args[2] == "indication")
        {
            if (!File.Exists(args[3]) || !DateOnly.TryParseExact(args[5], "yyyy-MM-dd", out var indicationDate))
            {
                global::System.Console.Error.WriteLine("Medication indication requires an existing database and yyyy-MM-dd date.");
                return 2;
            }
            return await RunEvidenceMedicationIndicationReconciliationAsync(
                Path.GetFullPath(args[3]), new VeteranId(args[4]), indicationDate,
                args[6], args[7], args[8], global::System.Console.Out);
        }

        if ((args.Length == 13 || args.Length == 14) &&
            args[0] == "evidence" &&
            args[1] == "medication" &&
            args[2] == "history")
        {
            var historyDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(historyDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {historyDatabasePath}");
                return 2;
            }

            if (!DateOnly.TryParseExact(
                    args[6],
                    "yyyy-MM-dd",
                    out var eventDate))
            {
                global::System.Console.Error.WriteLine(
                    "Medication history event date must use yyyy-MM-dd.");
                return 2;
            }

            if (!int.TryParse(args[7], out var historySourcePage) ||
                historySourcePage <= 0)
            {
                global::System.Console.Error.WriteLine(
                    "Medication history source page is invalid.");
                return 2;
            }

            string? OptionalHistory(string value) =>
                value == "-" ? null : value;

            return await RunEvidenceMedicationHistoryAsync(
                historyDatabasePath,
                new VeteranId(args[4]),
                new ArtifactId(args[5]),
                eventDate,
                historySourcePage,
                args[8],
                args[9],
                OptionalHistory(args[10]),
                OptionalHistory(args[11]),
                OptionalHistory(args[12]),
                args.Length == 14 ? OptionalHistory(args[13]) : null,
                global::System.Console.Out);
        }

        if (args.Length == 5 &&
            args[0] == "evidence" &&
            args[1] == "medication" &&
            args[2] == "current")
        {
            var medicationDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(medicationDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{medicationDatabasePath}");
                return 2;
            }

            return await RunEvidenceCurrentMedicationsAsync(
                medicationDatabasePath,
                new VeteranId(args[4]),
                global::System.Console.Out);
        }

        if ((args.Length == 12 || args.Length == 13) &&
            args[0] == "evidence" &&
            args[1] == "medication")
        {
            var medicationDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(medicationDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: " +
                    $"{medicationDatabasePath}");
                return 2;
            }

            if (!DateOnly.TryParseExact(
                    args[5],
                    "yyyy-MM-dd",
                    out var recordDate))
            {
                global::System.Console.Error.WriteLine(
                    "Medication record date must use yyyy-MM-dd.");
                return 2;
            }

            if (!int.TryParse(args[6], out var sourcePage) ||
                sourcePage <= 0)
            {
                global::System.Console.Error.WriteLine(
                    "Medication source page is invalid.");
                return 2;
            }

            string? Optional(string value) =>
                value == "-" ? null : value;

            return await RunEvidenceMedicationAsync(
                medicationDatabasePath,
                new VeteranId(args[3]),
                new ArtifactId(args[4]),
                recordDate,
                sourcePage,
                args[7],
                args[8],
                Optional(args[9]),
                Optional(args[10]),
                Optional(args[11]),
                args.Length == 13 ? Optional(args[12]) : null,
                global::System.Console.Out);
        }

        if (args.Length == 4 &&
            args[0] == "evidence" &&
            args[1] == "claim")
        {
            var claimDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(claimDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {claimDatabasePath}");

                return 2;
            }

            return await RunClaimEvidenceAsync(
                claimDatabasePath,
                new ClaimId(args[3]));
        }

        if (args.Length == 4 &&
            args[0] == "evidence" &&
            args[1] == "checklist")
        {
            var checklistDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(checklistDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {checklistDatabasePath}");

                return 2;
            }

            return await RunChecklistAsync(
                checklistDatabasePath,
                new ClaimIssueId(args[3]));
        }

        if (args.Length == 7 &&
            args[0] == "evidence" &&
            args[1] == "guidance")
        {
            var guidanceDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(guidanceDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {guidanceDatabasePath}");

                return 2;
            }

            return await RunGuidanceAsync(
                guidanceDatabasePath,
                new RequirementId(args[3]),
                args[4],
                args[5],
                args[6]);
        }

        ServiceConnectionBasisId? literatureBasisId = null;
        if (args.Length >= 3 && args[0] == "evidence" && args[1] == "literature" &&
            args[2] is "link" or "review" or "classify")
        {
            var basisOption = Array.IndexOf(args, "--basis");
            if (basisOption >= 0)
            {
                if (basisOption != args.Length - 2 ||
                    string.IsNullOrWhiteSpace(args[^1]) || args[^1] == "--basis")
                {
                    global::System.Console.Error.WriteLine("Use a single trailing --basis <basisId> option.");
                    return 1;
                }
                literatureBasisId = new ServiceConnectionBasisId(args[^1]);
                args = args[..basisOption];
            }
        }

        if (args.Length == 8 &&
            args[0] == "evidence" &&
            args[1] == "literature" &&
            args[2] == "link")
        {
            var literatureLinkDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(literatureLinkDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {literatureLinkDatabasePath}");

                return 2;
            }

            return await MedicalLiteratureConsoleCommand.RunLinkAsync(
                literatureLinkDatabasePath,
                new RequirementId(args[4]),
                new MedicalLiteratureSourceId(args[5]),
                args[6],
                args[7],
                literatureBasisId);
        }


        if (args.Length >= 12 &&
            args[0] == "evidence" &&
            args[1] == "literature" &&
            args[2] == "review" &&
            args[3] == "--supersede")
        {
            var reviewedBy =
                Environment.GetEnvironmentVariable("EMF_REVIEWED_BY");

            if (string.IsNullOrWhiteSpace(reviewedBy))
            {
                global::System.Console.Error.WriteLine(
                    "Medical literature human review requires review. " +
                    "Set EMF_REVIEWED_BY to the reviewer identity.");
                return 1;
            }

            var literatureReviewDatabasePath =
                Path.GetFullPath(args[5]);

            if (!File.Exists(literatureReviewDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {literatureReviewDatabasePath}");
                return 2;
            }

            var excerptOrdinals = new List<int>();

            foreach (var value in args[11..])
            {
                if (!int.TryParse(value, out var ordinal) ||
                    ordinal < 0)
                {
                    global::System.Console.Error.WriteLine(
                        $"Invalid reviewed literature excerpt ordinal: {value}");
                    return 1;
                }

                excerptOrdinals.Add(ordinal);
            }

            return await MedicalLiteratureConsoleCommand
                .RunReviewSupersedeAsync(
                    literatureReviewDatabasePath,
                    new MedicalLiteratureSourceId(args[6]),
                    new ArtifactId(args[7]),
                    new RequirementId(args[8]),
                    args[4],
                    args[9],
                    args[10],
                    excerptOrdinals,
                    reviewedBy,
                    global::System.Console.Out,
                    literatureBasisId);
        }


        var supersedeLiteratureClassification =
            args.Length >= 9 &&
            args[0] == "evidence" &&
            args[1] == "literature" &&
            args[2] == "classify" &&
            args[3] == "--supersede";

        var promoteLiteratureClassification =
            !supersedeLiteratureClassification &&
            args.Length >= 8 &&
            args[0] == "evidence" &&
            args[1] == "literature" &&
            args[2] == "classify" &&
            args[3] == "--promote";

        var persistLiteratureClassification =
            promoteLiteratureClassification ||
            supersedeLiteratureClassification;

        var literatureArgOffset =
            supersedeLiteratureClassification
                ? 2
                : promoteLiteratureClassification ? 1 : 0;

        if (args.Length >= 7 + literatureArgOffset &&
            args[0] == "evidence" &&
            args[1] == "literature" &&
            args[2] == "classify")
        {
            var literatureClassifyDatabasePath =
                Path.GetFullPath(args[3 + literatureArgOffset]);

            if (!File.Exists(literatureClassifyDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {literatureClassifyDatabasePath}");
                return 2;
            }

            var reviewedBy =
                Environment.GetEnvironmentVariable("EMF_REVIEWED_BY");

            if (persistLiteratureClassification &&
                string.IsNullOrWhiteSpace(reviewedBy))
            {
                global::System.Console.Error.WriteLine(
                    "Medical literature promotion requires review. " +
                    "Set EMF_REVIEWED_BY to the reviewer identity.");
                return 1;
            }

            var supersedesCorrelationId =
                supersedeLiteratureClassification
                    ? args[4]
                    : null;

            return await MedicalLiteratureConsoleCommand.RunClassifyAsync(
                literatureClassifyDatabasePath,
                new MedicalLiteratureSourceId(args[4 + literatureArgOffset]),
                new ArtifactId(args[5 + literatureArgOffset]),
                args[(6 + literatureArgOffset)..]
                    .Select(id => new RequirementId(id))
                    .ToArray(),
                runtimeFactory,
                contentStoreFactory(),
                global::System.Console.Out,
                persistLiteratureClassification,
                reviewedBy,
                supersedesCorrelationId,
                literatureBasisId);
        }

        if (args.Length == 6 &&
            args[0] == "evidence" &&
            args[1] == "literature" &&
            args[2] == "artifact")
        {
            var literatureArtifactDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(literatureArtifactDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {literatureArtifactDatabasePath}");
                return 2;
            }

            return await MedicalLiteratureConsoleCommand.RunArtifactAsync(
                literatureArtifactDatabasePath,
                new MedicalLiteratureSourceId(args[4]),
                new ArtifactId(args[5]));
        }

        if (args.Length == 5 &&
            args[0] == "evidence" &&
            args[1] == "literature" &&
            args[2] == "source")
        {
            var literatureDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(literatureDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {literatureDatabasePath}");

                return 2;
            }

            var sourcePath =
                Path.GetFullPath(args[4]);

            if (!File.Exists(sourcePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Medical literature source file not found: {sourcePath}");

                return 2;
            }

            return await MedicalLiteratureConsoleCommand.RunSourceAsync(
                literatureDatabasePath,
                sourcePath);
        }

        if (args.Length == 6 &&
            args[0] == "evidence" &&
            args[1] == "classify")
        {
            var classifyDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(classifyDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {classifyDatabasePath}");

                return 2;
            }

            return await RunClassifyAsync(
                classifyDatabasePath,
                new ClaimIssueId(args[3]),
                new ArtifactId(args[4]),
                args[5]);
        }

        if (args.Length == 6 &&
            args[0] == "evidence" &&
            args[1] == "package" &&
            args[2] == "add")
        {
            var db = Path.GetFullPath(args[3]);
            if (!File.Exists(db))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {db}");
                return 2;
            }

            return await RunEvidencePackageAddAsync(
                db,
                new EvidencePackageId(args[4]),
                new ArtifactId(args[5]),
                global::System.Console.Out);
        }

        if (args.Length == 7 &&
            args[0] == "evidence" &&
            args[1] == "package" &&
            args[2] == "pages")
        {
            var packageDatabasePath =
                Path.GetFullPath(args[3]);

            if (!File.Exists(packageDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {packageDatabasePath}");

                return 2;
            }

            return await RunEvidencePackagePagesAsync(
                packageDatabasePath,
                new EvidencePackageId(args[4]),
                new ArtifactId(args[5]),
                args[6],
                global::System.Console.Out);
        }

        if (args.Length == 4 &&
            args[0] == "evidence" &&
            args[1] == "package")
        {
            var packageDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(packageDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {packageDatabasePath}");

                return 2;
            }

            return await RunEvidencePackageAsync(
                packageDatabasePath,
                new EvidencePackageId(args[3]),
                global::System.Console.Out);
        }

        if ((args.Length == 5 ||
             (args.Length == 7 && args[4] == "--format")) &&
            args[0] == "evidence" &&
            args[1] == "package")
        {
            var packageDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(packageDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {packageDatabasePath}");

                return 2;
            }

            VeteransReviewerPackageOutputRequest packageOutput;

            try
            {
                packageOutput =
                    VeteransReviewerPackageOutputRequestResolver.Resolve(
                        args.Length == 5 ? args[4] : args[6],
                        args.Length == 7 ? args[5] : null);
            }
            catch (InvalidOperationException ex)
            {
                global::System.Console.Error.WriteLine(
                    ConsoleTextSanitizer.Sanitize(ex.Message));
                return 2;
            }

            return await RunEvidencePackageDocumentAsync(
                packageDatabasePath,
                new EvidencePackageId(args[3]),
                packageOutput);
        }

        if (args.Length == 4 &&
            args[0] == "evidence" &&
            args[1] == "plan")
        {
            var planDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(planDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {planDatabasePath}");

                return 2;
            }

            return await RunEvidenceDevelopmentPlanAsync(
                planDatabasePath,
                new EvidenceDevelopmentPlanId(args[3]),
                global::System.Console.Out);
        }

        if (args.Length == 5 &&
            args[0] == "evidence" &&
            args[1] == "prepare")
        {
            var prepareDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(prepareDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {prepareDatabasePath}");

                return 2;
            }

            return await RunPrepareAsync(
                prepareDatabasePath,
                new ClaimIssueId(args[3]),
                new EvidenceDevelopmentPlanId(args[4]));
        }

        if (args.Length == 4 &&
            args[0] == "evidence" &&
            args[1] == "execute")
        {
            var executeDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(executeDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {executeDatabasePath}");

                return 2;
            }

            return await RunExecuteAsync(
                executeDatabasePath,
                new EvidenceDevelopmentPlanId(args[3]));
        }

        if (args.Length == 3 &&
            args[0] == "pap" &&
            args[1] == "analyze")
        {
            var papSourcePath = Path.GetFullPath(args[2]);

            if (!File.Exists(papSourcePath))
            {
                global::System.Console.Error.WriteLine(
                    $"PAP source not found: {papSourcePath}");
                return 2;
            }

            return RunPapAnalysis(papSourcePath);
        }

        if (args.Length >= 4 &&
            args[0] == "evidence" &&
            args[1] == "reviewer")
        {
            var reviewerDatabasePath =
                Path.GetFullPath(args[2]);

            if (!File.Exists(reviewerDatabasePath))
            {
                global::System.Console.Error.WriteLine(
                    $"Veterans Claims database not found: {reviewerDatabasePath}");

                return 2;
            }

            if (!VeteransReviewerPackageCommandOptionsParser.TryParse(
                    args,
                    out var reviewerOptions,
                    out var reviewerOptionsError))
            {
                global::System.Console.Error.WriteLine(
                    ConsoleTextSanitizer.Sanitize(
                        reviewerOptionsError ??
                        "Reviewer command options are invalid."));

                return 2;
            }

            return await RunReviewerPackageAsync(
                reviewerDatabasePath,
                new ClaimIssueId(args[3]),
                runtimeFactory,
                contentStoreFactory,
                reviewerOptions!.Output,
                reviewerOptions.BasisId);
        }

        var summarize =
            args.Length >= 6 &&
            args[0] == "evidence" &&
            args[1] == "develop" &&
            args[2] == "--summarize";

        var promote =
            summarize &&
            args.Length == 7 &&
            args[3] == "--promote";

        if ((!summarize && args.Length != 5) ||
            (summarize && !promote && args.Length != 6) ||
            (summarize && promote && args.Length != 7) ||
            args[0] != "evidence" ||
            args[1] != "develop")
        {
            ShowUsage();
            return 2;
        }

        var offset =
            summarize
                ? promote ? 2 : 1
                : 0;

        var databasePath =
            Path.GetFullPath(args[2 + offset]);

        if (!File.Exists(databasePath))
        {
            global::System.Console.Error.WriteLine(
                $"Veterans Claims database not found: {databasePath}");

            return 2;
        }

        var planId =
            new EvidenceDevelopmentPlanId(args[3 + offset]);

        var evidenceGapId =
            new EvidenceGapId(args[4 + offset]);

        if (promote &&
            string.IsNullOrWhiteSpace(
                Environment.GetEnvironmentVariable(
                    "EMF_REVIEWED_BY")))
        {
            global::System.Console.Error.WriteLine(
                "Evidence promotion requires review. " +
                "Set EMF_REVIEWED_BY to the reviewer identity.");

            return 1;
        }

        var workflowRepository =
            new SqliteWorkflowRepository(databasePath);

        await workflowRepository.InitializeAsync();

        var workflowService =
            new WorkflowService(workflowRepository);

        var workflowRunner =
            new WorkflowRunner(workflowService);

        var developmentRepository =
            new SqliteEvidenceDevelopmentPlanRepository(
                databasePath);

        await developmentRepository.InitializeAsync();

        var gapRepository =
            new SqliteEvidenceGapRepository(databasePath);

        var guidanceRepository =
            new SqliteEvidenceRequirementGuidanceRepository(
                databasePath);

        var contentStore =
            ArtifactContentStoreFactory.Create();

        IEvidenceDevelopmentWorkflowCoordinator coordinator;

        if (contentStore is null)
        {
            coordinator =
                VeteransEvidenceOrchestrationFactory
                    .CreateEvidenceDevelopmentWorkflowCoordinator(
                        workflowService,
                        developmentRepository,
                        workflowRunner,
                        gapRepository,
                        guidanceRepository);
        }
        else
        {
            var evidenceRepository =
                new SqliteEvidenceRepository(databasePath);

            await evidenceRepository.InitializeAsync();

            var textExtractor =
                ArtifactTextExtractionFactory.Create(
                    evidenceRepository,
                    contentStore);

            var recognitionTerms =
                new SqliteEvidenceRecognitionTermRepository(
                    databasePath);

            var classifications =
                new SqliteEvidenceClassificationRepository(
                    databasePath);

            var classificationService =
                new EvidenceClassificationService(
                    classifications,
                    new GuidIdGenerator());

            coordinator =
                VeteransEvidenceOrchestrationFactory
                    .CreateEvidenceDevelopmentWorkflowCoordinator(
                        workflowService,
                        developmentRepository,
                        workflowRunner,
                        gapRepository,
                        guidanceRepository,
                        textExtractor,
                        recognitionTerms,
                        classificationService);
        }

        try
        {
            var execution =
                await coordinator.StartAsync(
                    planId,
                    evidenceGapId);

            var result =
                await developmentRepository
                    .GetEvidenceDevelopmentResultAsync(
                        evidenceGapId);

            if (result is null)
            {
                global::System.Console.Error.WriteLine(
                    "Evidence development completed without a persisted result.");

                return 1;
            }

            global::System.Console.WriteLine(
                $"Workflow ID : {execution.WorkflowId.Value}");

            global::System.Console.WriteLine(
                $"Plan ID     : {execution.EvidenceDevelopmentPlanId.Value}");

            global::System.Console.WriteLine(
                $"Evidence Gap: {result.EvidenceGapId.Value}");

            global::System.Console.WriteLine(
                $"Requirement : {result.RequirementId.Value}");

            global::System.Console.WriteLine(
                $"Guidance    : {result.EvidenceGuidance.Count}");

            if (summarize)
            {
                var runtime =
                    await runtimeFactory();

                var intelligenceCoordinator =
                    VeteransEvidenceOrchestrationFactory.CreateEvidenceDevelopmentIntelligenceCoordinator(
                        developmentRepository,
                        gapRepository,
                        runtime.TextSummarizationCapabilityExecutor);

                var intelligenceResult =
                    await intelligenceCoordinator.SummarizeAsync(
                        planId,
                        evidenceGapId,
                        new IntelligenceExecutionContext(
                            runtime.SubjectId,
                            new IntelligenceCorrelationId(
                                $"veterans-{Guid.NewGuid():N}"),
                            runtime.ClassificationId,
                            Array.Empty<ArtifactId>()));

                if (!intelligenceResult.Success)
                {
                    global::System.Console.Error.WriteLine(
                        ConsoleTextSanitizer.Sanitize(
                            intelligenceResult.Message ??
                            "Evidence development summarization failed."));

                    return 1;
                }

                global::System.Console.WriteLine();
                global::System.Console.WriteLine("Summary");
                global::System.Console.WriteLine("-------");
                global::System.Console.WriteLine(
                    ConsoleTextSanitizer.Sanitize(
                        intelligenceResult.Output));

                if (promote)
                {
                    var plan =
                        await developmentRepository
                            .GetEvidenceDevelopmentPlanAsync(planId);

                    if (plan is null)
                    {
                        global::System.Console.Error.WriteLine(
                            $"Evidence development plan not found: {planId.Value}");
                        return 1;
                    }

                    var prepared =
                        await VeteransReviewerPackagePublisher.PublishAsync(
                            databasePath,
                            plan.ClaimIssueId,
                            "Physician reviewer package",
                            "MedicalProfessional",
                            $"Evidence gap {evidenceGapId.Value} summary",
                            runtime.SubjectId,
                            Environment.GetEnvironmentVariable("EMF_REVIEWED_BY")!,
                            DateTimeOffset.UtcNow,
                            evidenceGapId,
                            result.RequirementId,
                            intelligenceResult);

                    global::System.Console.WriteLine();
                    global::System.Console.WriteLine("Promoted and Packaged");
                    global::System.Console.WriteLine("---------------------");
                    global::System.Console.WriteLine(
                        $"Summary Artifact ID : {prepared.SummaryArtifact.Id.Value}");
                    global::System.Console.WriteLine(
                        $"Package ID          : {prepared.Package.Id.Value}");
                }

            }

            return 0;
        }
        catch (Exception ex)
        {
            global::System.Console.Error.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    $"Evidence development failed: {ex.Message}"));

            return 1;
        }
    }

    internal static async Task<int>
        RunClaimAdjudicationAssessmentAsync(
            string databasePath,
            ClaimId claimId,
            TextWriter output)
    {
        var claims =
            new SqliteClaimRepository(databasePath);

        var issues =
            new SqliteClaimIssueRepository(databasePath);

        var service =
            new ClaimAdjudicationAssessmentService(
                claims,
                issues,
                CreateAdjudicationAssessmentService(
                    databasePath));

        var timeline =
            new ClaimAdjudicationTimelineService(
                issues,
                new ClaimIssueAdjudicationTimelineService(
                    new ClaimIssueAdjudicationLifecycleService(
                        new SqliteVaDecisionRepository(databasePath),
                        new SqliteSubmissionRepository(databasePath)),
                    new SqliteClaimIssueCourtAppealRepository(
                        databasePath)));

        var result =
            await service.GetAsync(claimId);

        if (result is null)
        {
            global::System.Console.Error.WriteLine(
                $"Claim not found: {claimId.Value}");

            return 1;
        }

        ArgumentNullException.ThrowIfNull(output);

        output.WriteLine(
            $"Claim       : {result.Claim.Id.Value}");

        output.WriteLine(
            $"Issues      : {result.IssueCount}");

        output.WriteLine(
            $"Ready       : {result.ReadyIssueCount}");

        output.WriteLine(
            $"Blocked     : {result.BlockedIssueCount}");

        output.WriteLine(
            $"Recommended : {result.RecommendedIssueCount}");

        output.WriteLine(
            $"Decisions   : {result.CurrentDecisionCount}");

        output.WriteLine(
            $"Denied      : {result.DeniedIssueCount}");

        output.WriteLine(
            $"Granted     : {result.GrantedIssueCount}");

        output.WriteLine(
            $"Deferred    : {result.DeferredIssueCount}");

        output.WriteLine(
            $"Partial     : {result.PartiallyGrantedIssueCount}");

        output.WriteLine(
            $"Undecided   : {result.UndecidedIssueCount}");

        output.WriteLine(
            $"Reviews     : {result.ReviewedDecisionCount}");

        output.WriteLine(
            $"Review Req  : {result.ReviewRequiredCount}");

        output.WriteLine(
            $"Attention   : {result.RequiresAttention} " +
            $"({result.AttentionIssueCount} issue(s))");

        output.WriteLine(
            $"Follow Up   : {result.ShouldConsiderFollowUp} " +
            $"({result.FollowUpIssueCount} issue(s))");

        foreach (var issue in result.Issues)
        {
            output.WriteLine(
                $"Issue       : " +
                $"{issue.Details.ClaimIssue.Id.Value}");

            output.WriteLine(
                $"  Ready     : " +
                $"{issue.Readiness.IsReadyForAdjudication}");

            output.WriteLine(
                $"  Attention : " +
                $"{issue.RequiresAttention}");

            output.WriteLine(
                $"  Follow Up : " +
                $"{issue.ShouldConsiderFollowUp}");

            output.WriteLine(
                $"  Merits    : " +
                $"{issue.Merits?.Outcome ?? "None"}");

            output.WriteLine(
                $"  Recommend : " +
                $"{issue.Recommendation?.RecommendedOutcome ?? "None"}");

            output.WriteLine(
                $"  Current   : " +
                $"{issue.CurrentDecision?.IssueDecision.Outcome ?? "None"}");

            output.WriteLine(
                $"  Reviews   : " +
                $"{issue.DecisionReviewHistory.Count}");

            output.WriteLine(
                $"  Review Req: " +
                $"{issue.DecisionReviewHistory.Count(
                    x => x.Review.RequiresReview)}");
        }

        var timelineEvents =
            await timeline.GetAsync(claimId);

        output.WriteLine(
            $"Timeline    : {timelineEvents.Count}");

        foreach (var item in timelineEvents)
        {
            output.WriteLine(
                $"- {item.OccurredAt:O} " +
                $"{item.ClaimIssueId.Value} " +
                $"{item.EventType}" +
                (item.Outcome is null
                    ? string.Empty
                    : $" [{item.Outcome}]") +
                (item.Description is null
                    ? string.Empty
                    : $": {item.Description}"));
        }

        return 0;
    }


    private static ClaimIssueDecisionReviewHistoryService
        CreateReviewHistoryService(
            string databasePath)
    {
        var repository =
            new SqliteVaDecisionRepository(databasePath);

        return new ClaimIssueDecisionReviewHistoryService(
            new ClaimIssueDecisionComparisonHistoryService(
                repository,
                new ClaimIssueDecisionComparisonService()),
            new ClaimIssueDecisionReviewService(),
            new ClaimIssueDecisionReviewAnalysisService());
    }


    private static async Task<int> RunReviewerPackageAsync(
        string databasePath,
        ClaimIssueId claimIssueId,
        Func<Task<TextSummarizationConsoleRuntime>> runtimeFactory,
        Func<IArtifactContentStore?> contentStoreFactory,
        VeteransReviewerPackageOutputRequest? outputRequest,
        string? basisId = null)
    {
        static void OperatorStatus(
            string area,
            string message)
        {
            global::System.Console.WriteLine(
                $"{DateTimeOffset.UtcNow:HH:mm:ss} UTC  " +
                $"{area,-8}  " +
                ConsoleTextSanitizer.Sanitize(message));

            global::System.Console.Out.Flush();
        }

        static void WriteReviewerAiCostSummary(
            IReadOnlyList<IntelligenceExecutionMetadata> executions,
            bool reusedPackage)
        {
            var inputTokens =
                executions.Sum(
                    item => (long)(item.InputTokenCount ?? 0));

            var outputTokens =
                executions.Sum(
                    item => (long)(item.OutputTokenCount ?? 0));

            var totalTokens =
                executions.Sum(
                    item => (long)(item.TotalTokenCount ?? 0));

            var estimatedCost =
                executions.Sum(
                    item => item.EstimatedCostUsd ?? 0m);

            var providers =
                executions
                    .Select(item => item.ProviderId.Value)
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .Distinct(StringComparer.Ordinal)
                    .ToArray();

            var engines =
                executions
                    .Select(item => item.EngineName)
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .Distinct(StringComparer.Ordinal)
                    .ToArray();

            global::System.Console.WriteLine();
            global::System.Console.WriteLine(
                "===== AI COST SUMMARY =====");
            global::System.Console.WriteLine(
                $"Reviewer summary calls : {executions.Count}");
            global::System.Console.WriteLine(
                $"Input tokens           : {inputTokens}");
            global::System.Console.WriteLine(
                $"Output tokens          : {outputTokens}");
            global::System.Console.WriteLine(
                $"Total tokens           : {totalTokens}");
            global::System.Console.WriteLine(
                "Estimated cost         : $" +
                estimatedCost.ToString(
                    "0.00000",
                    System.Globalization.CultureInfo.InvariantCulture));
            global::System.Console.WriteLine(
                $"Reused summaries       : {(reusedPackage ? 1 : 0)}");
            global::System.Console.WriteLine(
                $"New AI summaries       : {(reusedPackage ? 0 : 1)}");
            global::System.Console.WriteLine(
                $"Reused package         : {(reusedPackage ? "Yes" : "No")}");
            global::System.Console.WriteLine(
                "AI provider            : " +
                (providers.Length == 0
                    ? "Not invoked"
                    : string.Join(", ", providers)));
            global::System.Console.WriteLine(
                "Model                  : " +
                (engines.Length == 0
                    ? "Not invoked"
                    : string.Join(", ", engines)));
        }

        OperatorStatus(
            "REVIEWER",
            $"Starting reviewer package for {claimIssueId.Value}");

        OperatorStatus(
            "EVIDENCE",
            "Loading claim issue details");

        var details =
            await CreateAdjudicationDetailsService(databasePath)
                .GetAsync(claimIssueId);

        if (details is null)
        {
            global::System.Console.Error.WriteLine(
                $"Claim issue not found: {claimIssueId.Value}");

            return 1;
        }

        var classifications =
            await new SqliteEvidenceClassificationRepository(
                    databasePath)
                .GetEvidenceClassificationsAsync(claimIssueId);

        var hasRequirementLiterature =
            details.Requirements.Any(
                requirement =>
                    requirement.MedicalLiterature.Count > 0);

        if (classifications.Count == 0 &&
            !hasRequirementLiterature)
        {
            global::System.Console.Error.WriteLine(
                $"No reviewer evidence found for claim issue: {claimIssueId.Value}");

            return 1;
        }

        var contentStore =
            contentStoreFactory();

        if (contentStore is null)
            throw new InvalidOperationException(
                "Artifact content store is not configured.");

        var evidenceRepository =
            new SqliteEvidenceRepository(databasePath);

        await evidenceRepository.InitializeAsync();

        var textExtractor =
            ArtifactTextExtractionFactory.Create(
                evidenceRepository,
                contentStore);

        var developmentRepository =
            new SqliteEvidenceDevelopmentPlanRepository(
                databasePath);

        await developmentRepository.InitializeAsync();

        var gapRepository =
            new SqliteEvidenceGapRepository(databasePath);

        var developmentDetails =
            await new VeteransReviewerEvidenceDevelopmentDetailsService(
                    developmentRepository,
                    gapRepository)
                .GetAsync(claimIssueId);

        ServiceConnectionBasisId? requestedBasisId =
            string.IsNullOrWhiteSpace(basisId)
                ? null
                : new ServiceConnectionBasisId(basisId);

        if (!requestedBasisId.HasValue && hasRequirementLiterature)
        {
            if (details.ServiceConnectionBases.Count != 1)
            {
                global::System.Console.Error.WriteLine(
                    "Reviewer medical literature requires an explicit --basis selection " +
                    "when the claim issue does not have exactly one service-connection basis.");
                return 1;
            }

            requestedBasisId = details.ServiceConnectionBases.Single().Id;
        }

        var evidenceSourceDetails = details;

        if (requestedBasisId.HasValue)
        {
            try
            {
                var scope =
                    await new VeteransReviewerPackageBasisScopeService(
                            developmentRepository,
                            gapRepository)
                        .ScopeAsync(
                            details,
                            developmentDetails,
                            requestedBasisId.Value);

                details = scope.Details;
                developmentDetails = scope.DevelopmentDetails;
            }
            catch (InvalidOperationException ex)
            {
                global::System.Console.Error.WriteLine(
                    ConsoleTextSanitizer.Sanitize(ex.Message));
                return 1;
            }
        }

        var medicalLiteratureRepository =
            new SqliteMedicalLiteratureRepository(
                databasePath);

        await medicalLiteratureRepository.InitializeAsync();

        OperatorStatus(
            "EXTRACT",
            "Extracting reviewer evidence sources");

        var evidenceSourceService =
            new VeteransReviewerEvidenceSourceService(
                evidenceRepository,
                medicalLiteratureRepository,
                textExtractor);

        var evidenceSources =
            requestedBasisId.HasValue
                ? await evidenceSourceService.GetAsync(
                    evidenceSourceDetails,
                    classifications,
                    requestedBasisId.Value)
                : await evidenceSourceService.GetAsync(
                    details,
                    classifications);

        OperatorStatus(
            "EVIDENCE",
            $"{evidenceSources.Count} source artifact(s) ready");

        var sourceArtifactIds =
            evidenceSources
                .Select(x => x.ArtifactId)
                .ToArray();

        if (sourceArtifactIds.Length == 0)
        {
            global::System.Console.Error.WriteLine(
                $"No reviewer evidence found for claim issue: {claimIssueId.Value}");

            return 1;
        }

        var recognitionTermRepository =
            new SqliteEvidenceRecognitionTermRepository(
                databasePath);

        await recognitionTermRepository.InitializeAsync();

        var reviewerRequirementIds =
            details.Requirements
                .Select(item => item.Requirement.Id)
                .Distinct()
                .OrderBy(id => id.Value, StringComparer.Ordinal)
                .ToArray();

        var reviewerRecognitionTerms =
            new List<EvidenceRecognitionTerm>();

        foreach (var requirementId in reviewerRequirementIds)
        {
            reviewerRecognitionTerms.AddRange(
                await recognitionTermRepository
                    .GetEvidenceRecognitionTermsAsync(
                        requirementId));
        }

        var clinicalProgressionRepository =
            new SqliteClinicalProgressionRepository(databasePath);

        await clinicalProgressionRepository.InitializeAsync();

        var sourceArtifactIdSet =
            sourceArtifactIds.ToHashSet();

        var reviewerClinicalProgression =
            (await clinicalProgressionRepository.GetAsync(claimIssueId))
                .Where(item => sourceArtifactIdSet.Contains(item.SourceArtifactId))
                .ToArray();

        var reviewerReuseKey =
            VeteransReviewerPackageIntelligenceService
                .CreateReuseKey(
                    details,
                    evidenceSources,
                    developmentDetails,
                    reviewerRecognitionTerms,
                    reviewerClinicalProgression);

        var packageRepository =
            new SqliteEvidencePackageRepository(
                databasePath);

        var expectedSourceArtifactIds =
            sourceArtifactIds.ToHashSet();

        EvidencePackageId? reusablePackageId = null;

        foreach (var package in
                 await packageRepository
                     .GetEvidencePackagesAsync(claimIssueId))
        {
            if (!string.Equals(
                    package.Purpose,
                    "Physician reviewer package",
                    StringComparison.Ordinal) ||
                !string.Equals(
                    package.ReviewerRole,
                    "MedicalProfessional",
                    StringComparison.Ordinal) ||
                package.ServiceConnectionBasisId != requestedBasisId)
            {
                continue;
            }

            var packageArtifacts =
                await packageRepository
                    .GetEvidencePackageArtifactsAsync(
                        package.Id);

            var packageSourceArtifactIds =
                packageArtifacts
                    .Where(
                        artifact =>
                            string.Equals(
                                artifact.ContentRole,
                                EvidencePackageContentRoles
                                    .UnderlyingEvidence,
                                StringComparison.Ordinal))
                    .Select(artifact => artifact.ArtifactId)
                    .ToHashSet();

            if (!packageSourceArtifactIds
                    .SetEquals(expectedSourceArtifactIds))
            {
                continue;
            }

            foreach (var generatedArtifact in
                     packageArtifacts.Where(
                         artifact =>
                             string.Equals(
                                 artifact.ContentRole,
                                 EvidencePackageContentRoles
                                     .GeneratedOrganizationalMaterial,
                                 StringComparison.Ordinal)))
            {
                var summaryArtifact =
                    await evidenceRepository.GetArtifactAsync(
                        generatedArtifact.ArtifactId);

                if (summaryArtifact is null ||
                    !summaryArtifact.Metadata.TryGetValue(
                        "reviewerSummaryReuseKey",
                        out var storedReuseKey) ||
                    !string.Equals(
                        storedReuseKey?.ToString(),
                        reviewerReuseKey,
                        StringComparison.Ordinal))
                {
                    continue;
                }

                var provenance =
                    await evidenceRepository.GetProvenanceAsync(
                        generatedArtifact.ArtifactId);

                var reviewed =
                    provenance.Any(
                        item =>
                            string.Equals(
                                item.Source,
                                "EMF.Intelligence",
                                StringComparison.Ordinal) &&
                            item.Properties is not null &&
                            item.Properties.TryGetValue(
                                "reviewedBy",
                                out var reviewedByValue) &&
                            !string.IsNullOrWhiteSpace(
                                reviewedByValue?.ToString()));

                if (!reviewed)
                    continue;

                reusablePackageId = package.Id;
                break;
            }

            if (reusablePackageId.HasValue)
                break;
        }

        if (reusablePackageId.HasValue)
        {
            OperatorStatus(
                "REUSE",
                "Reusing reviewed reviewer package; Azure OpenAI not invoked");

            global::System.Console.WriteLine(
                $"Package ID          : {reusablePackageId.Value.Value}");

            WriteReviewerAiCostSummary(
                Array.Empty<IntelligenceExecutionMetadata>(),
                reusedPackage: true);

            if (outputRequest is null)
            {
                OperatorStatus(
                    "COMPLETE",
                    "Reviewer package complete");

                return 0;
            }

            OperatorStatus(
                "EXPORT",
                $"Creating reviewer document output ({outputRequest.Format}) from reviewed package");

            var reusedExportExitCode =
                await RunEvidencePackageDocumentAsync(
                    databasePath,
                    reusablePackageId.Value,
                    outputRequest,
                    contentStore);

            if (reusedExportExitCode != 0)
                return reusedExportExitCode;

            WriteReviewerOutputPaths(outputRequest);

            OperatorStatus(
                "COMPLETE",
                "Reviewer document output created");

            return 0;
        }

        var reviewedBy =
            Environment.GetEnvironmentVariable(
                "EMF_REVIEWED_BY");

        if (string.IsNullOrWhiteSpace(reviewedBy))
        {
            global::System.Console.Error.WriteLine(
                "Creating and promoting a new reviewer summary requires review. " +
                "Set EMF_REVIEWED_BY to the reviewer identity.");

            return 1;
        }

        global::System.Console.WriteLine();
        global::System.Console.WriteLine(
            "===== USES AZURE OPENAI — PAID =====");

        OperatorStatus(
            "AI",
            "Initializing Azure OpenAI runtime");

        var runtime =
            await runtimeFactory();

        var intelligence =
            VeteransEvidenceOrchestrationFactory
                .CreateReviewerPackageIntelligenceService(
                    runtime.TextSummarizationCapabilityExecutor,
                    recognitionTermRepository);

        OperatorStatus(
            "AI",
            "Starting reviewer summarization");

        var result =
            await intelligence.SummarizeAsync(
                details,
                evidenceSources,
                developmentDetails,
                new IntelligenceExecutionContext(
                    runtime.SubjectId,
                    new IntelligenceCorrelationId(
                        $"veterans-{Guid.NewGuid():N}"),
                    runtime.ClassificationId,
                    sourceArtifactIds));

        OperatorStatus(
            "AI",
            "Reviewer summarization complete");

        WriteReviewerAiCostSummary(
            result.CapabilityExecutions,
            reusedPackage: false);

        if (!result.Success)
        {
            global::System.Console.Error.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    result.Message ??
                    "Reviewer package summarization failed."));

            return 1;
        }

        OperatorStatus(
            "PACKAGE",
            "Publishing reviewer package");

        var prepared =
            await VeteransReviewerPackagePublisher.PublishAsync(
                databasePath,
                claimIssueId,
                "Physician reviewer package",
                "MedicalProfessional",
                $"Claim issue {claimIssueId.Value} reviewer summary",
                runtime.SubjectId,
                reviewedBy,
                DateTimeOffset.UtcNow,
                result,
                requestedBasisId);

        await evidenceRepository.MergeArtifactMetadataAsync(
            prepared.SummaryArtifact.Id,
            new Dictionary<string, object>
            {
                ["reviewerSummaryReuseKey"] = reviewerReuseKey
            });

        global::System.Console.WriteLine(
            ConsoleTextSanitizer.Sanitize(
                result.Output));

        global::System.Console.WriteLine(
            $"Summary Artifact ID : {prepared.SummaryArtifact.Id.Value}");

        global::System.Console.WriteLine(
            $"Package ID          : {prepared.Package.Id.Value}");

        OperatorStatus(
            "PACKAGE",
            "Reviewer package persisted");

        if (outputRequest is null)
        {
            OperatorStatus(
                "COMPLETE",
                "Reviewer package complete");

            return 0;
        }

        OperatorStatus(
            "EXPORT",
            $"Creating reviewer document output ({outputRequest.Format})");

        var exportExitCode =
            await RunEvidencePackageDocumentAsync(
                databasePath,
                prepared.Package.Id,
                outputRequest,
                contentStore);

        if (exportExitCode != 0)
            return exportExitCode;

        WriteReviewerOutputPaths(outputRequest);

        OperatorStatus(
            "COMPLETE",
            "Reviewer document output created");

        return 0;
    }

    internal static async Task<int>
        RunEvidenceRecognitionTermProposalsAsync(
            string databasePath,
            ClaimIssueId claimIssueId,
            Func<Task<TextSummarizationConsoleRuntime>> runtimeFactory,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentNullException.ThrowIfNull(runtimeFactory);
        ArgumentNullException.ThrowIfNull(output);

        var runtime = await runtimeFactory();

        var coordinator =
            VeteransEvidenceOrchestrationFactory
                .CreateEvidenceRecognitionTermProposalCoordinator(
                    CreateAdjudicationDetailsService(databasePath),
                    runtime.TextStructuredExtractionCapabilityExecutor);

        var results =
            await coordinator.ProposeAsync(
                claimIssueId,
                new IntelligenceExecutionContext(
                    runtime.SubjectId,
                    new IntelligenceCorrelationId(
                        $"veterans-recognition-proposal-{Guid.NewGuid():N}"),
                    runtime.ClassificationId,
                    []));

        if (results.Count == 0)
        {
            output.WriteLine(
                "No recognition-term proposal contexts were found.");
            return 0;
        }

        foreach (var result in results)
        {
            output.WriteLine(
                $"Basis             : {ConsoleTextSanitizer.Sanitize(result.BasisId.Value)}");
            output.WriteLine(
                $"Claimed Condition : {ConsoleTextSanitizer.Sanitize(result.ClaimedCondition)}");
            output.WriteLine(
                $"Requirement       : {ConsoleTextSanitizer.Sanitize(result.RequirementId.Value)}");

            foreach (var condition in result.ServiceConnectedConditions)
            {
                output.WriteLine(
                    $"Service Connected : {ConsoleTextSanitizer.Sanitize(condition)}");
            }

            if (!result.ProposalResult.IntelligenceResult.Success)
            {
                output.WriteLine("Status            : FAILED");
                output.WriteLine(
                    "Message           : " +
                    ConsoleTextSanitizer.Sanitize(
                        result.ProposalResult.IntelligenceResult.Message ??
                        "Recognition-term proposal failed."));
                output.WriteLine();
                return 1;
            }

            output.WriteLine(
                $"Requires Review    : {result.ProposalResult.IntelligenceResult.RequiresReview}");
            output.WriteLine(
                $"Proposals          : {result.ProposalResult.Proposals.Count}");

            var index = 0;
            foreach (var proposal in result.ProposalResult.Proposals)
            {
                index++;
                output.WriteLine();
                output.WriteLine($"  Proposal {index}");
                output.WriteLine(
                    $"  Term             : {ConsoleTextSanitizer.Sanitize(proposal.Term)}");
                output.WriteLine(
                    $"  Term Type        : {ConsoleTextSanitizer.Sanitize(proposal.TermType)}");
                output.WriteLine(
                    $"  Recognition Role : {ConsoleTextSanitizer.Sanitize(proposal.RecognitionRole)}");
                output.WriteLine(
                    $"  Classification   : {ConsoleTextSanitizer.Sanitize(proposal.EvidenceClassification ?? "Not specified")}");
                output.WriteLine(
                    $"  Authority Source : {ConsoleTextSanitizer.Sanitize(proposal.AuthoritySource)}");
                output.WriteLine(
                    $"  Rationale        : {ConsoleTextSanitizer.Sanitize(proposal.Rationale)}");
            }

            output.WriteLine();
        }

        return 0;
    }


    internal static async Task<int>
        RunEvidenceRecognitionTermReplayAsync(
            string snapshotPath,
            ArtifactId blueButtonArtifactId,
            IArtifactContentStore? contentStore,
            TextWriter output,
            string? qualifiedOutputPath = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(snapshotPath);
        ArgumentNullException.ThrowIfNull(output);

        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");
            return 2;
        }

        var contexts =
            new EvidenceRecognitionTermReplaySnapshotParser().Parse(
                await File.ReadAllTextAsync(snapshotPath));

#pragma warning disable CA1416
        var extractor =
            new PdfArtifactTextExtractionProvider(
                contentStore,
                new PdfToImagePageRenderer(),
                new PaddleImageOcrService());
#pragma warning restore CA1416

        var pages =
            await extractor.ExtractPagesAsync(
                blueButtonArtifactId);

        if (pages is null || pages.Count == 0)
        {
            global::System.Console.Error.WriteLine(
                "Blue Button artifact contains no extractable PDF pages.");
            return 1;
        }

        var records =
            new VeteransBlueButtonCareSummaryParser().Parse(pages);

        output.WriteLine("Mode                : OFFLINE REPLAY");
        output.WriteLine("Azure Intelligence  : NOT USED");
        output.WriteLine(
            $"Blue Button Pages   : {pages.Count}");
        output.WriteLine(
            $"Care Summary Records: {records.Count}");
        output.WriteLine();

        var auditService =
            new EvidenceRecognitionTermProposalAuditService();

        var allProposals =
            new List<EvidenceRecognitionTermProposal>();

        var qualifiedWindows =
            new List<(
                EvidenceRecognitionTermProposalAuditWindow Window,
                string RequirementId)>();

        foreach (var context in contexts)
        {
            var audit =
                auditService.Audit(
                    context.Proposals,
                    records);

            allProposals.AddRange(context.Proposals);

            foreach (var window in audit.QualifiedWindows)
            {
                qualifiedWindows.Add(
                    (window, context.RequirementId.Value));
            }

            output.WriteLine(
                $"Basis             : {ConsoleTextSanitizer.Sanitize(context.BasisId.Value)}");
            output.WriteLine(
                $"Requirement       : {ConsoleTextSanitizer.Sanitize(context.RequirementId.Value)}");
            output.WriteLine(
                $"Proposals          : {audit.Audits.Count}");
            output.WriteLine(
                $"Unique Record Hits : {audit.UniqueMatchingRecordCount} / {audit.RecordCount}");
            output.WriteLine(
                $"Diagnosis Anchors   : {audit.DiagnosisAnchorRecordCount} / {audit.RecordCount}");
            output.WriteLine(
                $"Requirement Signals : {audit.RequirementSignalRecordCount} / {audit.RecordCount}");
            output.WriteLine(
                $"Qualified Records   : {audit.QualifiedRecordCount} / {audit.RecordCount}");

            foreach (var sample in audit.QualifiedSamples)
            {
                output.WriteLine(
                    "  Qualified Sample : " +
                    $"{ConsoleTextSanitizer.Sanitize(sample.DateEntered)} | " +
                    $"pages {sample.SourceStartPage}-{sample.SourceEndPage} | " +
                    ConsoleTextSanitizer.Sanitize(sample.Title));
            }

            foreach (var item in audit.Audits)
            {
                var percentage =
                    audit.RecordCount == 0
                        ? 0.0
                        : 100.0 * item.MatchingRecordCount / audit.RecordCount;

                output.WriteLine();
                output.WriteLine(
                    $"  Term             : {ConsoleTextSanitizer.Sanitize(item.Proposal.Term)}");
                output.WriteLine(
                    $"  Role             : {ConsoleTextSanitizer.Sanitize(item.Proposal.RecognitionRole)}");
                output.WriteLine(
                    $"  Hits             : {item.MatchingRecordCount} " +
                    $"({percentage.ToString("F2", global::System.Globalization.CultureInfo.InvariantCulture)}%)");

                foreach (var sample in item.Samples)
                {
                    output.WriteLine(
                        "    Sample         : " +
                        $"{ConsoleTextSanitizer.Sanitize(sample.DateEntered)} | " +
                        $"pages {sample.SourceStartPage}-{sample.SourceEndPage} | " +
                        ConsoleTextSanitizer.Sanitize(sample.Title));
                }
            }

            output.WriteLine();
        }

        var overallAudit =
            auditService.Audit(
                allProposals,
                records,
                maximumSamples: 0);

        output.WriteLine("===== OVERALL REPLAY COVERAGE =====");
        output.WriteLine(
            $"Proposal Terms      : {allProposals.Count}");
        output.WriteLine(
            $"Unique Record Hits  : {overallAudit.UniqueMatchingRecordCount} / {overallAudit.RecordCount}");

        var overallPercentage =
            overallAudit.RecordCount == 0
                ? 0.0
                : 100.0 * overallAudit.UniqueMatchingRecordCount /
                    overallAudit.RecordCount;

        output.WriteLine(
            "Coverage Percentage : " +
            overallPercentage.ToString(
                "F2",
                global::System.Globalization.CultureInfo.InvariantCulture) +
            "%");

        if (!string.IsNullOrWhiteSpace(qualifiedOutputPath))
        {
            await WriteQualifiedReplayWindowsAsync(
                qualifiedOutputPath,
                qualifiedWindows);

            output.WriteLine(
                $"Qualified Windows  : {qualifiedOutputPath}");
        }

        return 0;
    }


    private static async Task WriteQualifiedReplayWindowsAsync(
        string outputPath,
        IReadOnlyList<(
            EvidenceRecognitionTermProposalAuditWindow Window,
            string RequirementId)> qualifiedWindows)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(outputPath);
        ArgumentNullException.ThrowIfNull(qualifiedWindows);

        var directory = Path.GetDirectoryName(outputPath);

        if (!string.IsNullOrEmpty(directory))
            Directory.CreateDirectory(directory);

        await using var writer =
            new StreamWriter(
                outputPath,
                append: false,
                encoding: new global::System.Text.UTF8Encoding(
                    encoderShouldEmitUTF8Identifier: false));

        var groups =
            qualifiedWindows
                .GroupBy(item =>
                    (
                        item.Window.RecordIndex,
                        item.Window.StartLineNumber,
                        item.Window.EndLineNumber))
                .OrderBy(group => group.Key.RecordIndex)
                .ThenBy(group => group.Key.StartLineNumber)
                .ThenBy(group => group.Key.EndLineNumber);

        foreach (var group in groups)
        {
            var window = group.First().Window;

            await writer.WriteLineAsync(
                "===== QUALIFIED BLUE BUTTON EVIDENCE WINDOW =====");
            await writer.WriteLineAsync(
                $"Date Entered : {window.DateEntered}");
            await writer.WriteLineAsync(
                $"Record Pages : {window.SourceStartPage}-{window.SourceEndPage}");
            await writer.WriteLineAsync(
                $"Title        : {window.Title}");
            await writer.WriteLineAsync(
                $"Record Lines : {window.StartLineNumber}-{window.EndLineNumber}");
            await writer.WriteLineAsync(
                "Requirements : " +
                string.Join(
                    ", ",
                    group
                        .Select(item => item.RequirementId)
                        .Distinct(StringComparer.Ordinal)
                        .OrderBy(
                            value => value,
                            StringComparer.Ordinal)));

            if (window.NoteTitles.Count > 0)
            {
                await writer.WriteLineAsync(
                    "Note Titles  : " +
                    string.Join(" | ", window.NoteTitles));
            }

            await writer.WriteLineAsync();
            await writer.WriteLineAsync(window.Text);
            await writer.WriteLineAsync();
        }
    }



    internal static async Task<int>
        RunEvidenceRecognitionPersistAsync(
            string databasePath,
            string snapshotPath,
            ClaimIssueId claimIssueId,
            ArtifactId blueButtonArtifactId,
            IArtifactContentStore? contentStore,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentException.ThrowIfNullOrWhiteSpace(snapshotPath);
        ArgumentNullException.ThrowIfNull(output);

        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");
            return 2;
        }

        var contexts =
            new EvidenceRecognitionTermReplaySnapshotParser().Parse(
                await File.ReadAllTextAsync(snapshotPath));

#pragma warning disable CA1416
        var extractor =
            new PdfArtifactTextExtractionProvider(
                contentStore,
                new PdfToImagePageRenderer(),
                new PaddleImageOcrService());
#pragma warning restore CA1416

        var pages =
            await extractor.ExtractPagesAsync(
                blueButtonArtifactId);

        if (pages is null || pages.Count == 0)
        {
            global::System.Console.Error.WriteLine(
                "Blue Button artifact contains no extractable PDF pages.");
            return 1;
        }

        var records =
            new VeteransBlueButtonCareSummaryParser().Parse(pages);

        var auditService =
            new EvidenceRecognitionTermProposalAuditService();

        var qualifiedWindows =
            new List<(
                ServiceConnectionBasisId BasisId,
                RequirementId RequirementId,
                EvidenceRecognitionTermProposalAuditWindow Window)>();

        foreach (var context in contexts)
        {
            var audit =
                auditService.Audit(
                    context.Proposals,
                    records);

            foreach (var window in audit.QualifiedWindows)
            {
                qualifiedWindows.Add(
                    (
                        context.BasisId,
                        context.RequirementId,
                        window));
            }
        }

        var groups =
            qualifiedWindows
                .GroupBy(item =>
                    (
                        BasisId: item.BasisId.Value,
                        item.Window.RecordIndex,
                        item.Window.StartLineNumber,
                        item.Window.EndLineNumber))
                .OrderBy(group => group.Key.BasisId, StringComparer.Ordinal)
                .ThenBy(group => group.Key.RecordIndex)
                .ThenBy(group => group.Key.StartLineNumber)
                .ThenBy(group => group.Key.EndLineNumber)
                .ToArray();

        var repository =
            new SqliteEvidenceRepository(databasePath);

        await repository.InitializeAsync();

        var service =
            new VeteransBoundedEvidenceDerivationService(
                repository,
                contentStore,
                new Sha256ContentFingerprintService(),
                new GuidArtifactIdGenerator(),
                new ArtifactFactory());

        output.WriteLine("Mode                : LOCAL PERSIST");
        output.WriteLine("Azure Intelligence  : NOT USED");
        output.WriteLine($"Blue Button Pages   : {pages.Count}");
        output.WriteLine($"Care Summary Records: {records.Count}");
        output.WriteLine($"Qualified Windows   : {groups.Length}");
        output.WriteLine();

        var persisted = 0;
        var reused = 0;

        foreach (var group in groups)
        {
            var first = group.First();
            var window = first.Window;

            if (!DateOnly.TryParseExact(
                    window.DateEntered,
                    "MMMM d, yyyy",
                    global::System.Globalization.CultureInfo.InvariantCulture,
                    global::System.Globalization.DateTimeStyles.None,
                    out var evidenceDate))
            {
                throw new InvalidDataException(
                    $"Qualified evidence date '{window.DateEntered}' is invalid.");
            }

            var requirements =
                group
                    .Select(item => item.RequirementId)
                    .Distinct()
                    .OrderBy(id => id.Value, StringComparer.Ordinal)
                    .ToArray();

            var bytes =
                global::System.Text.Encoding.UTF8.GetBytes(
                    window.Text);

            VeteransBoundedEvidenceDerivationResult result;

            try
            {
                result =
                    await service.DeriveAsync(
                        blueButtonArtifactId,
                        claimIssueId,
                        first.BasisId,
                        requirements,
                        window.SourceStartPage,
                        window.SourceEndPage,
                        window.StartLineNumber,
                        window.EndLineNumber,
                        evidenceDate,
                        window.Title,
                        bytes);
            }
            finally
            {
                global::System.Security.Cryptography
                    .CryptographicOperations.ZeroMemory(bytes);
            }

            if (result.AlreadyExisted)
                reused++;
            else
                persisted++;

            await output.WriteLineAsync(
                $"Artifact ID  : {result.Artifact.Id.Value}");
            await output.WriteLineAsync(
                $"Status       : {(result.AlreadyExisted ? "Existing" : "Persisted")}");
            await output.WriteLineAsync(
                $"Basis        : {first.BasisId.Value}");
            await output.WriteLineAsync(
                "Requirements : " +
                string.Join(", ", requirements.Select(id => id.Value)));
            await output.WriteLineAsync(
                $"Source Pages : {window.SourceStartPage}-{window.SourceEndPage}");
            await output.WriteLineAsync(
                $"Record Lines : {window.StartLineNumber}-{window.EndLineNumber}");
            await output.WriteLineAsync(
                $"Evidence Date: {evidenceDate:yyyy-MM-dd}");
            await output.WriteLineAsync(
                $"Evidence Title: {ConsoleTextSanitizer.Sanitize(window.Title)}");
            await output.WriteLineAsync();
        }

        output.WriteLine("===== PERSISTENCE SUMMARY =====");
        output.WriteLine($"Persisted           : {persisted}");
        output.WriteLine($"Existing            : {reused}");
        output.WriteLine($"Total               : {groups.Length}");

        return 0;
    }


    internal static async Task<int>
        RunBoundedEvidenceListAsync(
            string databasePath,
            ClaimIssueId claimIssueId,
            ServiceConnectionBasisId basisId,
            RequirementId requirementId,
            ArtifactId sourceArtifactId,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentNullException.ThrowIfNull(output);

        var repository =
            new SqliteEvidenceRepository(databasePath);

        await repository.InitializeAsync();

        var service =
            new VeteransBoundedEvidenceSelectionService(repository);

        var selections =
            await service.GetAsync(
                claimIssueId,
                basisId,
                requirementId,
                sourceArtifactId);

        output.WriteLine("Mode                : LOCAL SELECT");
        output.WriteLine("Azure Intelligence  : NOT USED");
        output.WriteLine($"Claim Issue         : {claimIssueId.Value}");
        output.WriteLine($"Basis               : {basisId.Value}");
        output.WriteLine($"Requirement         : {requirementId.Value}");
        output.WriteLine($"Source Artifact     : {sourceArtifactId.Value}");
        output.WriteLine($"Bounded Evidence    : {selections.Count}");
        output.WriteLine();

        foreach (var selection in selections)
        {
            await output.WriteLineAsync(
                $"Artifact ID  : {selection.Artifact.Id.Value}");
            await output.WriteLineAsync(
                $"Evidence Date: {selection.EvidenceDate:yyyy-MM-dd}");
            await output.WriteLineAsync(
                $"Evidence Title: {ConsoleTextSanitizer.Sanitize(selection.EvidenceTitle)}");
            await output.WriteLineAsync(
                $"Source Pages : {selection.SourceStartPage}-{selection.SourceEndPage}");
            await output.WriteLineAsync(
                $"Record Lines : {selection.SourceStartLine}-{selection.SourceEndLine}");
            await output.WriteLineAsync(
                "Requirements : " +
                string.Join(
                    ", ",
                    selection.RequirementIds.Select(id => id.Value)));
            await output.WriteLineAsync();
        }

        return 0;
    }


    internal static async Task<int>
        RunBoundedEvidenceInterpretAsync(
            string databasePath,
            ClaimIssueId claimIssueId,
            ServiceConnectionBasisId basisId,
            RequirementId requirementId,
            ArtifactId sourceArtifactId,
            Func<Task<TextSummarizationConsoleRuntime>> runtimeFactory,
            IArtifactContentStore? contentStore,
            TextWriter output,
            ArtifactId? boundedArtifactId = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentNullException.ThrowIfNull(runtimeFactory);
        ArgumentNullException.ThrowIfNull(output);

        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");
            return 2;
        }

        var regulatory =
            new SqliteRegulatoryRepository(databasePath);

        await regulatory.InitializeAsync();

        var requirement =
            await regulatory.GetRequirementAsync(requirementId);

        if (requirement is null)
        {
            global::System.Console.Error.WriteLine(
                $"Regulatory requirement not found: {requirementId.Value}");
            return 1;
        }

        var repository =
            new SqliteEvidenceRepository(databasePath);

        await repository.InitializeAsync();

        var runtime = await runtimeFactory();

        var service =
            new VeteransBoundedEvidenceInterpretationService(
                new VeteransBoundedEvidenceSelectionService(repository),
                contentStore,
                runtime.TextStructuredExtractionCapabilityExecutor);

        var results =
            await service.InterpretAsync(
                claimIssueId,
                basisId,
                requirement,
                sourceArtifactId,
                new IntelligenceExecutionContext(
                    runtime.SubjectId,
                    new IntelligenceCorrelationId(
                        $"veterans-bounded-interpret-{Guid.NewGuid():N}"),
                    runtime.ClassificationId,
                    []),
                boundedArtifactId);

        output.WriteLine("Mode                : BOUNDED INTERPRET");
        output.WriteLine($"Claim Issue         : {claimIssueId.Value}");
        output.WriteLine($"Basis               : {basisId.Value}");
        output.WriteLine($"Requirement         : {requirementId.Value}");
        output.WriteLine($"Source Artifact     : {sourceArtifactId.Value}");

        if (boundedArtifactId.HasValue)
        {
            output.WriteLine(
                $"Target Artifact     : {boundedArtifactId.Value.Value}");
        }

        output.WriteLine($"Bounded Evidence    : {results.Count}");
        output.WriteLine();

        var failed = 0;

        foreach (var result in results)
        {
            var intelligence = result.IntelligenceResult;
            var metadata = intelligence.Metadata;

            await output.WriteLineAsync(
                $"Artifact ID         : {result.Evidence.Artifact.Id.Value}");
            await output.WriteLineAsync(
                $"Evidence Date       : {result.Evidence.EvidenceDate:yyyy-MM-dd}");
            await output.WriteLineAsync(
                "Evidence Title      : " +
                ConsoleTextSanitizer.Sanitize(
                    result.Evidence.EvidenceTitle));

            if (!intelligence.Success || result.Interpretation is null)
            {
                failed++;
                await output.WriteLineAsync("Status              : FAILED");
                await output.WriteLineAsync(
                    "Message             : " +
                    ConsoleTextSanitizer.Sanitize(
                        intelligence.Message ??
                        "Bounded evidence interpretation failed."));
                await WriteIntelligenceTelemetryAsync(output, metadata);
                await output.WriteLineAsync();
                continue;
            }

            var interpretation = result.Interpretation;

            await output.WriteLineAsync("Status              : INTERPRETED");
            await output.WriteLineAsync(
                $"Direction           : {interpretation.Direction}");
            await output.WriteLineAsync(
                $"Opinion Standard    : {interpretation.OpinionStandard}");
            await output.WriteLineAsync(
                "Medical Conclusion  : " +
                ConsoleTextSanitizer.Sanitize(
                    interpretation.MedicalConclusion));
            await output.WriteLineAsync(
                "Rationale           : " +
                ConsoleTextSanitizer.Sanitize(
                    interpretation.RationaleSummary));
            await output.WriteLineAsync(
                $"Requires Review     : {intelligence.RequiresReview}");
            await output.WriteLineAsync(
                $"Source Excerpts     : {interpretation.SourceExcerpts.Count}");

            foreach (var excerpt in interpretation.SourceExcerpts)
            {
                await output.WriteLineAsync(
                    $"  [{excerpt.StartOffset},{excerpt.Length}] " +
                    ConsoleTextSanitizer.Sanitize(excerpt.Text));
            }

            await WriteIntelligenceTelemetryAsync(output, metadata);
            await output.WriteLineAsync();
        }

        output.WriteLine("===== INTERPRETATION SUMMARY =====");
        output.WriteLine($"Interpreted         : {results.Count - failed}");
        output.WriteLine($"Failed              : {failed}");
        output.WriteLine($"Total               : {results.Count}");

        return failed == 0 ? 0 : 1;
    }


    private static async Task WriteIntelligenceTelemetryAsync(
        TextWriter output,
        IntelligenceExecutionMetadata? metadata)
    {
        if (metadata is null)
            return;

        await output.WriteLineAsync(
            $"Provider            : {metadata.ProviderId.Value}");
        await output.WriteLineAsync(
            "Engine              : " +
            ConsoleTextSanitizer.Sanitize(metadata.EngineName));
        await output.WriteLineAsync(
            $"Correlation         : {metadata.CorrelationId.Value}");

        if (metadata.InputTokenCount.HasValue)
        {
            await output.WriteLineAsync(
                $"Input Tokens        : {metadata.InputTokenCount.Value}");
        }

        if (metadata.OutputTokenCount.HasValue)
        {
            await output.WriteLineAsync(
                $"Output Tokens       : {metadata.OutputTokenCount.Value}");
        }

        if (metadata.TotalTokenCount.HasValue)
        {
            await output.WriteLineAsync(
                $"Total Tokens        : {metadata.TotalTokenCount.Value}");
        }

        if (metadata.EstimatedCostUsd.HasValue)
        {
            await output.WriteLineAsync(
                $"Estimated Cost USD  : {metadata.EstimatedCostUsd.Value:G29}");
        }
    }


    internal static async Task<int>
        RunEvidenceRecognitionTermAuditAsync(
            string databasePath,
            ClaimIssueId claimIssueId,
            ArtifactId blueButtonArtifactId,
            Func<Task<TextSummarizationConsoleRuntime>> runtimeFactory,
            IArtifactContentStore? contentStore,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentNullException.ThrowIfNull(runtimeFactory);
        ArgumentNullException.ThrowIfNull(output);

        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");
            return 2;
        }

#pragma warning disable CA1416
        var extractor =
            new PdfArtifactTextExtractionProvider(
                contentStore,
                new PdfToImagePageRenderer(),
                new PaddleImageOcrService());
#pragma warning restore CA1416

        var pages =
            await extractor.ExtractPagesAsync(
                blueButtonArtifactId);

        if (pages is null || pages.Count == 0)
        {
            global::System.Console.Error.WriteLine(
                "Blue Button artifact contains no extractable PDF pages.");
            return 1;
        }

        var records =
            new VeteransBlueButtonCareSummaryParser().Parse(pages);

        output.WriteLine(
            $"Blue Button Pages   : {pages.Count}");
        output.WriteLine(
            $"Care Summary Records: {records.Count}");
        output.WriteLine();

        var runtime = await runtimeFactory();

        var coordinator =
            VeteransEvidenceOrchestrationFactory
                .CreateEvidenceRecognitionTermProposalCoordinator(
                    CreateAdjudicationDetailsService(databasePath),
                    runtime.TextStructuredExtractionCapabilityExecutor);

        var results =
            await coordinator.ProposeAsync(
                claimIssueId,
                new IntelligenceExecutionContext(
                    runtime.SubjectId,
                    new IntelligenceCorrelationId(
                        $"veterans-recognition-audit-{Guid.NewGuid():N}"),
                    runtime.ClassificationId,
                    []));

        if (results.Count == 0)
        {
            output.WriteLine(
                "No recognition-term proposal contexts were found.");
            return 0;
        }

        var auditService =
            new EvidenceRecognitionTermProposalAuditService();

        var allProposals =
            new List<EvidenceRecognitionTermProposal>();

        foreach (var result in results)
        {
            if (!result.ProposalResult.IntelligenceResult.Success)
            {
                output.WriteLine(
                    $"Requirement       : {ConsoleTextSanitizer.Sanitize(result.RequirementId.Value)}");
                output.WriteLine("Status            : FAILED");
                output.WriteLine(
                    "Message           : " +
                    ConsoleTextSanitizer.Sanitize(
                        result.ProposalResult.IntelligenceResult.Message ??
                        "Recognition-term proposal failed."));
                output.WriteLine();
                return 1;
            }

            var audit =
                auditService.Audit(
                    result.ProposalResult.Proposals,
                    records);

            allProposals.AddRange(
                result.ProposalResult.Proposals);

            output.WriteLine(
                $"Basis             : {ConsoleTextSanitizer.Sanitize(result.BasisId.Value)}");
            output.WriteLine(
                $"Requirement       : {ConsoleTextSanitizer.Sanitize(result.RequirementId.Value)}");
            output.WriteLine(
                $"Proposals          : {audit.Audits.Count}");
            output.WriteLine(
                $"Unique Record Hits : {audit.UniqueMatchingRecordCount} / {audit.RecordCount}");
            output.WriteLine(
                $"Diagnosis Anchors   : {audit.DiagnosisAnchorRecordCount} / {audit.RecordCount}");
            output.WriteLine(
                $"Requirement Signals : {audit.RequirementSignalRecordCount} / {audit.RecordCount}");
            output.WriteLine(
                $"Qualified Records   : {audit.QualifiedRecordCount} / {audit.RecordCount}");

            foreach (var sample in audit.QualifiedSamples)
            {
                output.WriteLine(
                    "  Qualified Sample : " +
                    $"{ConsoleTextSanitizer.Sanitize(sample.DateEntered)} | " +
                    $"pages {sample.SourceStartPage}-{sample.SourceEndPage} | " +
                    ConsoleTextSanitizer.Sanitize(sample.Title));
            }

            foreach (var item in audit.Audits)
            {
                var percentage =
                    audit.RecordCount == 0
                        ? 0.0
                        : 100.0 * item.MatchingRecordCount / audit.RecordCount;

                output.WriteLine();
                output.WriteLine(
                    $"  Term             : {ConsoleTextSanitizer.Sanitize(item.Proposal.Term)}");
                output.WriteLine(
                    $"  Role             : {ConsoleTextSanitizer.Sanitize(item.Proposal.RecognitionRole)}");
                output.WriteLine(
                    $"  Hits             : {item.MatchingRecordCount} " +
                    $"({percentage.ToString("F2", global::System.Globalization.CultureInfo.InvariantCulture)}%)");

                foreach (var sample in item.Samples)
                {
                    output.WriteLine(
                        "    Sample         : " +
                        $"{ConsoleTextSanitizer.Sanitize(sample.DateEntered)} | " +
                        $"pages {sample.SourceStartPage}-{sample.SourceEndPage} | " +
                        ConsoleTextSanitizer.Sanitize(sample.Title));
                }
            }

            output.WriteLine();
        }

        var overallAudit =
            auditService.Audit(
                allProposals,
                records,
                maximumSamples: 0);

        output.WriteLine("===== OVERALL PROPOSAL COVERAGE =====");
        output.WriteLine(
            $"Proposal Terms      : {allProposals.Count}");
        output.WriteLine(
            $"Unique Record Hits  : {overallAudit.UniqueMatchingRecordCount} / {overallAudit.RecordCount}");

        var overallPercentage =
            overallAudit.RecordCount == 0
                ? 0.0
                : 100.0 * overallAudit.UniqueMatchingRecordCount /
                    overallAudit.RecordCount;

        output.WriteLine(
            "Coverage Percentage : " +
            overallPercentage.ToString(
                "F2",
                global::System.Globalization.CultureInfo.InvariantCulture) +
            "%");

        return 0;
    }


    private static ClaimIssueAdjudicationDetailsService
        CreateAdjudicationDetailsService(
            string databasePath)
    {
        var issues =
            new SqliteClaimIssueRepository(databasePath);

        var serviceConnections =
            new SqliteServiceConnectionRepository(databasePath);

        var regulatory =
            new SqliteRegulatoryRepository(databasePath);

        var gaps =
            new SqliteEvidenceGapRepository(databasePath);

        var requirementEvidence =
            new RequirementEvidenceService(
                new SqliteEvidenceClassificationRepository(
                    databasePath),
                new SqliteEvidenceRequirementGuidanceRepository(
                    databasePath));

        var evidence =
            new ClaimIssueEvidenceDetailsService(
                issues,
                new ClaimIssueEvidenceChecklistService(
                    gaps,
                    requirementEvidence),
                new EvidenceDevelopmentPlanService(
                    new SqliteEvidenceDevelopmentPlanRepository(
                        databasePath),
                    gaps));

        var timeline =
            new ClaimIssueAdjudicationTimelineService(
                new ClaimIssueAdjudicationLifecycleService(
                    new SqliteVaDecisionRepository(databasePath),
                    new SqliteSubmissionRepository(databasePath)),
                new SqliteClaimIssueCourtAppealRepository(
                    databasePath));

        return new ClaimIssueAdjudicationDetailsService(
            issues,
            new SqliteConditionRepository(databasePath),
            serviceConnections,
            new SqliteServiceHistoryRepository(databasePath),
            regulatory,
            requirementEvidence,
            evidence,
            timeline,
            new SqliteMedicalOpinionRepository(databasePath),
            new SqliteMedicalLiteratureRepository(databasePath));
    }

    private static ClaimIssueAdjudicationAssessmentService
        CreateAdjudicationAssessmentService(
            string databasePath)
    {
        var serviceConnections =
            new SqliteServiceConnectionRepository(databasePath);

        var details =
            CreateAdjudicationDetailsService(databasePath);

        var merits =
            new ClaimIssueMeritsAssessmentService(
                serviceConnections,
                new SqliteFindingRepository(databasePath));

        var assessment =
            new ClaimIssueAdjudicationAssessmentService(
                details,
                new ClaimIssueAdjudicationReadinessService(),
                merits,
                new ClaimIssueDecisionRecommendationService(),
                new ClaimIssueCurrentDecisionService(
                    new SqliteVaDecisionRepository(databasePath)),
                CreateReviewHistoryService(databasePath),
                new ClaimIssueAdjudicationAgingStatusService(
                    new ClaimIssueAdjudicationAgingService(),
                    new ClaimIssueAdjudicationAgingPolicyService()),
                ClaimIssueAdjudicationAgingPolicies.Default,
                TimeProvider.System);


        return assessment;
    }


    internal static async Task<int> RunAdjudicationAssessmentAsync(
        string databasePath,
        ClaimIssueId claimIssueId,
        TextWriter output)
    {
        var assessment =
            CreateAdjudicationAssessmentService(databasePath);

        var result =
            await assessment.GetAsync(claimIssueId);

        if (result is null)
        {
            global::System.Console.Error.WriteLine(
                $"Claim issue not found: {claimIssueId.Value}");

            return 1;
        }

        ArgumentNullException.ThrowIfNull(output);

        output.WriteLine(
            $"Claim Issue : {result.Details.ClaimIssue.Id.Value}");

        foreach (var claimedCondition in result.Details.ClaimedConditions)
        {
            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    $"Claimed Condition: {claimedCondition.Id.Value} ({claimedCondition.Name})"));
        }

        output.WriteLine(
            $"Ready       : {result.Readiness.IsReadyForAdjudication}");

        output.WriteLine(
            $"Attention   : {result.RequiresAttention}");

        output.WriteLine(
            $"Follow Up   : {result.ShouldConsiderFollowUp}");

        output.WriteLine(
            $"Merits      : {result.Merits?.Outcome ?? "None"}");

        output.WriteLine(
            $"Recommend   : " +
            $"{result.Recommendation?.RecommendedOutcome ?? "None"}");

        output.WriteLine(
            $"Current     : " +
            $"{result.CurrentDecision?.IssueDecision.Outcome ?? "None"}");

        output.WriteLine(
            $"Review History: {result.DecisionReviewHistory.Count}");

        output.WriteLine(
            $"Evidence Checklists: " +
            $"{result.Details.Evidence.Checklist.RequirementChecklists.Count}");

        output.WriteLine(
            $"Evidence Outstanding: " +
            $"{result.Details.Evidence.Checklist.HasOutstandingItems}");

        output.WriteLine(
            $"Development Plans: " +
            $"{result.Details.Evidence.DevelopmentPlans.Count}");

        foreach (var review in result.DecisionReviewHistory)
        {
            output.WriteLine(
                $"- {review.Review.Comparison.ComparisonOutcome} " +
                $"Review={review.Review.RequiresReview}");
        }

        foreach (var theory in result.Details.ServiceConnectionTheories)
        {
            output.WriteLine(
                $"Theory      : {theory.TheoryType}");

            output.WriteLine(
                $"Theory ID   : {theory.Id.Value}");

            var theoryOutcome =
                result.Merits?.TheoryOutcomes.SingleOrDefault(
                    x => x.Theory.Id == theory.Id);

            if (theoryOutcome is not null)
            {
                output.WriteLine(
                    $"Outcome     : {theoryOutcome.Outcome}");
            }

            foreach (var basis in
                result.Details.ServiceConnectionBases.Where(
                    x => x.ServiceConnectionTheoryId == theory.Id))
            {
                output.WriteLine(
                    $"Basis       : {basis.Id.Value}");

                var basisOutcome =
                    theoryOutcome?.BasisOutcomes.SingleOrDefault(
                        x => x.Basis.Id == basis.Id);

                if (basisOutcome is not null)
                {
                    output.WriteLine(
                        $"Basis Result: {basisOutcome.Outcome}");
                }

                foreach (var condition in
                    result.Details.ServiceConnectedConditions.Where(
                        x => x.Basis.Id == basis.Id))
                {
                    output.WriteLine(
                        ConsoleTextSanitizer.Sanitize(
                            $"Service Connected: " +
                            $"{condition.ServiceConnectedCondition.Id.Value} " +
                            $"({condition.ServiceConnectedCondition.Name})"));
                }

                foreach (var serviceEvent in
                    result.Details.ServiceEvents.Where(
                        x => x.Basis.Id == basis.Id))
                {
                    output.WriteLine(
                        ConsoleTextSanitizer.Sanitize(
                            $"Service Event: " +
                            $"{serviceEvent.ServiceEvent.Id.Value} " +
                            $"({serviceEvent.ServiceEvent.Description})"));
                }

                foreach (var requirement in
                    result.Details.Requirements.Where(
                        x => x.Basis.Id == basis.Id))
                {
                    output.WriteLine(
                        $"Requirement : {requirement.Requirement.Id.Value}");

                    var requirementOutcome =
                        basisOutcome?.RequirementOutcomes.SingleOrDefault(
                            x =>
                                x.RequirementId ==
                                requirement.Requirement.Id);

                    if (requirementOutcome is not null)
                    {
                        output.WriteLine(
                            $"Req Result  : {requirementOutcome.Outcome}");
                    }

                    output.WriteLine(
                        ConsoleTextSanitizer.Sanitize(
                            $"Description : {requirement.Requirement.Description}"));

                    output.WriteLine(
                        $"Provision   : " +
                        $"{requirement.Requirement.RegulatoryProvisionId.Value}");

                    output.WriteLine(
                        ConsoleTextSanitizer.Sanitize(
                            $"Citation    : " +
                            $"{requirement.RegulatoryProvision.Citation}"));

                    output.WriteLine(
                        $"Evidence Matched : " +
                        $"{requirement.Responsiveness.MatchingItemCount}");

                    output.WriteLine(
                        $"Evidence Missing : " +
                        $"{requirement.Responsiveness.MissingItemCount}");

                    output.WriteLine(
                        $"Development Items: " +
                        $"{requirement.DevelopmentChecklist.Items.Count}");
                }
            }
        }

        output.WriteLine(
            $"Outstanding : {result.Readiness.OutstandingRequirementCount}");

        foreach (var blocking in
            result.Readiness.BlockingRequirements)
        {
            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    $"- {blocking.Requirement.Id.Value}: " +
                    blocking.Requirement.Description));
        }

        output.WriteLine(
            $"Outstanding Items: {result.Readiness.OutstandingItemCount}");

        foreach (var item in result.Readiness.BlockingItems)
        {
            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    $"  - {item.EvidenceClassification} / " +
                    $"{item.GuidanceRole}: {item.Description}"));
        }

        if (result.Aging is not null)
        {
            output.WriteLine(
                $"Pending Since: {result.Aging.Aging.PendingSince:O}");

            output.WriteLine(
                $"Age (Days)   : {result.Aging.Aging.AgeInDays}");

            output.WriteLine(
                $"Last Activity: " +
                $"{result.Aging.Aging.LastActivityAt:O}");

            output.WriteLine(
                $"Inactive Days: " +
                $"{result.Aging.Aging.DaysSinceLastActivity}");

            output.WriteLine(
                $"Aging Status : {result.Aging.AlertLevel}");
        }

        output.WriteLine(
            $"Timeline    : {result.Details.Timeline.Count}");

        foreach (var item in result.Details.Timeline)
        {
            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    $"- {item.OccurredAt:O} " +
                    $"{item.EventType}" +
                    (item.Outcome is null
                        ? string.Empty
                        : $" [{item.Outcome}]") +
                    (item.Description is null
                        ? string.Empty
                        : $": {item.Description}")));
        }

        return 0;
    }


    internal static async Task<int> RunEvidenceIngestAsync(
        string databasePath,
        string sourcePath,
        IArtifactContentStore? contentStore,
        TextWriter output)
    {
        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");

            return 2;
        }

        var repository =
            new SqliteEvidenceRepository(databasePath);

        await repository.InitializeAsync();

        var service =
            new EvidenceFileIngestionService(
                repository,
                contentStore,
                new Sha256ContentFingerprintService(),
                new GuidArtifactIdGenerator(),
                new ArtifactFactory());

        try
        {
            var result =
                await service.IngestAsync(sourcePath);

            await output.WriteLineAsync(
                $"Artifact ID : {result.Artifact.Id.Value}");

            await output.WriteLineAsync(
                $"Status      : {(result.AlreadyExisted ? "Existing" : "Persisted")}");

            return 0;
        }
        catch (Exception ex)
        {
            global::System.Console.Error.WriteLine(
                $"Evidence ingestion failed: {ex.Message}");

            return 1;
        }
    }

    internal static async Task<int> RunEvidenceSupersedeAsync(
        string databasePath,
        ArtifactId replacementArtifactId,
        ArtifactId supersededArtifactId,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        var repository =
            new SqliteEvidenceRepository(databasePath);

        await repository.InitializeAsync();

        var service =
            new ArtifactSupersessionService(repository);

        try
        {
            var result =
                await service.SupersedeAsync(
                    replacementArtifactId,
                    supersededArtifactId);

            await output.WriteLineAsync(
                $"Replacement Artifact : " +
                $"{result.Relationship.SourceArtifactId.Value}");

            await output.WriteLineAsync(
                $"Superseded Artifact  : " +
                $"{result.Relationship.TargetArtifactId.Value}");

            await output.WriteLineAsync(
                $"Status               : " +
                $"{(result.AlreadyExisted ? "Existing" : "Persisted")}");

            return 0;
        }
        catch (Exception ex)
        {
            global::System.Console.Error.WriteLine(
                $"Evidence supersession failed: {ex.Message}");

            return 1;
        }
    }


    internal static async Task<int> RunEvidenceClinicalNoteAsync(
        string databasePath,
        ArtifactId parentArtifactId,
        int startPage,
        int endPage,
        DateOnly noteDate,
        string noteTitle,
        IArtifactContentStore? contentStore,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");
            return 2;
        }

        if (string.IsNullOrWhiteSpace(noteTitle))
        {
            global::System.Console.Error.WriteLine(
                "Clinical note title must not be empty.");
            return 2;
        }

        var repository =
            new SqliteEvidenceRepository(databasePath);

        await repository.InitializeAsync();

        try
        {
#pragma warning disable CA1416
            var extractor =
                new PdfArtifactTextExtractionProvider(
                    contentStore,
                    new PdfToImagePageRenderer(),
                    new PaddleImageOcrService());
#pragma warning restore CA1416

            var text =
                await extractor.ExtractPageRangeTextAsync(
                    parentArtifactId,
                    startPage,
                    endPage);

            if (string.IsNullOrWhiteSpace(text))
            {
                global::System.Console.Error.WriteLine(
                    "Clinical note page range contains no extractable text.");
                return 1;
            }

            var bytes =
                global::System.Text.Encoding.UTF8.GetBytes(text);

            try
            {
                var service =
                    new VeteransClinicalNoteDerivationService(
                        repository,
                        contentStore,
                        new Sha256ContentFingerprintService(),
                        new GuidArtifactIdGenerator(),
                        new ArtifactFactory());

                var result =
                    await service.DeriveAsync(
                        parentArtifactId,
                        $"clinical-note-{noteDate:yyyy-MM-dd}-" +
                            $"{startPage}-{endPage}.txt",
                        startPage,
                        endPage,
                        noteDate,
                        noteTitle,
                        bytes);

                await output.WriteLineAsync(
                    $"Artifact ID : {result.Artifact.Id.Value}");
                await output.WriteLineAsync(
                    $"Parent ID   : {parentArtifactId.Value}");
                await output.WriteLineAsync(
                    $"Source Pages: {startPage}-{endPage}");
                await output.WriteLineAsync(
                    $"Note Date   : {noteDate:yyyy-MM-dd}");
                await output.WriteLineAsync(
                    $"Note Title  : {noteTitle}");

                return 0;
            }
            finally
            {
                global::System.Security.Cryptography
                    .CryptographicOperations.ZeroMemory(bytes);
            }
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Clinical note derivation failed: {ex.Message}");
            return 1;
        }
    }


    internal static async Task<int> RunEvidenceClinicalNoteRecordAsync(
        string databasePath,
        ArtifactId parentArtifactId,
        DateOnly noteDate,
        string noteTitle,
        IArtifactContentStore? contentStore,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");
            return 2;
        }

        if (string.IsNullOrWhiteSpace(noteTitle))
        {
            global::System.Console.Error.WriteLine(
                "Clinical note record title must not be empty.");
            return 2;
        }

        var repository =
            new SqliteEvidenceRepository(databasePath);

        await repository.InitializeAsync();

        try
        {
#pragma warning disable CA1416
            var extractor =
                new PdfArtifactTextExtractionProvider(
                    contentStore,
                    new PdfToImagePageRenderer(),
                    new PaddleImageOcrService());
#pragma warning restore CA1416

            var pages =
                await extractor.ExtractPagesAsync(
                    parentArtifactId);

            if (pages is null || pages.Count == 0)
            {
                global::System.Console.Error.WriteLine(
                    "Blue Button artifact contains no extractable PDF pages.");
                return 1;
            }

            var records =
                new VeteransBlueButtonCareSummaryParser().Parse(pages);

            var record =
                new VeteransBlueButtonClinicalNoteSelectionService()
                    .Select(
                        records,
                        noteDate,
                        noteTitle);

            var bytes =
                global::System.Text.Encoding.UTF8.GetBytes(
                    record.Text);

            try
            {
                var service =
                    new VeteransClinicalNoteDerivationService(
                        repository,
                        contentStore,
                        new Sha256ContentFingerprintService(),
                        new GuidArtifactIdGenerator(),
                        new ArtifactFactory());

                var result =
                    await service.DeriveAsync(
                        parentArtifactId,
                        $"clinical-note-{noteDate:yyyy-MM-dd}-" +
                            $"{record.SourceStartPage}-" +
                            $"{record.SourceEndPage}.txt",
                        record.SourceStartPage,
                        record.SourceEndPage,
                        noteDate,
                        record.Title,
                        bytes);

                await output.WriteLineAsync(
                    $"Parsed Records: {records.Count}");
                await output.WriteLineAsync(
                    $"Artifact ID   : {result.Artifact.Id.Value}");
                await output.WriteLineAsync(
                    $"Parent ID     : {parentArtifactId.Value}");
                await output.WriteLineAsync(
                    $"Source Pages  : {record.SourceStartPage}-" +
                    $"{record.SourceEndPage}");
                await output.WriteLineAsync(
                    $"Note Date     : {noteDate:yyyy-MM-dd}");
                await output.WriteLineAsync(
                    $"Note Title    : {record.Title}");

                return 0;
            }
            finally
            {
                global::System.Security.Cryptography
                    .CryptographicOperations.ZeroMemory(bytes);
            }
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Clinical note record derivation failed: {ex.Message}");
            return 1;
        }
    }

    internal static async Task<int> RunEvidenceMedicationIndicationReconciliationAsync(
        string databasePath, VeteranId veteranId, DateOnly date, string medicationName,
        string indication, string source, TextWriter output)
    {
        if (string.IsNullOrWhiteSpace(medicationName) || string.IsNullOrWhiteSpace(indication) ||
            string.IsNullOrWhiteSpace(source)) return 2;
        var repository = new SqliteMedicationRepository(databasePath);
        await repository.InitializeAsync();
        if (await new SqliteVeteranRepository(databasePath).GetVeteranAsync(veteranId) is null)
            return 2;
        var existing = (await repository.GetMedicationIndicationReconciliationsAsync(veteranId))
            .SingleOrDefault(item => item.ReconciliationDate == date &&
                item.MedicationName.Equals(medicationName.Trim(), StringComparison.OrdinalIgnoreCase));
        if (existing is not null)
        {
            if (existing.Indication != indication.Trim() || existing.Source != source.Trim())
            {
                await output.WriteLineAsync("A different attributed indication already exists for this medication and date.");
                return 2;
            }
        }
        else
            await repository.AddMedicationIndicationReconciliationAsync(new()
            {
                Id = Guid.NewGuid().ToString("N"), VeteranId = veteranId, ReconciliationDate = date,
                MedicationName = medicationName.Trim(), Indication = indication.Trim(), Source = source.Trim()
            });
        await output.WriteLineAsync($"Indication reconciliation: {medicationName.Trim()} — {indication.Trim()}; {source.Trim()}, {date:yyyy-MM-dd}. Original ledger unchanged.");
        return 0;
    }

    internal static async Task<int>
        RunEvidenceMedicationReconciliationAsync(
            string databasePath,
            VeteranId veteranId,
            MedicationLedgerEntryId medicationLedgerEntryId,
            DateOnly reconciliationDate,
            string currentUseStatus,
            string source,
            string? note,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentException.ThrowIfNullOrWhiteSpace(currentUseStatus);
        ArgumentException.ThrowIfNullOrWhiteSpace(source);
        ArgumentNullException.ThrowIfNull(output);

        if (!MedicationCurrentUseStatuses.IsSupported(currentUseStatus))
        {
            global::System.Console.Error.WriteLine(
                $"Unsupported medication current-use status: {currentUseStatus}");
            return 2;
        }

        var veterans = new SqliteVeteranRepository(databasePath);

        if (await veterans.GetVeteranAsync(veteranId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Veteran not found: {veteranId.Value}");
            return 2;
        }

        try
        {
            var repository = new SqliteMedicationRepository(databasePath);
            await repository.InitializeAsync();

            MedicationLedgerEntry? selectedEntry = null;

            foreach (var ledger in
                await repository.GetMedicationLedgersAsync(veteranId))
            {
                selectedEntry =
                    (await repository.GetMedicationLedgerEntriesAsync(ledger.Id))
                        .SingleOrDefault(
                            entry => entry.Id == medicationLedgerEntryId);

                if (selectedEntry is not null)
                    break;
            }

            if (selectedEntry is null)
            {
                global::System.Console.Error.WriteLine(
                    $"Medication ledger entry not found for veteran: " +
                    $"{medicationLedgerEntryId.Value}");
                return 2;
            }

            var normalizedStatus =
                MedicationCurrentUseStatuses.IsCurrentlyUsed(currentUseStatus)
                    ? MedicationCurrentUseStatuses.CurrentlyUsed
                    : MedicationCurrentUseStatuses.NotCurrentlyUsed;
            var normalizedSource = source.Trim();
            var normalizedNote =
                string.IsNullOrWhiteSpace(note) ? null : note.Trim();

            var existing =
                (await repository
                    .GetMedicationCurrentUseReconciliationsAsync(veteranId))
                .Where(item =>
                    item.MedicationLedgerEntryId == medicationLedgerEntryId &&
                    item.ReconciliationDate == reconciliationDate)
                .ToArray();

            if (existing.Length > 1)
                throw new InvalidDataException(
                    "Multiple medication reconciliations exist for the same " +
                    "ledger entry and date.");

            if (existing.Length == 1)
            {
                var item = existing[0];

                if (!string.Equals(
                        item.CurrentUseStatus,
                        normalizedStatus,
                        StringComparison.Ordinal) ||
                    !string.Equals(
                        item.Source,
                        normalizedSource,
                        StringComparison.Ordinal) ||
                    !string.Equals(
                        item.Note,
                        normalizedNote,
                        StringComparison.Ordinal))
                {
                    global::System.Console.Error.WriteLine(
                        "A different medication reconciliation already exists " +
                        "for this ledger entry and date.");
                    return 1;
                }

                await WriteMedicationReconciliationAsync(
                    output,
                    item,
                    selectedEntry,
                    true);
                return 0;
            }

            var reconciliation =
                new MedicationCurrentUseReconciliation
                {
                    Id =
                        new MedicationCurrentUseReconciliationId(
                            Guid.NewGuid().ToString("N")),
                    VeteranId = veteranId,
                    MedicationLedgerEntryId = medicationLedgerEntryId,
                    ReconciliationDate = reconciliationDate,
                    CurrentUseStatus = normalizedStatus,
                    Source = normalizedSource,
                    Note = normalizedNote
                };

            await repository.AddMedicationCurrentUseReconciliationAsync(
                reconciliation);

            await WriteMedicationReconciliationAsync(
                output,
                reconciliation,
                selectedEntry,
                false);

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Medication reconciliation failed: {ex.Message}");
            return 1;
        }
    }

    private static async Task WriteMedicationReconciliationAsync(
        TextWriter output,
        MedicationCurrentUseReconciliation reconciliation,
        MedicationLedgerEntry entry,
        bool alreadyPersisted)
    {
        await output.WriteLineAsync(
            $"Reconciliation ID : {reconciliation.Id.Value}");
        await output.WriteLineAsync(
            $"Ledger Entry ID   : {entry.Id.Value}");
        await output.WriteLineAsync(
            $"Medication        : {entry.MedicationName}");
        await output.WriteLineAsync(
            $"Prescription      : {entry.PrescriptionNumber ?? "-"}");
        await output.WriteLineAsync(
            $"Current Use       : {reconciliation.CurrentUseStatus}");
        await output.WriteLineAsync(
            $"Reconciled Date   : {reconciliation.ReconciliationDate:yyyy-MM-dd}");
        await output.WriteLineAsync(
            $"Source            : {reconciliation.Source}");
        await output.WriteLineAsync(
            $"Note              : {reconciliation.Note ?? "-"}");
        await output.WriteLineAsync(
            $"Already Persisted : {alreadyPersisted}");
    }

    internal static async Task<int>
        RunEvidenceCurrentMedicationLedgerAsync(
            string databasePath,
            VeteranId veteranId,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentNullException.ThrowIfNull(output);

        var veterans =
            new SqliteVeteranRepository(databasePath);

        if (await veterans.GetVeteranAsync(veteranId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Veteran not found: {veteranId.Value}");
            return 2;
        }

        try
        {
            var medicationRepository =
                new SqliteMedicationRepository(databasePath);

            var currentMedicationService =
                new CurrentMedicationLedgerService(
                    medicationRepository);

            var snapshot =
                await currentMedicationService.GetAsync(veteranId);

            if (snapshot is null)
            {
                await output.WriteLineAsync(
                    "Authoritative Medication Ledger : None");
                return 0;
            }

            await output.WriteLineAsync(
                $"Medication Ledger ID : {snapshot.Ledger.Id.Value}");
            await output.WriteLineAsync(
                $"Report Date          : " +
                $"{snapshot.Ledger.ReportDate:yyyy-MM-dd}");
            await output.WriteLineAsync(
                $"Source Pages         : " +
                $"{snapshot.Ledger.SourceStartPage}-" +
                $"{snapshot.Ledger.SourceEndPage}");
            var latestReconciliations =
                await new ReconciledCurrentMedicationLedgerService(
                        currentMedicationService,
                        medicationRepository)
                    .GetLatestReconciliationsAsync(veteranId);

            await output.WriteLineAsync(
                $"Current Prescriptions: {snapshot.Entries.Count}");

            foreach (var entry in snapshot.Entries)
            {
                latestReconciliations.TryGetValue(
                    entry.Id,
                    out var reconciliation);

                await output.WriteLineAsync();
                await output.WriteLineAsync(
                    $"Ledger Entry ID : {entry.Id.Value}");
                await output.WriteLineAsync(
                    $"Medication      : {entry.MedicationName}");
                await output.WriteLineAsync(
                    $"Strength        : {entry.Strength ?? "-"}");
                await output.WriteLineAsync(
                    $"VA Status       : {entry.Status}");
                await output.WriteLineAsync(
                    $"Prescription    : {entry.PrescriptionNumber ?? "-"}");
                await output.WriteLineAsync(
                    $"Prescribed      : " +
                    $"{entry.PrescribedDate?.ToString("yyyy-MM-dd") ?? "-"}");
                await output.WriteLineAsync(
                    $"Last Filled     : " +
                    $"{entry.LastFilledDate?.ToString("yyyy-MM-dd") ?? entry.LastFilledOnText ?? "-"}");
                await output.WriteLineAsync(
                    $"Expires         : " +
                    $"{entry.ExpirationDate?.ToString("yyyy-MM-dd") ?? "-"}");
                await output.WriteLineAsync(
                    $"Refills Left    : " +
                    $"{entry.RefillsLeft?.ToString() ?? "-"}");
                await output.WriteLineAsync(
                    $"Directions      : {entry.Directions ?? "-"}");
                await output.WriteLineAsync(
                    $"Indication      : {entry.Indication ?? "-"}");
                await output.WriteLineAsync(
                    $"Source Pages    : {entry.SourceStartPage}-" +
                    $"{entry.SourceEndPage}");
                await output.WriteLineAsync(
                    $"Current Use     : " +
                    $"{reconciliation?.CurrentUseStatus ?? "Unreconciled"}");
                await output.WriteLineAsync(
                    $"Reconciled Date : " +
                    $"{reconciliation?.ReconciliationDate.ToString("yyyy-MM-dd") ?? "-"}");
                await output.WriteLineAsync(
                    $"Reconciled By   : {reconciliation?.Source ?? "-"}");
                await output.WriteLineAsync(
                    $"Reconcile Note  : {reconciliation?.Note ?? "-"}");
            }

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Current medication ledger resolution failed: {ex.Message}");
            return 1;
        }
    }


    internal static async Task<int>
        RunEvidenceMedicationLedgerImportAsync(
            string databasePath,
            VeteranId veteranId,
            ArtifactId sourceArtifactId,
            IArtifactContentStore? contentStore,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentNullException.ThrowIfNull(output);

        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");
            return 2;
        }

        var veterans =
            new SqliteVeteranRepository(databasePath);

        if (await veterans.GetVeteranAsync(veteranId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Veteran not found: {veteranId.Value}");
            return 2;
        }

        var evidence =
            new SqliteEvidenceRepository(databasePath);

        await evidence.InitializeAsync();

        if (await evidence.GetArtifactAsync(sourceArtifactId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Source artifact not found: {sourceArtifactId.Value}");
            return 2;
        }

        try
        {
#pragma warning disable CA1416
            var extractor =
                new PdfArtifactTextExtractionProvider(
                    contentStore,
                    new PdfToImagePageRenderer(),
                    new PaddleImageOcrService());
#pragma warning restore CA1416

            var pages =
                await extractor.ExtractPagesAsync(sourceArtifactId);

            if (pages is null || pages.Count == 0)
            {
                global::System.Console.Error.WriteLine(
                    "Blue Button artifact contains no extractable PDF pages.");
                return 1;
            }

            var parsed =
                new VeteransBlueButtonMedicationLedgerParser()
                    .Parse(pages);

            var repository =
                new SqliteMedicationRepository(databasePath);

            await repository.InitializeAsync();

            var result =
                await new VeteransBlueButtonMedicationLedgerImportService(
                    repository,
                    new GuidIdGenerator())
                .ImportAsync(
                    veteranId,
                    sourceArtifactId,
                    parsed);

            await output.WriteLineAsync(
                "Mode                 : OFFLINE BLUE BUTTON IMPORT");
            await output.WriteLineAsync(
                "Azure Intelligence   : NOT USED");
            await output.WriteLineAsync(
                $"Medication Ledger ID : {result.Ledger.Id.Value}");
            await output.WriteLineAsync(
                $"Report Date          : {result.Ledger.ReportDate:yyyy-MM-dd}");
            await output.WriteLineAsync(
                $"Source Pages         : {result.Ledger.SourceStartPage}-" +
                $"{result.Ledger.SourceEndPage}");
            await output.WriteLineAsync(
                $"Reported Entries     : " +
                $"{result.Ledger.ReportedEntryCount?.ToString() ?? "Unknown"}");
            await output.WriteLineAsync(
                $"Parsed Entries       : {result.Ledger.ParsedEntryCount}");
            await output.WriteLineAsync(
                $"Complete             : {result.Ledger.IsComplete}");
            await output.WriteLineAsync(
                $"Already Persisted    : {result.AlreadyPersisted}");

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Medication ledger import failed: {ex.Message}");
            return 1;
        }
    }


    internal static async Task<int> RunEvidenceMedicationBasisAsync(
        string databasePath,
        ServiceConnectionBasisId basisId,
        string medicationName,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (string.IsNullOrWhiteSpace(medicationName))
        {
            global::System.Console.Error.WriteLine(
                "Medication name must not be empty.");
            return 2;
        }

        try
        {
            var repository =
                new SqliteServiceConnectionRepository(databasePath);

            var existing =
                await repository.GetPrescribedMedicationNamesAsync(
                    basisId);

            var name = medicationName.Trim();

            if (!existing.Contains(
                    name,
                    StringComparer.OrdinalIgnoreCase))
            {
                await repository.AddBasisPrescribedMedicationAsync(
                    new ServiceConnectionBasisPrescribedMedication
                    {
                        ServiceConnectionBasisId = basisId,
                        MedicationName = name
                    });
            }

            await output.WriteLineAsync(
                $"Basis      : {basisId.Value}");
            await output.WriteLineAsync(
                $"Medication : {name}");
            await output.WriteLineAsync(
                $"Status     : " +
                $"{(existing.Contains(name, StringComparer.OrdinalIgnoreCase) ? "Existing" : "Persisted")}");

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Medication basis association failed: {ex.Message}");
            return 1;
        }
    }


    internal static async Task<int>
        RunEvidenceSourceClarificationReviewerCorrectionAsync(
            string databasePath,
            ClaimIssueId claimIssueId,
            SourceClarificationId sourceClarificationId,
            string reviewerMatchText,
            string reviewerReplacementText,
            TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (string.IsNullOrWhiteSpace(reviewerMatchText) ||
            string.IsNullOrWhiteSpace(reviewerReplacementText))
        {
            global::System.Console.Error.WriteLine(
                "Reviewer correction match and replacement text must not be empty.");
            return 2;
        }

        var repository =
            new SqliteSourceClarificationRepository(databasePath);

        await repository.InitializeAsync();

        var clarification =
            (await repository.GetAsync(claimIssueId))
                .SingleOrDefault(item => item.Id == sourceClarificationId);

        if (clarification is null)
        {
            global::System.Console.Error.WriteLine(
                $"Source clarification not found: {sourceClarificationId.Value}");
            return 2;
        }

        await repository.SetReviewerCorrectionAsync(
            sourceClarificationId,
            reviewerMatchText.Trim(),
            reviewerReplacementText.Trim());

        await output.WriteLineAsync(
            $"Clarification ID      : {sourceClarificationId.Value}");
        await output.WriteLineAsync(
            $"Reviewer Match        : {reviewerMatchText.Trim()}");
        await output.WriteLineAsync(
            $"Reviewer Replacement  : {reviewerReplacementText.Trim()}");

        return 0;
    }


    internal static async Task<int> RunEvidenceSourceClarificationAsync(
        string databasePath,
        ClaimIssueId claimIssueId,
        ArtifactId sourceArtifactId,
        DateOnly evidenceDate,
        int sourceStartPage,
        int sourceEndPage,
        string category,
        string recordTitle,
        string originalText,
        string clarificationText,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (sourceStartPage <= 0 || sourceEndPage < sourceStartPage)
        {
            global::System.Console.Error.WriteLine(
                "Source clarification internal page range is invalid.");
            return 2;
        }

        if (string.IsNullOrWhiteSpace(category) ||
            string.IsNullOrWhiteSpace(recordTitle) ||
            string.IsNullOrWhiteSpace(originalText) ||
            string.IsNullOrWhiteSpace(clarificationText))
        {
            global::System.Console.Error.WriteLine(
                "Source clarification fields must not be empty.");
            return 2;
        }

        var normalizedCategory = category.Trim();

        if (!SourceClarificationCategories.IsSupported(normalizedCategory))
        {
            global::System.Console.Error.WriteLine(
                $"Unsupported source clarification category: {normalizedCategory}");
            return 2;
        }

        var issues = new SqliteClaimIssueRepository(databasePath);

        if (await issues.GetClaimIssueAsync(claimIssueId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Claim issue not found: {claimIssueId.Value}");
            return 2;
        }

        var evidence = new SqliteEvidenceRepository(databasePath);
        await evidence.InitializeAsync();

        if (await evidence.GetArtifactAsync(sourceArtifactId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Source artifact not found: {sourceArtifactId.Value}");
            return 2;
        }

        var repository =
            new SqliteSourceClarificationRepository(databasePath);

        await repository.InitializeAsync();

        var normalizedRecordTitle = recordTitle.Trim();
        var normalizedOriginalText = originalText.Trim();
        var normalizedClarification = clarificationText.Trim();

        var existing =
            (await repository.GetAsync(claimIssueId))
                .FirstOrDefault(item =>
                    item.SourceArtifactId == sourceArtifactId &&
                    item.EvidenceDate == evidenceDate &&
                    item.SourceStartPage == sourceStartPage &&
                    item.SourceEndPage == sourceEndPage &&
                    string.Equals(
                        item.RecordTitle,
                        normalizedRecordTitle,
                        StringComparison.Ordinal) &&
                    string.Equals(
                        item.Category,
                        normalizedCategory,
                        StringComparison.Ordinal) &&
                    string.Equals(
                        item.OriginalText,
                        normalizedOriginalText,
                        StringComparison.Ordinal) &&
                    string.Equals(
                        item.Clarification,
                        normalizedClarification,
                        StringComparison.Ordinal));

        var alreadyPersisted = existing is not null;

        var clarification =
            existing ??
            new SourceClarification
            {
                Id =
                    new SourceClarificationId(
                        Guid.NewGuid().ToString("N")),
                ClaimIssueId = claimIssueId,
                SourceArtifactId = sourceArtifactId,
                EvidenceDate = evidenceDate,
                SourceStartPage = sourceStartPage,
                SourceEndPage = sourceEndPage,
                RecordTitle = normalizedRecordTitle,
                Category = normalizedCategory,
                OriginalText = normalizedOriginalText,
                Clarification = normalizedClarification
            };

        if (!alreadyPersisted)
            await repository.AddAsync(clarification);

        await output.WriteLineAsync(
            $"Clarification ID      : {clarification.Id.Value}");
        await output.WriteLineAsync(
            $"Category              : {clarification.Category}");
        await output.WriteLineAsync(
            $"Record Title          : {clarification.RecordTitle}");
        await output.WriteLineAsync(
            $"Evidence Date         : {clarification.EvidenceDate:yyyy-MM-dd}");
        await output.WriteLineAsync(
            $"Internal PDF Pages    : {clarification.SourceStartPage}-{clarification.SourceEndPage}");
        await output.WriteLineAsync(
            $"Already Persisted     : {alreadyPersisted}");

        return 0;
    }


    internal static async Task<int> RunEvidenceClinicalProgressionAsync(
        string databasePath,
        ClaimIssueId claimIssueId,
        ArtifactId sourceArtifactId,
        DateOnly eventDate,
        int? sourceStartPage,
        int? sourceEndPage,
        string eventType,
        string recordTitle,
        string summary,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (sourceStartPage.HasValue != sourceEndPage.HasValue ||
            (sourceStartPage is int invalidStartPage && invalidStartPage <= 0) ||
            (sourceStartPage is int startPage &&
             sourceEndPage is int endPage &&
             endPage < startPage))
        {
            global::System.Console.Error.WriteLine(
                "Clinical progression internal page range is invalid.");
            return 2;
        }

        if (string.IsNullOrWhiteSpace(eventType) ||
            string.IsNullOrWhiteSpace(recordTitle) ||
            string.IsNullOrWhiteSpace(summary))
        {
            global::System.Console.Error.WriteLine(
                "Clinical progression fields must not be empty.");
            return 2;
        }

        var normalizedEventType = eventType.Trim();

        if (!ClinicalProgressionEventTypes.IsSupported(normalizedEventType))
        {
            global::System.Console.Error.WriteLine(
                $"Unsupported clinical progression event type: {normalizedEventType}");
            return 2;
        }

        var issues = new SqliteClaimIssueRepository(databasePath);

        if (await issues.GetClaimIssueAsync(claimIssueId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Claim issue not found: {claimIssueId.Value}");
            return 2;
        }

        var evidence = new SqliteEvidenceRepository(databasePath);
        await evidence.InitializeAsync();

        if (await evidence.GetArtifactAsync(sourceArtifactId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Source artifact not found: {sourceArtifactId.Value}");
            return 2;
        }

        var repository =
            new SqliteClinicalProgressionRepository(databasePath);

        await repository.InitializeAsync();

        var normalizedRecordTitle = recordTitle.Trim();
        var normalizedSummary = summary.Trim();

        var existing =
            (await repository.GetAsync(claimIssueId))
                .FirstOrDefault(item =>
                    item.SourceArtifactId == sourceArtifactId &&
                    item.EventDate == eventDate &&
                    item.SourceStartPage == sourceStartPage &&
                    item.SourceEndPage == sourceEndPage &&
                    string.Equals(
                        item.RecordTitle,
                        normalizedRecordTitle,
                        StringComparison.Ordinal) &&
                    string.Equals(
                        item.EventType,
                        normalizedEventType,
                        StringComparison.Ordinal) &&
                    string.Equals(
                        item.Summary,
                        normalizedSummary,
                        StringComparison.Ordinal));

        var alreadyPersisted = existing is not null;

        var progressionEvent =
            existing ??
            new ClinicalProgressionEvent
            {
                Id =
                    new ClinicalProgressionEventId(
                        Guid.NewGuid().ToString("N")),
                ClaimIssueId = claimIssueId,
                SourceArtifactId = sourceArtifactId,
                EventDate = eventDate,
                SourceStartPage = sourceStartPage,
                SourceEndPage = sourceEndPage,
                RecordTitle = normalizedRecordTitle,
                EventType = normalizedEventType,
                Summary = normalizedSummary
            };

        if (!alreadyPersisted)
            await repository.AddAsync(progressionEvent);

        await output.WriteLineAsync(
            $"Progression Event ID  : {progressionEvent.Id.Value}");
        await output.WriteLineAsync(
            $"Event Type            : {progressionEvent.EventType}");
        await output.WriteLineAsync(
            $"Record Title          : {progressionEvent.RecordTitle}");
        await output.WriteLineAsync(
            $"Event Date            : {progressionEvent.EventDate:yyyy-MM-dd}");
        await output.WriteLineAsync(
            $"Internal Source Pages : " +
            (progressionEvent.SourceStartPage is int persistedStart &&
             progressionEvent.SourceEndPage is int persistedEnd
                ? $"{persistedStart}-{persistedEnd}"
                : "None"));
        await output.WriteLineAsync(
            $"Already Persisted     : {alreadyPersisted}");

        return 0;
    }


    internal static async Task<int> RunEvidenceCurrentMedicationsAsync(
        string databasePath,
        VeteranId veteranId,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        var veterans =
            new SqliteVeteranRepository(databasePath);

        var veteran =
            await veterans.GetVeteranAsync(veteranId);

        if (veteran is null)
        {
            global::System.Console.Error.WriteLine(
                $"Veteran not found: {veteranId.Value}");
            return 2;
        }

        try
        {
            var service =
                new CurrentMedicationService(
                    new SqliteMedicationRepository(databasePath));

            var records =
                await service.GetCurrentMedicationsAsync(veteranId);

            await output.WriteLineAsync(
                $"Current Medications : {records.Count}");

            foreach (var record in records)
            {
                await output.WriteLineAsync();
                await output.WriteLineAsync(
                    $"Medication  : {record.MedicationName}");
                await output.WriteLineAsync(
                    $"Strength    : {record.Strength ?? "-"}");
                await output.WriteLineAsync(
                    $"Directions  : {record.Directions ?? "-"}");
                await output.WriteLineAsync(
                    $"Indication  : {record.Indication ?? "-"}");
                await output.WriteLineAsync(
                    $"Status      : {record.Status}");
                await output.WriteLineAsync(
                    $"Record Date : {record.RecordDate:yyyy-MM-dd}");
                await output.WriteLineAsync(
                    $"Source Page : {record.SourcePage}");
            }

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Current medication resolution failed: {ex.Message}");
            return 1;
        }
    }


    internal static async Task<int> RunEvidenceMedicationClinicalContextSupersedeAsync(
        string databasePath,
        MedicationClinicalContextId supersededMedicationClinicalContextId,
        MedicationClinicalContextId replacementMedicationClinicalContextId,
        string reason,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (string.IsNullOrWhiteSpace(reason))
        {
            global::System.Console.Error.WriteLine(
                "Medication clinical context supersession reason must not be empty.");
            return 2;
        }

        try
        {
            var repository = new SqliteMedicationRepository(databasePath);
            await repository.InitializeAsync();

            await repository.SupersedeMedicationClinicalContextAsync(
                supersededMedicationClinicalContextId,
                replacementMedicationClinicalContextId,
                reason.Trim(),
                DateTimeOffset.UtcNow);

            await output.WriteLineAsync(
                $"Superseded Context   : {supersededMedicationClinicalContextId.Value}");
            await output.WriteLineAsync(
                $"Replacement Context  : {replacementMedicationClinicalContextId.Value}");
            await output.WriteLineAsync(
                $"Reason               : {reason.Trim()}");

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Medication clinical context supersession failed: {ex.Message}");
            return 1;
        }
    }


    internal static async Task<int> RunEvidenceMedicationClinicalContextAsync(
        string databasePath,
        VeteranId veteranId,
        ArtifactId sourceArtifactId,
        DateOnly eventDate,
        int sourceStartPage,
        int sourceEndPage,
        string medicationName,
        string prescriptionNumber,
        string contextType,
        string recordTitle,
        string summary,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (string.IsNullOrWhiteSpace(medicationName) ||
            string.IsNullOrWhiteSpace(prescriptionNumber) ||
            string.IsNullOrWhiteSpace(contextType) ||
            string.IsNullOrWhiteSpace(recordTitle) ||
            string.IsNullOrWhiteSpace(summary))
        {
            global::System.Console.Error.WriteLine(
                "Medication clinical context fields must not be empty.");
            return 2;
        }

        var normalizedContextType = contextType.Trim();

        if (normalizedContextType != MedicationClinicalContextTypes.ClinicalEffect &&
            normalizedContextType != MedicationClinicalContextTypes.ChangeReason &&
            normalizedContextType != MedicationClinicalContextTypes.ClinicalObservation &&
            normalizedContextType != MedicationClinicalContextTypes.TreatmentResponse)
        {
            global::System.Console.Error.WriteLine(
                $"Unsupported medication clinical context type: {normalizedContextType}");
            return 2;
        }

        var veterans = new SqliteVeteranRepository(databasePath);

        if (await veterans.GetVeteranAsync(veteranId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Veteran not found: {veteranId.Value}");
            return 2;
        }

        var evidence = new SqliteEvidenceRepository(databasePath);
        await evidence.InitializeAsync();

        if (await evidence.GetArtifactAsync(sourceArtifactId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Source artifact not found: {sourceArtifactId.Value}");
            return 2;
        }

        try
        {
            var repository = new SqliteMedicationRepository(databasePath);
            await repository.InitializeAsync();

            var normalizedMedicationName = medicationName.Trim();
            var normalizedPrescriptionNumber = prescriptionNumber.Trim();
            var normalizedRecordTitle = recordTitle.Trim();
            var normalizedSummary = summary.Trim();

            var existing =
                (await repository.GetMedicationClinicalContextsAsync(veteranId))
                    .SingleOrDefault(context =>
                        context.SourceArtifactId == sourceArtifactId &&
                        context.EventDate == eventDate &&
                        context.SourceStartPage == sourceStartPage &&
                        context.SourceEndPage == sourceEndPage &&
                        string.Equals(
                            context.MedicationName,
                            normalizedMedicationName,
                            StringComparison.Ordinal) &&
                        string.Equals(
                            context.PrescriptionNumber,
                            normalizedPrescriptionNumber,
                            StringComparison.OrdinalIgnoreCase) &&
                        string.Equals(
                            context.ContextType,
                            normalizedContextType,
                            StringComparison.Ordinal) &&
                        string.Equals(
                            context.Summary,
                            normalizedSummary,
                            StringComparison.Ordinal));

            var alreadyPersisted = existing is not null;
            var recordTitleUpdated =
                existing is not null &&
                !string.Equals(
                    existing.RecordTitle,
                    normalizedRecordTitle,
                    StringComparison.Ordinal);

            if (recordTitleUpdated)
            {
                await repository.UpdateMedicationClinicalContextRecordTitleAsync(
                    existing!.Id,
                    normalizedRecordTitle);
            }

            var clinicalContext =
                existing ??
                new MedicationClinicalContext
                {
                    Id =
                        new MedicationClinicalContextId(
                            Guid.NewGuid().ToString("N")),
                    VeteranId = veteranId,
                    SourceArtifactId = sourceArtifactId,
                    EventDate = eventDate,
                    SourceStartPage = sourceStartPage,
                    SourceEndPage = sourceEndPage,
                    MedicationName = normalizedMedicationName,
                    PrescriptionNumber = normalizedPrescriptionNumber,
                    ContextType = normalizedContextType,
                    RecordTitle = normalizedRecordTitle,
                    Summary = normalizedSummary
                };

            if (!alreadyPersisted)
            {
                await repository.AddMedicationClinicalContextAsync(
                    clinicalContext);
            }

            await output.WriteLineAsync(
                $"Medication Context ID : {clinicalContext.Id.Value}");
            await output.WriteLineAsync(
                $"Medication            : {clinicalContext.MedicationName}");
            await output.WriteLineAsync(
                $"Prescription          : {clinicalContext.PrescriptionNumber}");
            await output.WriteLineAsync(
                $"Context Type          : {clinicalContext.ContextType}");
            await output.WriteLineAsync(
                $"Event Date            : {clinicalContext.EventDate:yyyy-MM-dd}");
            await output.WriteLineAsync(
                $"Record Title          : {normalizedRecordTitle}");
            await output.WriteLineAsync(
                $"Internal PDF Pages    : {clinicalContext.SourceStartPage}-{clinicalContext.SourceEndPage}");
            await output.WriteLineAsync(
                $"Already Persisted     : {alreadyPersisted}");
            await output.WriteLineAsync(
                $"Record Title Updated  : {recordTitleUpdated}");

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Medication clinical context persistence failed: {ex.Message}");
            return 1;
        }
    }


    internal static async Task<int> RunEvidenceMedicationHistoryAsync(
        string databasePath,
        VeteranId veteranId,
        ArtifactId sourceArtifactId,
        DateOnly eventDate,
        int sourcePage,
        string eventType,
        string medicationName,
        string? strength,
        string? directions,
        string? pharmacyIndication,
        string? prescriptionNumber,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (string.IsNullOrWhiteSpace(medicationName) ||
            string.IsNullOrWhiteSpace(eventType))
        {
            global::System.Console.Error.WriteLine(
                "Medication name and history event type must not be empty.");
            return 2;
        }

        var veterans =
            new SqliteVeteranRepository(databasePath);

        if (await veterans.GetVeteranAsync(veteranId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Veteran not found: {veteranId.Value}");
            return 2;
        }

        var evidence =
            new SqliteEvidenceRepository(databasePath);

        await evidence.InitializeAsync();

        if (await evidence.GetArtifactAsync(sourceArtifactId) is null)
        {
            global::System.Console.Error.WriteLine(
                $"Source artifact not found: {sourceArtifactId.Value}");
            return 2;
        }

        try
        {
            var repository =
                new SqliteMedicationRepository(databasePath);

            await repository.InitializeAsync();

            var historyEvent =
                new MedicationHistoryEvent
                {
                    Id =
                        new MedicationHistoryEventId(
                            Guid.NewGuid().ToString("N")),
                    VeteranId = veteranId,
                    SourceArtifactId = sourceArtifactId,
                    EventDate = eventDate,
                    SourcePage = sourcePage,
                    MedicationName = medicationName.Trim(),
                    EventType = eventType.Trim(),
                    Strength = strength?.Trim(),
                    Directions = directions?.Trim(),
                    PharmacyIndication = pharmacyIndication?.Trim(),
                    PrescriptionNumber = prescriptionNumber?.Trim()
                };

            await repository.AddMedicationHistoryEventAsync(historyEvent);

            await output.WriteLineAsync(
                $"Medication History ID : {historyEvent.Id.Value}");
            await output.WriteLineAsync(
                $"Medication            : {historyEvent.MedicationName}");
            await output.WriteLineAsync(
                $"Event Type            : {historyEvent.EventType}");
            await output.WriteLineAsync(
                $"Event Date            : {historyEvent.EventDate:yyyy-MM-dd}");
            await output.WriteLineAsync(
                $"Source Page           : {historyEvent.SourcePage}");
            await output.WriteLineAsync(
                $"Source Artifact       : {historyEvent.SourceArtifactId.Value}");

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Medication history persistence failed: {ex.Message}");
            return 1;
        }
    }


    internal static async Task<int> RunEvidenceMedicationAsync(
        string databasePath,
        VeteranId veteranId,
        ArtifactId sourceArtifactId,
        DateOnly recordDate,
        int sourcePage,
        string status,
        string medicationName,
        string? strength,
        string? directions,
        string? indication,
        string? sourceDesignation,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        if (string.IsNullOrWhiteSpace(medicationName) ||
            string.IsNullOrWhiteSpace(status))
        {
            global::System.Console.Error.WriteLine(
                "Medication name and status must not be empty.");
            return 2;
        }

        var veterans =
            new SqliteVeteranRepository(databasePath);

        var veteran =
            await veterans.GetVeteranAsync(veteranId);

        if (veteran is null)
        {
            global::System.Console.Error.WriteLine(
                $"Veteran not found: {veteranId.Value}");
            return 2;
        }

        var evidence =
            new SqliteEvidenceRepository(databasePath);

        await evidence.InitializeAsync();

        var sourceArtifact =
            await evidence.GetArtifactAsync(sourceArtifactId);

        if (sourceArtifact is null)
        {
            global::System.Console.Error.WriteLine(
                $"Source artifact not found: {sourceArtifactId.Value}");
            return 2;
        }

        try
        {
            var repository =
                new SqliteMedicationRepository(databasePath);

            await repository.InitializeAsync();

            var record =
                new MedicationRecord
                {
                    Id =
                        new MedicationRecordId(
                            Guid.NewGuid().ToString("N")),
                    VeteranId = veteranId,
                    SourceArtifactId = sourceArtifactId,
                    RecordDate = recordDate,
                    SourcePage = sourcePage,
                    MedicationName = medicationName.Trim(),
                    Strength = strength?.Trim(),
                    Directions = directions?.Trim(),
                    Indication = indication?.Trim(),
                    Status = status.Trim(),
                    SourceDesignation =
                        sourceDesignation?.Trim()
                };

            await repository.AddMedicationRecordAsync(record);

            await output.WriteLineAsync(
                $"Medication Record ID : {record.Id.Value}");
            await output.WriteLineAsync(
                $"Medication           : {record.MedicationName}");
            await output.WriteLineAsync(
                $"Status               : {record.Status}");
            await output.WriteLineAsync(
                $"Record Date          : {record.RecordDate:yyyy-MM-dd}");
            await output.WriteLineAsync(
                $"Source Page          : {record.SourcePage}");
            await output.WriteLineAsync(
                $"Source Artifact      : {record.SourceArtifactId.Value}");

            return 0;
        }
        catch (Exception ex)
            when (ex is not OperationCanceledException)
        {
            global::System.Console.Error.WriteLine(
                $"Medication evidence persistence failed: {ex.Message}");
            return 1;
        }
    }


    private static async Task<int> RunClaimEvidenceAsync(
        string databasePath,
        ClaimId claimId)
    {
        var claims =
            new SqliteClaimRepository(databasePath);

        var issues =
            new SqliteClaimIssueRepository(databasePath);

        var gaps =
            new SqliteEvidenceGapRepository(databasePath);

        var guidance =
            new SqliteEvidenceRequirementGuidanceRepository(
                databasePath);

        var classifications =
            new SqliteEvidenceClassificationRepository(
                databasePath);

        var requirements =
            new RequirementEvidenceService(
                classifications,
                guidance);

        var checklist =
            new ClaimIssueEvidenceChecklistService(
                gaps,
                requirements);

        var plans =
            new EvidenceDevelopmentPlanService(
                new SqliteEvidenceDevelopmentPlanRepository(
                    databasePath));

        var issueEvidence =
            new ClaimIssueEvidenceDetailsService(
                issues,
                checklist,
                plans);

        var service =
            new ClaimEvidenceDetailsService(
                claims,
                issues,
                issueEvidence);

        var details =
            await service.GetAsync(claimId);

        if (details is null)
        {
            global::System.Console.Error.WriteLine(
                $"Claim not found: {claimId.Value}");

            return 1;
        }

        foreach (var line in
            VeteransClaimEvidenceDetailsFormatter.Format(details))
        {
            global::System.Console.WriteLine(line);
        }

        return 0;
    }


    internal static async Task<int>
        RunAddEvidenceRecognitionTermAsync(
            string databasePath,
            RequirementId requirementId,
            string term,
            string termType,
            string recognitionRole,
            string? evidenceClassification,
            string authoritySource,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentNullException.ThrowIfNull(output);

        var regulatory =
            new SqliteRegulatoryRepository(databasePath);
        await regulatory.InitializeAsync();

        var recognition =
            new SqliteEvidenceRecognitionTermRepository(databasePath);
        await recognition.InitializeAsync();

        var service =
            new EvidenceRecognitionTermService(
                regulatory,
                recognition);

        EvidenceRecognitionTerm result;

        try
        {
            result =
                await service.AddAsync(
                    requirementId,
                    term,
                    termType,
                    recognitionRole,
                    evidenceClassification,
                    authoritySource);
        }
        catch (ArgumentException ex)
        {
            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(ex.Message));
            return 1;
        }
        catch (InvalidOperationException ex)
        {
            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(ex.Message));
            return 1;
        }

        output.WriteLine($"Recognition Term ID  : {result.Id.Value}");
        output.WriteLine($"Requirement ID       : {result.RequirementId.Value}");
        output.WriteLine($"Term                 : {result.Term}");
        output.WriteLine($"Term Type            : {result.TermType}");
        output.WriteLine($"Recognition Role     : {result.RecognitionRole}");
        output.WriteLine(
            $"Evidence Classification: {result.EvidenceClassification ?? "-"}");
        output.WriteLine($"Authority Source     : {result.AuthoritySource}");

        return 0;
    }


    internal static async Task<int>
        RunAddRegulatoryRequirementAsync(
            string databasePath,
            ServiceConnectionBasisId basisId,
            RegulatoryAuthorityId authorityId,
            string authorityCitation,
            string authorityTitle,
            RegulatoryProvisionId provisionId,
            string provisionCitation,
            string version,
            string sourceUri,
            string sourceHash,
            RequirementId requirementId,
            string description,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentException.ThrowIfNullOrWhiteSpace(authorityCitation);
        ArgumentException.ThrowIfNullOrWhiteSpace(authorityTitle);
        ArgumentException.ThrowIfNullOrWhiteSpace(provisionCitation);
        ArgumentException.ThrowIfNullOrWhiteSpace(version);
        ArgumentException.ThrowIfNullOrWhiteSpace(sourceUri);
        ArgumentException.ThrowIfNullOrWhiteSpace(sourceHash);
        ArgumentException.ThrowIfNullOrWhiteSpace(description);
        ArgumentNullException.ThrowIfNull(output);

        var connections =
            new SqliteServiceConnectionRepository(databasePath);

        var basis =
            await connections.GetServiceConnectionBasisAsync(basisId);

        if (basis is null)
        {
            output.WriteLine(
                $"Service connection basis not found: {basisId.Value}");
            return 1;
        }

        var regulatory =
            new SqliteRegulatoryRepository(databasePath);

        var authority =
            await regulatory.GetRegulatoryAuthorityAsync(authorityId);

        var provision =
            await regulatory.GetRegulatoryProvisionAsync(provisionId);

        var requirement =
            await regulatory.GetRequirementAsync(requirementId);

        if (authority is not null &&
            (authority.AuthorityType != "Regulation" ||
             authority.Citation != authorityCitation ||
             authority.Title != authorityTitle))
        {
            output.WriteLine(
                "Regulatory authority ID already exists with different metadata.");
            return 1;
        }

        if (provision is not null &&
            (provision.RegulatoryAuthorityId.Value != authorityId.Value ||
             provision.ProvisionType !=
                 RegulatoryProvisionTypes.Requirement ||
             provision.Citation != provisionCitation ||
             provision.Version != version ||
             provision.SourceUri != sourceUri ||
             provision.SourceHash != sourceHash))
        {
            output.WriteLine(
                "Regulatory provision ID already exists with different metadata.");
            return 1;
        }

        if (requirement is not null &&
            (requirement.RegulatoryProvisionId.Value != provisionId.Value ||
             requirement.Description != description))
        {
            output.WriteLine(
                "Requirement ID already exists with different metadata.");
            return 1;
        }

        if (authority is null)
        {
            await regulatory.AddRegulatoryAuthorityAsync(
                new RegulatoryAuthority
                {
                    Id = authorityId,
                    AuthorityType = "Regulation",
                    Citation = authorityCitation,
                    Title = authorityTitle
                });
        }

        if (provision is null)
        {
            await regulatory.AddRegulatoryProvisionAsync(
                new RegulatoryProvision
                {
                    Id = provisionId,
                    RegulatoryAuthorityId = authorityId,
                    ProvisionType =
                        RegulatoryProvisionTypes.Requirement,
                    Citation = provisionCitation,
                    Version = version,
                    SourceUri = sourceUri,
                    SourceHash = sourceHash,
                    RetrievedUtc = DateTimeOffset.UtcNow
                });
        }

        if (requirement is null)
        {
            await regulatory.AddRequirementAsync(
                new Requirement
                {
                    Id = requirementId,
                    RegulatoryProvisionId = provisionId,
                    Description = description
                });
        }

        var requirementIds =
            await connections.GetRequirementIdsAsync(basisId);

        if (!requirementIds.Any(
                x => x.Value == requirementId.Value))
        {
            await connections.AddBasisRequirementAsync(
                new ServiceConnectionBasisRequirement
                {
                    ServiceConnectionBasisId = basisId,
                    RequirementId = requirementId
                });
        }

        output.WriteLine(
            $"Regulatory Provision : {provisionCitation}");
        output.WriteLine(
            $"Requirement          : {requirementId.Value}");
        output.WriteLine(
            $"Basis                : {basisId.Value}");
        output.WriteLine(
            "Status               : Associated");

        return 0;
    }

    internal static async Task<int>
        RunAddServiceConnectedConditionAsync(
            string databasePath,
            VeteranId veteranId,
            ServiceConnectionBasisId basisId,
            MedicalConditionId medicalConditionId,
            string conditionName,
            TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);
        ArgumentException.ThrowIfNullOrWhiteSpace(conditionName);
        ArgumentNullException.ThrowIfNull(output);

        var connections =
            new SqliteServiceConnectionRepository(databasePath);

        var basis =
            await connections.GetServiceConnectionBasisAsync(basisId);

        if (basis is null)
        {
            output.WriteLine($"Service connection basis not found: {basisId.Value}");
            return 1;
        }

        var issue =
            await new SqliteClaimIssueRepository(databasePath)
                .GetClaimIssueAsync(basis.ClaimIssueId);

        var claim =
            issue is null
                ? null
                : await new SqliteClaimRepository(databasePath)
                    .GetClaimAsync(issue.ClaimId);

        if (claim is null ||
            claim.VeteranId.Value != veteranId.Value)
        {
            output.WriteLine(
                "Service connection basis does not belong to the veteran.");
            return 1;
        }

        var conditions =
            new SqliteConditionRepository(databasePath);

        var existingCondition =
            await conditions.GetMedicalConditionAsync(
                medicalConditionId);

        if (existingCondition is null)
        {
            await conditions.AddMedicalConditionAsync(
                new MedicalCondition
                {
                    Id = medicalConditionId,
                    Name = conditionName
                });
        }
        else if (!string.Equals(
                     existingCondition.Name,
                     conditionName,
                     StringComparison.Ordinal))
        {
            output.WriteLine(
                "Medical condition ID already exists with a different name.");
            return 1;
        }

        var veteranConditionIds =
            await conditions.GetMedicalConditionIdsAsync(
                veteranId);

        if (!veteranConditionIds.Any(
                x => x.Value == medicalConditionId.Value))
        {
            await conditions.AddVeteranMedicalConditionAsync(
                new VeteranMedicalCondition
                {
                    VeteranId = veteranId,
                    MedicalConditionId = medicalConditionId
                });
        }

        var basisConditionIds =
            await connections.GetServiceConnectedConditionIdsAsync(
                basisId);

        if (!basisConditionIds.Any(
                x => x.Value == medicalConditionId.Value))
        {
            await connections.AddBasisServiceConnectedConditionAsync(
                new ServiceConnectionBasisServiceConnectedCondition
                {
                    ServiceConnectionBasisId = basisId,
                    ServiceConnectedConditionId = medicalConditionId
                });
        }

        output.WriteLine(
            $"Medical Condition : {medicalConditionId.Value}");
        output.WriteLine(
            $"Veteran           : {veteranId.Value}");
        output.WriteLine(
            $"Basis             : {basisId.Value}");
        output.WriteLine(
            $"Status            : Service connected");

        return 0;
    }


    internal static async Task<int> RunDecisionReviewAsync(
        string databasePath,
        ClaimIssueId claimIssueId,
        TextWriter output)
    {
        var service =
            CreateAdjudicationAssessmentService(databasePath);

        var assessment =
            await service.GetAsync(claimIssueId);

        if (assessment is null)
        {
            output.WriteLine(
                $"Claim issue not found: {claimIssueId.Value}");

            return 1;
        }

        output.WriteLine(
            $"Claim Issue : {claimIssueId.Value}");

        output.WriteLine(
            $"Reviews     : {assessment.DecisionReviewHistory.Count}");

        foreach (var analysis in assessment.DecisionReviewHistory)
        {
            output.WriteLine();

            output.WriteLine(
                $"Issue Decision: " +
                $"{analysis.Review.Comparison.IssueDecision.Id.Value}");

            output.WriteLine(
                $"VA Decision : " +
                $"{analysis.Review.Comparison.IssueDecision.VaDecisionId.Value}");

            if (analysis.Review.Comparison.VaDecision is not null)
            {
                output.WriteLine(
                    $"Decision Date: " +
                    $"{analysis.Review.Comparison.VaDecision.DecisionDate:yyyy-MM-dd}");
            }

            output.WriteLine(
                $"VA Outcome  : " +
                $"{analysis.Review.Comparison.IssueDecision.Outcome}");

            output.WriteLine(
                $"EMF Merits  : " +
                $"{analysis.Review.Comparison.Recommendation.MeritsOutcome}");

            output.WriteLine(
                $"Recommend   : " +
                $"{analysis.Review.Comparison.Recommendation.RecommendedOutcome ?? "None"}");

            output.WriteLine(
                $"Comparison  : " +
                $"{analysis.Review.Comparison.ComparisonOutcome}");

            output.WriteLine(
                $"Needs Review: {analysis.Review.RequiresReview}");

            output.WriteLine(
                $"Merits      : {analysis.Merits.Outcome}");

            output.WriteLine(
                $"Contributing: " +
                $"{analysis.ContributingTheoryOutcomes.Count}");

            foreach (var theory in analysis.ContributingTheoryOutcomes)
            {
                output.WriteLine(
                    $"Theory      : {theory.Theory.TheoryType}");

                output.WriteLine(
                    $"Outcome     : {theory.Outcome}");

                foreach (var basis in theory.BasisOutcomes)
                {
                    output.WriteLine(
                        $"Basis       : {basis.Basis.Id.Value}");

                    output.WriteLine(
                        $"Basis Result: {basis.Outcome}");

                    foreach (var requirement in basis.RequirementOutcomes)
                    {
                        output.WriteLine(
                            $"Requirement : {requirement.RequirementId.Value}");

                        output.WriteLine(
                            $"Req Result  : {requirement.Outcome}");

                        foreach (var finding in requirement.Findings)
                        {
                            output.WriteLine(
                                $"Finding     : {finding.Id.Value}");

                            output.WriteLine(
                                $"Find Result : {finding.Outcome}");

                            output.WriteLine(
                                $"Description : {finding.Description}");
                        }
                    }
                }
            }
        }

        return 0;
    }


    internal static async Task<int> RunDecisionHistoryAsync(
        string databasePath,
        ClaimId claimId,
        TextWriter output)
    {
        var repository =
            new SqliteVaDecisionDocumentProcessingAttemptRepository(
                databasePath);

        var service =
            new VaDecisionDocumentProcessingHistoryService(
                repository);

        var history =
            await service.GetAsync(claimId);

        foreach (var entry in history)
        {
            output.WriteLine(
                $"Artifact    : {entry.ArtifactId.Value}");

            output.WriteLine(
                $"Processed   : {entry.ProcessedAt:u}");

            output.WriteLine(
                $"Persisted   : {entry.Persisted}");

            if (entry.VaDecisionId is not null)
            {
                output.WriteLine(
                    $"VA Decision : {entry.VaDecisionId.Value}");
            }

            output.WriteLine(
                $"Matched     : {entry.MatchedIssueCount}");

            output.WriteLine(
                $"Unmatched   : {entry.UnmatchedIssueCount}");

            output.WriteLine(
                $"Ambiguous   : {entry.AmbiguousIssueCount}");

            output.WriteLine(
                $"Unresolved  : {entry.HasUnresolvedIssues}");

            output.WriteLine();
        }

        return 0;
    }


    internal static async Task<int> RunDecisionInterpretAsync(
        string databasePath,
        ArtifactId artifactId,
        Func<Task<TextSummarizationConsoleRuntime>> runtimeFactory,
        IArtifactContentStore? contentStore,
        TextWriter output)
    {
        var evidenceRepository =
            new SqliteEvidenceRepository(databasePath);

        await evidenceRepository.InitializeAsync();

        if (contentStore is null)
        {
            global::System.Console.Error.WriteLine(
                "Artifact content store is not configured.");

            return 2;
        }

        var textExtractor =
            ArtifactTextExtractionFactory.Create(
                evidenceRepository,
                contentStore);

        var text =
            await textExtractor.ExtractTextAsync(
                artifactId);

        if (string.IsNullOrWhiteSpace(text))
        {
            global::System.Console.Error.WriteLine(
                $"No text could be extracted from artifact: {artifactId.Value}");

            return 1;
        }

        var runtime =
            await runtimeFactory();

        var coordinator =
            VeteransEvidenceOrchestrationFactory
                .CreateVaDecisionDocumentInterpretationCoordinator(
                    textExtractor,
                    runtime.TextStructuredExtractionCapabilityExecutor);

        var result =
            await coordinator.InterpretAsync(
                artifactId,
                new IntelligenceExecutionContext(
                    runtime.SubjectId,
                    new IntelligenceCorrelationId(
                        $"veterans-decision-{Guid.NewGuid():N}"),
                    runtime.ClassificationId,
                    [artifactId]));

        if (!result.IntelligenceResult.Success)
        {
            global::System.Console.Error.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    result.IntelligenceResult.Message ??
                    "VA decision document interpretation failed."));

            return 1;
        }

        if (result.Interpretation is null)
        {
            global::System.Console.Error.WriteLine(
                "VA decision document interpretation produced no interpretation.");

            return 1;
        }

        output.WriteLine(
            $"Artifact    : {result.Interpretation.ArtifactId.Value}");

        output.WriteLine(
            $"Decision Date: " +
            $"{result.Interpretation.DecisionDate?.ToString("u") ?? "Not provided"}");

        output.WriteLine(
            $"Issues      : {result.Interpretation.IssueDecisions.Count}");

        output.WriteLine(
            $"Requires Review: {result.IntelligenceResult.RequiresReview}");

        foreach (var issue in result.Interpretation.IssueDecisions)
        {
            output.WriteLine();
            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    $"Issue       : {issue.IssueDescription}"));

            output.WriteLine(
                $"Outcome     : {issue.Outcome}");

            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(
                    $"Rationale   : {issue.Rationale}"));

            foreach (var finding in issue.FavorableFindings)
            {
                output.WriteLine(
                    ConsoleTextSanitizer.Sanitize(
                        $"Favorable   : {finding}"));
            }

            foreach (var finding in issue.AdverseFindings)
            {
                output.WriteLine(
                    ConsoleTextSanitizer.Sanitize(
                        $"Adverse     : {finding}"));
            }

            foreach (var regulation in issue.CitedRegulations)
            {
                output.WriteLine(
                    ConsoleTextSanitizer.Sanitize(
                        $"Regulation  : {regulation}"));
            }

            foreach (var evidence in issue.ReferencedEvidence)
            {
                output.WriteLine(
                    ConsoleTextSanitizer.Sanitize(
                        $"Evidence    : {evidence}"));
            }

            foreach (var excerpt in issue.SourceExcerpts)
            {
                output.WriteLine(
                    ConsoleTextSanitizer.Sanitize(
                        $"Source      : {excerpt.Text}"));
            }
        }

        return 0;
    }

    public static async Task<int> RunEvidenceDevelopmentPlanAsync(
        string databasePath,
        EvidenceDevelopmentPlanId planId,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        void WriteSanitized(string value) =>
            output.WriteLine(
                ConsoleTextSanitizer.Sanitize(value));

        var repository =
            new SqliteEvidenceDevelopmentPlanRepository(
                databasePath);

        await repository.InitializeAsync();

        var gaps =
            new SqliteEvidenceGapRepository(databasePath);

        var plans =
            new EvidenceDevelopmentPlanService(
                repository,
                gaps);

        var result =
            await plans.GetEvidenceDevelopmentPlanAsync(
                planId);

        if (result is null)
        {
            WriteSanitized(
                $"Evidence development plan not found: {planId.Value}");

            return 1;
        }

        WriteSanitized(
            $"Plan ID     : {result.Plan.Id.Value}");

        WriteSanitized(
            $"Claim Issue : {result.Plan.ClaimIssueId.Value}");

        WriteSanitized(
            $"Description : {result.Plan.Description}");

        WriteSanitized(
            $"Status      : {result.Status?.Status ?? "Unknown"}");

        WriteSanitized(
            $"Requirements: {result.Requirements.Count}");

        foreach (var requirement in result.Requirements)
        {
            WriteSanitized(
                $"Plan Requirement: {requirement.RequirementId.Value}");
        }

        WriteSanitized(
            $"Evidence Gaps: {result.EvidenceGaps.Count}");

        foreach (var gap in result.GapDetails)
        {
            WriteSanitized(
                $"Gap         : {gap.Id.Value}");

            WriteSanitized(
                $"Requirement : {gap.RequirementId.Value}");

            WriteSanitized(
                $"Gap Status  : {gap.Status}");

            WriteSanitized(
                $"Gap Detail  : {gap.Description}");
        }

        WriteSanitized(
            $"Artifacts   : {result.Artifacts.Count}");

        foreach (var artifact in result.Artifacts)
        {
            WriteSanitized(
                $"Plan Artifact: {artifact.ArtifactId.Value} ({artifact.Role})");
        }

        WriteSanitized(
            $"Executions  : {result.Executions.Count}");

        foreach (var execution in result.Executions)
        {
            WriteSanitized(
                $"Execution   : {execution.EvidenceGapId.Value} -> {execution.WorkflowId.Value}");
        }

        WriteSanitized(
            $"Results     : {result.Results.Count}");

        foreach (var developmentResult in result.Results)
        {
            WriteSanitized(
                $"Result      : {developmentResult.EvidenceGapId.Value}");

            WriteSanitized(
                $"Result Req  : {developmentResult.RequirementId.Value}");

            WriteSanitized(
                $"Matched     : {developmentResult.MatchingGuidanceItemCount?.ToString() ?? "Unknown"}");

            WriteSanitized(
                $"Missing     : {developmentResult.MissingGuidanceItemCount?.ToString() ?? "Unknown"}");

            WriteSanitized(
                $"Result Status: {developmentResult.ResultingGapStatus ?? "Unknown"}");
        }

        return 0;
    }


    private static async Task<int> RunExecuteAsync(
        string databasePath,
        EvidenceDevelopmentPlanId planId)
    {
        var workflowRepository =
            new SqliteWorkflowRepository(databasePath);

        await workflowRepository.InitializeAsync();

        var workflowService =
            new WorkflowService(workflowRepository);

        var workflowRunner =
            new WorkflowRunner(workflowService);

        var developmentRepository =
            new SqliteEvidenceDevelopmentPlanRepository(
                databasePath);

        await developmentRepository.InitializeAsync();

        var gapRepository =
            new SqliteEvidenceGapRepository(databasePath);

        var guidanceRepository =
            new SqliteEvidenceRequirementGuidanceRepository(
                databasePath);

        var coordinator =
            VeteransEvidenceOrchestrationFactory
                .CreateEvidenceDevelopmentWorkflowCoordinator(
                    workflowService,
                    developmentRepository,
                    workflowRunner,
                    gapRepository,
                    guidanceRepository);

        var plans =
            new EvidenceDevelopmentPlanService(
                developmentRepository,
                gapRepository);

        var service =
            new EvidenceDevelopmentPlanExecutionService(
                plans,
                coordinator);

        var result =
            await service.ExecuteAsync(planId);

        if (result is null)
        {
            global::System.Console.Error.WriteLine(
                $"Evidence development plan not found: {planId.Value}");

            return 1;
        }

        global::System.Console.WriteLine(
            $"Executions: {result.Count}");

        return 0;
    }


    internal static async Task<int> RunEvidencePackageAddAsync(
        string databasePath,
        EvidencePackageId packageId,
        ArtifactId artifactId,
        TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(output);

        await new VeteransClaimsSqliteSchema(databasePath)
            .InitializeAsync();

        var service = new EvidencePackageService(
            new SqliteEvidencePackageRepository(databasePath),
            new GuidIdGenerator());

        var result = await service.AddArtifactAsync(
            packageId,
            artifactId,
            EvidencePackageContentRoles.UnderlyingEvidence);

        output.WriteLine($"Artifact    : {result.ArtifactId.Value}");
        output.WriteLine($"Content Role: {result.ContentRole}");
        return 0;
    }


    internal static async Task<int> RunEvidencePackagePagesAsync(
        string databasePath,
        EvidencePackageId evidencePackageId,
        ArtifactId artifactId,
        string selection,
        TextWriter output)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(selection);
        ArgumentNullException.ThrowIfNull(output);

        await new VeteransClaimsSqliteSchema(databasePath)
            .InitializeAsync();

        var service =
            new EvidencePackageService(
                new SqliteEvidencePackageRepository(databasePath),
                new GuidIdGenerator());

        var reviewerPageSelection =
            string.Equals(
                selection,
                "all",
                StringComparison.OrdinalIgnoreCase)
                ? null
                : selection;

        var result =
            await service.SetReviewerPageSelectionAsync(
                evidencePackageId,
                artifactId,
                reviewerPageSelection);

        output.WriteLine(
            $"Artifact             : {result.ArtifactId.Value}");

        output.WriteLine(
            $"Reviewer source pages: " +
            $"{result.ReviewerPageSelection ?? "all"}");

        return 0;
    }


    internal static async Task<int> RunEvidencePackageAsync(
        string databasePath,
        EvidencePackageId evidencePackageId,
        TextWriter output,
        Func<IArtifactContentStore?>? contentStoreFactory = null)
    {
        ArgumentNullException.ThrowIfNull(output);

        var packageService =
            new EvidencePackageService(
                new SqliteEvidencePackageRepository(
                    databasePath),
                new GuidIdGenerator());

        var evidenceRepository =
            new SqliteEvidenceRepository(databasePath);

        await evidenceRepository.InitializeAsync();

        var classifications =
            new SqliteEvidenceClassificationRepository(
                databasePath);

        var medicalLiterature =
            new SqliteMedicalLiteratureRepository(databasePath);

        await medicalLiterature.InitializeAsync();

        contentStoreFactory ??=
            ArtifactContentStoreFactory.Create;

        var contentStore =
            contentStoreFactory();

        var service =
            contentStore is null
                ? new VeteransReviewerPackageDetailsService(
                    packageService,
                    evidenceRepository,
                    classifications,
                    medicalLiterature)
                : new VeteransReviewerPackageDetailsService(
                    packageService,
                    evidenceRepository,
                    classifications,
                    ArtifactTextExtractionFactory.Create(
                        evidenceRepository,
                        contentStore),
                    ArtifactPrintRenderingFactory.Create(
                        evidenceRepository,
                        contentStore),
                    medicalLiterature);

        var details =
            await service.GetAsync(
                evidencePackageId);

        if (details is null)
        {
            global::System.Console.Error.WriteLine(
                $"Evidence package not found: {evidencePackageId.Value}");

            return 1;
        }

        foreach (var line in
            VeteransEvidencePackageFormatter.Format(details))
        {
            output.WriteLine(line);
        }

        return 0;
    }


    private static void WriteReviewerOutputPaths(
        VeteransReviewerPackageOutputRequest outputRequest)
    {
        ArgumentNullException.ThrowIfNull(outputRequest);

        if (outputRequest.DocxPath is not null)
        {
            global::System.Console.WriteLine(
                $"Package DOCX        : {outputRequest.DocxPath}");
        }

        if (outputRequest.PdfPath is not null)
        {
            global::System.Console.WriteLine(
                $"Package PDF         : {outputRequest.PdfPath}");
        }
    }


    internal static string ResolveGeneratedDocumentPath(
        string outputPath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(outputPath);

        if (Path.IsPathRooted(outputPath))
        {
            var absolutePath = Path.GetFullPath(outputPath);
            var absoluteDirectory = Path.GetDirectoryName(absolutePath);

            if (string.IsNullOrWhiteSpace(absoluteDirectory))
                throw new InvalidOperationException(
                    "Generated document output directory could not be resolved.");

            Directory.CreateDirectory(absoluteDirectory);
            return absolutePath;
        }

        var configuredRoot =
            Environment.GetEnvironmentVariable("EMF_OUTPUT_PATH");

        var outputRoot =
            string.IsNullOrWhiteSpace(configuredRoot)
                ? Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.UserProfile),
                    "EMF_Output")
                : configuredRoot.Trim();

        if (string.IsNullOrWhiteSpace(outputRoot))
            throw new InvalidOperationException(
                "Generated document output root could not be resolved.");

        var fullRoot = Path.GetFullPath(outputRoot);
        var fullOutputPath =
            Path.GetFullPath(
                Path.Combine(fullRoot, outputPath));

        var comparison =
            OperatingSystem.IsWindows()
                ? StringComparison.OrdinalIgnoreCase
                : StringComparison.Ordinal;

        var rootWithSeparator =
            fullRoot.TrimEnd(
                Path.DirectorySeparatorChar,
                Path.AltDirectorySeparatorChar) +
            Path.DirectorySeparatorChar;

        if (!fullOutputPath.StartsWith(
                rootWithSeparator,
                comparison))
        {
            throw new InvalidOperationException(
                "Relative generated document output must remain within " +
                "the configured EMF output directory.");
        }

        var directory = Path.GetDirectoryName(fullOutputPath);

        if (string.IsNullOrWhiteSpace(directory))
            throw new InvalidOperationException(
                "Generated document output directory could not be resolved.");

        Directory.CreateDirectory(directory);
        return fullOutputPath;
    }


    internal static Task<int> RunEvidencePackageDocxAsync(
        string databasePath,
        EvidencePackageId evidencePackageId,
        string outputPath,
        IArtifactContentStore? suppliedContentStore = null,
        Func<IArtifactContentStore?>? contentStoreFactory = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(outputPath);

        var request =
            new VeteransReviewerPackageOutputRequest(
                VeteransReviewerPackageOutputFormat.Docx,
                Path.GetFullPath(outputPath),
                null);

        return RunEvidencePackageDocumentAsync(
            databasePath,
            evidencePackageId,
            request,
            suppliedContentStore,
            contentStoreFactory);
    }

    internal static async Task<int> RunEvidencePackageDocumentAsync(
        string databasePath,
        EvidencePackageId evidencePackageId,
        VeteransReviewerPackageOutputRequest outputRequest,
        IArtifactContentStore? suppliedContentStore = null,
        Func<IArtifactContentStore?>? contentStoreFactory = null,
        IVeteransReviewerPackageDocumentConverter? suppliedConverter = null,
        IVeteransReviewerRegulatoryTextProvider? suppliedRegulatoryTextProvider = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(outputRequest);

        var fullDatabasePath =
            Path.GetFullPath(databasePath);

        var pathComparison =
            OperatingSystem.IsWindows()
                ? StringComparison.OrdinalIgnoreCase
                : StringComparison.Ordinal;

        foreach (var outputPath in outputRequest.OutputPaths)
        {
            var fullOutputPath = Path.GetFullPath(outputPath);

            if (string.Equals(
                fullDatabasePath,
                fullOutputPath,
                pathComparison))
            {
                global::System.Console.Error.WriteLine(
                    "Reviewer package output cannot overwrite " +
                    "the Veterans Claims database.");

                return 2;
            }
        }

        var packageService =
            new EvidencePackageService(
                new SqliteEvidencePackageRepository(
                    fullDatabasePath),
                new GuidIdGenerator());

        var evidenceRepository =
            new SqliteEvidenceRepository(fullDatabasePath);

        await evidenceRepository.InitializeAsync();

        var classifications =
            new SqliteEvidenceClassificationRepository(
                fullDatabasePath);

        var medicalLiterature =
            new SqliteMedicalLiteratureRepository(fullDatabasePath);

        await medicalLiterature.InitializeAsync();

        contentStoreFactory ??=
            ArtifactContentStoreFactory.Create;

        var contentStore =
            suppliedContentStore ??
            contentStoreFactory();

        var adjudicationDetailsService =
            CreateAdjudicationDetailsService(fullDatabasePath);

        var detailsService =
            contentStore is null
                ? new VeteransReviewerPackageDetailsService(
                    packageService,
                    evidenceRepository,
                    classifications,
                    medicalLiterature,
                    adjudicationDetailsService)
                : new VeteransReviewerPackageDetailsService(
                    packageService,
                    evidenceRepository,
                    classifications,
                    ArtifactTextExtractionFactory.Create(
                        evidenceRepository,
                        contentStore),
                    ArtifactPrintRenderingFactory.Create(
                        evidenceRepository,
                        contentStore),
                    medicalLiterature,
                    adjudicationDetailsService);

        var medicationRepository =
            new SqliteMedicationRepository(fullDatabasePath);

        var claimIssueRepository =
            new SqliteClaimIssueRepository(fullDatabasePath);

        var claimRepository =
            new SqliteClaimRepository(fullDatabasePath);

        var serviceConnectionRepository =
            new SqliteServiceConnectionRepository(fullDatabasePath);

        var sourceClarificationRepository =
            new SqliteSourceClarificationRepository(fullDatabasePath);

        await sourceClarificationRepository.InitializeAsync();

        var clinicalProgressionRepository =
            new SqliteClinicalProgressionRepository(fullDatabasePath);

        await clinicalProgressionRepository.InitializeAsync();

        var medicationSourceEvidence = contentStore is null ? null :
            new VeteransMedicationSourceEvidenceService(
                evidenceRepository,
                contentStore,
                new PdfArtifactTextExtractionProvider(contentStore));

        var assemblyService =
            new VeteransReviewerPackageAssemblyService(
                detailsService,
                new VeteransReviewerPackageCurrentMedicationService(
                    claimIssueRepository,
                    claimRepository,
                    new ReconciledCurrentMedicationLedgerService(
                        new CurrentMedicationLedgerService(
                            medicationRepository),
                        medicationRepository),
                    medicationSourceEvidence),
                new VeteransReviewerPackageMedicationProgressionService(
                    claimIssueRepository,
                    claimRepository,
                    serviceConnectionRepository,
                    medicationRepository,
                    medicationSourceEvidence),
                new VeteransReviewerPackageMedicationClinicalContextService(
                    claimIssueRepository,
                    claimRepository,
                    medicationRepository,
                    evidenceRepository),
                new VeteransReviewerPackageSourceClarificationService(
                    sourceClarificationRepository),
                new VeteransReviewerPackageClinicalProgressionService(
                    clinicalProgressionRepository),
                new VeteransReviewerMedicalOpinionRequestService(
                    serviceConnectionRepository,
                    new SqliteConditionRepository(fullDatabasePath),
                    new SqliteRegulatoryRepository(fullDatabasePath)));

        var details =
            await assemblyService.AssembleAsync(
                evidencePackageId,
                Environment.GetEnvironmentVariable(
                    "EMF_PACKAGE_PREPARED_BY"),
                Environment.GetEnvironmentVariable(
                    "EMF_VETERAN_DISPLAY_NAME"));

        if (details is null)
            return 1;

        if (contentStore is null &&
            details.PackageDetails.Artifacts.Any(
                artifact =>
                    string.Equals(
                        artifact.ContentRole,
                        EvidencePackageContentRoles.UnderlyingEvidence,
                        StringComparison.Ordinal)))
        {
            global::System.Console.Error.WriteLine(
                "Reviewer package contains underlying evidence, " +
                "but preserved artifact content is unavailable.");

            return 2;
        }

        IVeteransReviewerPackageDocumentConverter? converter =
            suppliedConverter;

        if (outputRequest.RequiresPdf && converter is null)
        {
            converter =
                new LibreOfficeVeteransReviewerPackageDocumentConverter();
        }

        VeteransReviewerPackageDocumentOutput content;

        try
        {
            content =
                await new VeteransReviewerPackageDocumentOutputService(
                        converter,
                        suppliedRegulatoryTextProvider ??
                            new EcfrVeteransReviewerRegulatoryTextProvider())
                    .RenderAsync(
                        details,
                        outputRequest.Format,
                        cancellationToken);
        }
        catch (Exception ex) when (ex is
            InvalidOperationException or
            InvalidDataException or
            HttpRequestException or
            TimeoutException)
        {
            global::System.Console.Error.WriteLine(
                ConsoleTextSanitizer.Sanitize(ex.Message));
            return 2;
        }

        if (outputRequest.DocxPath is not null)
        {
            if (content.Docx is null)
                throw new InvalidOperationException(
                    "DOCX reviewer-package output was requested but not rendered.");

            await WriteFileAtomicallyAsync(
                outputRequest.DocxPath,
                content.Docx);
        }

        if (outputRequest.PdfPath is not null)
        {
            if (content.Pdf is null)
                throw new InvalidOperationException(
                    "PDF reviewer-package output was requested but not rendered.");

            await WriteFileAtomicallyAsync(
                outputRequest.PdfPath,
                content.Pdf);
        }

        return 0;
    }

    private static async Task WriteFileAtomicallyAsync(
        string outputPath,
        byte[] content)
    {
        var directory =
            Path.GetDirectoryName(outputPath) ??
            throw new InvalidOperationException(
                "Reviewer package output directory could not be resolved.");

        var temporaryPath =
            Path.Combine(
                directory,
                $".{Path.GetFileName(outputPath)}.{Guid.NewGuid():N}.tmp");

        try
        {
            var options =
                new FileStreamOptions
                {
                    Mode = FileMode.CreateNew,
                    Access = FileAccess.Write,
                    Share = FileShare.None,
                    BufferSize = 4096,
                    Options =
                        FileOptions.Asynchronous |
                        FileOptions.WriteThrough
                };

            if (!OperatingSystem.IsWindows())
            {
                options.UnixCreateMode =
                    UnixFileMode.UserRead |
                    UnixFileMode.UserWrite;
            }

            await using (var stream =
                new FileStream(
                    temporaryPath,
                    options))
            {
                await stream.WriteAsync(content);
                await stream.FlushAsync();
            }

            File.Move(
                temporaryPath,
                outputPath,
                true);
        }
        finally
        {
            if (File.Exists(temporaryPath))
                File.Delete(temporaryPath);
        }
    }


    private static async Task<int> RunClassifyAsync(
        string databasePath,
        ClaimIssueId claimIssueId,
        ArtifactId artifactId,
        string classification)
    {
        var claimIssue =
            await new SqliteClaimIssueRepository(databasePath)
                .GetClaimIssueAsync(claimIssueId);

        if (claimIssue is null)
        {
            global::System.Console.Error.WriteLine(
                $"Claim issue not found: {claimIssueId.Value}");

            return 1;
        }

        var evidenceRepository =
            new SqliteEvidenceRepository(databasePath);

        await evidenceRepository.InitializeAsync();

        var artifact =
            await evidenceRepository.GetArtifactAsync(artifactId);

        if (artifact is null)
        {
            global::System.Console.Error.WriteLine(
                $"Artifact not found: {artifactId.Value}");

            return 1;
        }

        var classifications =
            new SqliteEvidenceClassificationRepository(databasePath);

        var service =
            new EvidenceClassificationService(
                classifications,
                new GuidIdGenerator());

        var result =
            await service.ClassifyAsync(
                artifactId,
                classification,
                claimIssueId);

        global::System.Console.WriteLine(
            $"Classification ID : {result.Id.Value}");
        global::System.Console.WriteLine(
            $"Artifact ID       : {result.ArtifactId.Value}");
        global::System.Console.WriteLine(
            $"Claim Issue       : {result.ClaimIssueId?.Value ?? "<none>"}");
        global::System.Console.WriteLine(
            $"Classification    : {result.Classification}");

        return 0;
    }


    private static async Task<int> RunGuidanceAsync(
        string databasePath,
        RequirementId requirementId,
        string evidenceClassification,
        string guidanceRole,
        string description)
    {
        var guidance =
            new SqliteEvidenceRequirementGuidanceRepository(
                databasePath);

        await guidance.InitializeAsync();

        var service =
            new RegulatoryEvidenceGuidanceService(
                new SqliteRegulatoryRepository(databasePath),
                guidance,
                new GuidIdGenerator());

        try
        {
            var result =
                await service.AddEvidenceGuidanceAsync(
                    requirementId,
                    evidenceClassification,
                    guidanceRole,
                    description);

            global::System.Console.WriteLine(
                $"Guidance ID     : {result.Id.Value}");
            global::System.Console.WriteLine(
                $"Requirement     : {result.RequirementId.Value}");
            global::System.Console.WriteLine(
                $"Classification  : {result.EvidenceClassification}");
            global::System.Console.WriteLine(
                $"Guidance Role   : {result.GuidanceRole}");
            global::System.Console.WriteLine(
                $"Description     : {result.Description}");

            return 0;
        }
        catch (ArgumentException ex)
        {
            global::System.Console.Error.WriteLine(ex.Message);
            return 1;
        }
        catch (InvalidOperationException ex)
        {
            global::System.Console.Error.WriteLine(ex.Message);
            return 1;
        }
    }


    private static async Task<int> RunPrepareAsync(
        string databasePath,
        ClaimIssueId claimIssueId,
        EvidenceDevelopmentPlanId planId)
    {
        var serviceConnections =
            new SqliteServiceConnectionRepository(databasePath);

        var gapsRepository =
            new SqliteEvidenceGapRepository(databasePath);

        var guidance =
            new SqliteEvidenceRequirementGuidanceRepository(
                databasePath);

        var classifications =
            new SqliteEvidenceClassificationRepository(
                databasePath);

        var requirementEvidence =
            new RequirementEvidenceService(
                classifications,
                guidance);

        var gapService =
            new EvidenceGapService(
                gapsRepository,
                requirementEvidence,
                new GuidIdGenerator());

        var serviceConnectionGaps =
            new ServiceConnectionEvidenceGapService(
                serviceConnections,
                gapService);

        var planRepository =
            new SqliteEvidenceDevelopmentPlanRepository(
                databasePath);

        await planRepository.InitializeAsync();

        var planService =
            new EvidenceDevelopmentPlanService(
                planRepository,
                gapsRepository);

        var preparation =
            new EvidenceDevelopmentPreparationService(
                serviceConnectionGaps,
                planService);

        var result =
            await preparation.PrepareAsync(
                planId,
                claimIssueId,
                "Develop missing service-connection evidence.");

        if (result is null)
        {
            global::System.Console.WriteLine(
                "No evidence development required.");

            return 0;
        }

        global::System.Console.WriteLine(
            $"Plan ID     : {result.Plan.Id.Value}");

        global::System.Console.WriteLine(
            $"Claim Issue : {result.Plan.ClaimIssueId.Value}");

        global::System.Console.WriteLine(
            $"Evidence Gaps: {result.EvidenceGaps.Count}");

        return 0;
    }


    private static async Task<int> RunChecklistAsync(
        string databasePath,
        ClaimIssueId claimIssueId)
    {
        var gaps =
            new SqliteEvidenceGapRepository(databasePath);

        var guidance =
            new SqliteEvidenceRequirementGuidanceRepository(
                databasePath);

        var classifications =
            new SqliteEvidenceClassificationRepository(
                databasePath);

        var requirements =
            new RequirementEvidenceService(
                classifications,
                guidance);

        var service =
            new ClaimIssueEvidenceChecklistService(
                gaps,
                requirements);

        var checklist =
            await service.CreateChecklistAsync(claimIssueId);

        foreach (var line in
            VeteransEvidenceChecklistFormatter.Format(checklist))
        {
            global::System.Console.WriteLine(line);
        }

        return 0;
    }

    private static int RunPapAnalysis(string sourcePath)
    {
        var content = File.ReadAllBytes(sourcePath);

        var sessions =
            Path.GetExtension(sourcePath).ToLowerInvariant() switch
            {
                ".json" =>
                    new SnorePapTherapyJsonParser().Parse(content),
                ".csv" =>
                    new OscarPapTherapyCsvParser().Parse(content),
                _ => throw new InvalidDataException(
                    "PAP source must be SNORE JSON or OSCAR CSV.")
            };

        var analysis =
            new PapTherapyAnalysisService().Analyze(sessions);

        global::System.Console.WriteLine("PAP Therapy Analysis");
        global::System.Console.WriteLine(
            $"Coverage       : {analysis.StartDate} through {analysis.EndDate}");
        global::System.Console.WriteLine(
            $"Calendar days  : {analysis.CalendarDayCount}");
        global::System.Console.WriteLine(
            $"Sessions       : {analysis.SessionCount}");
        global::System.Console.WriteLine(
            $"Zero duration  : {analysis.ZeroDurationSessionCount}");
        global::System.Console.WriteLine(
            $"Treatment days : {analysis.TreatmentDayCount}");
        global::System.Console.WriteLine(
            $"Total hours    : {analysis.TotalHoursUsed:F2}");
        global::System.Console.WriteLine(
            $"Avg hours/day  : {analysis.AverageHoursPerTreatmentDay:F2}");
        global::System.Console.WriteLine(
            $"Days >= 4 hrs  : {analysis.DaysAtLeastFourHours}");
        global::System.Console.WriteLine(
            $"Days >= 6 hrs  : {analysis.DaysAtLeastSixHours}");
        global::System.Console.WriteLine(
            $"Weighted AHI   : {analysis.WeightedAhi:F2}");
        global::System.Console.WriteLine(
            $"Median AHI     : {analysis.MedianDailyAhi:F2}");
        global::System.Console.WriteLine(
            $"Maximum AHI    : {analysis.MaximumDailyAhi:F2}");
        global::System.Console.WriteLine(
            $"Machines       : {string.Join(", ", analysis.Machines)}");

        return 0;
    }

    private static void ShowUsage()
    {
        global::System.Console.WriteLine(
            "Usage: emf veterans condition service-connected " +
            "<database-path> <veteran-id> <basis-id> " +
            "<medical-condition-id> <condition-name>");

        global::System.Console.WriteLine(
            "       emf veterans regulatory requirement " +
            "<database-path> <basis-id> <authority-id> " +
            "<authority-citation> <authority-title> <provision-id> " +
            "<provision-citation> <version> <source-uri> <source-hash> " +
            "<requirement-id> <description>");

        global::System.Console.WriteLine(
            "       emf veterans pap analyze <source-path>");

        global::System.Console.WriteLine(
            "       emf veterans evidence develop " +
            "[--summarize [--promote]] " +
            "<database-path> <plan-id> <evidence-gap-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence ingest " +
            "<database-path> <source-path>");

        global::System.Console.WriteLine(
            "       emf veterans evidence supersede " +
            "<database-path> <replacement-artifact-id> " +
            "<superseded-artifact-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence checklist " +
            "<database-path> <claim-issue-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence bounded list " +
            "<database-path> <claim-issue-id> <basis-id> " +
            "<requirement-id> <source-artifact-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence bounded interpret " +
            "<database-path> <claim-issue-id> <basis-id> " +
            "<requirement-id> <source-artifact-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence reviewer " +
            "<database-path> <claim-issue-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence reviewer " +
            "<database-path> <claim-issue-id> <output.docx|output.pdf>");

        global::System.Console.WriteLine(
            "       emf veterans evidence reviewer " +
            "<database-path> <claim-issue-id> --format <docx|pdf|both> " +
            "<output-path>");

        global::System.Console.WriteLine(
            "       emf veterans evidence reviewer " +
            "<database-path> <claim-issue-id> --basis <basis-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence reviewer " +
            "<database-path> <claim-issue-id> --basis <basis-id> " +
            "[--format <docx|pdf|both>] <output-path>");

        global::System.Console.WriteLine(
            "       emf veterans evidence classify " +
            "<database-path> <claim-issue-id> <artifact-id> <classification>");

        global::System.Console.WriteLine(
            "       emf veterans evidence literature classify " +
            "[--promote] <database-path> <literature-id> <artifact-id> " +
            "<requirement-id> [<requirement-id> ...] [--basis <basis-id>]");

        global::System.Console.WriteLine(
            "       emf veterans evidence literature review --supersede " +
            "<correlation-id> <database-path> <literature-id> <artifact-id> " +
            "<requirement-id> <role> <description> <excerpt-ordinal> " +
            "[<excerpt-ordinal> ...] [--basis <basis-id>]");

        global::System.Console.WriteLine(
            "       emf veterans evidence literature artifact " +
            "<database-path> <literature-id> <artifact-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence guidance " +
            "<database-path> <requirement-id> <classification> " +
            "<role> <description>");

        global::System.Console.WriteLine(
            "       emf veterans evidence recognition add " +
            "<database-path> <requirement-id> <term> " +
            "<Keyword|Phrase|Acronym|Synonym> " +
            "<recognition-role> <evidence-classification|-> " +
            "<authority-source>");

        global::System.Console.WriteLine(
            "       emf veterans evidence literature source " +
            "<database-path> <source-json-path>");

        global::System.Console.WriteLine(
            "       emf veterans evidence literature link " +
            "<database-path> <requirement-id> <source-id> " +
            "<role> <description> [--basis <basis-id>]");

        global::System.Console.WriteLine(
            "       emf veterans evidence medication ledger current " +
            "<database-path> <veteran-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence medication ledger import " +
            "<database-path> <veteran-id> <source-artifact-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence medication indication " +
            "<database-path> <veteran-id> <yyyy-MM-dd> <medication-name> <indication> <attributed-source>");

        global::System.Console.WriteLine(
            "       emf veterans evidence medication reconcile " +
            "<database-path> <veteran-id> <ledger-entry-id> " +
            "<yyyy-MM-dd> <CurrentlyUsed|NotCurrentlyUsed> " +
            "<source> [note]");

        global::System.Console.WriteLine(
            "       emf veterans evidence clarification " +
            "<database-path> <claim-issue-id> <source-artifact-id> " +
            "<yyyy-MM-dd> <internal-start-page> <internal-end-page> " +
            "<category> <record-title> <original-text> <clarification>");

        global::System.Console.WriteLine(
            "       emf veterans evidence clarification reviewer-correction " +
            "<database-path> <claim-issue-id> <clarification-id> " +
            "<match-text> <replacement-text>");

        global::System.Console.WriteLine(
            "       emf veterans evidence clinical progression " +
            "<database-path> <claim-issue-id> <source-artifact-id> " +
            "<yyyy-MM-dd> <internal-start-page|-> <internal-end-page|-> " +
            "<event-type> <record-title> <summary>");

        global::System.Console.WriteLine(
            "       emf veterans evidence medication basis " +
            "<database-path> <basis-id> <medication-name>");

        global::System.Console.WriteLine(
            "       emf veterans evidence medication context " +
            "<database-path> <veteran-id> <source-artifact-id> " +
            "<yyyy-MM-dd> <internal-start-page> <internal-end-page> " +
            "<medication-name> <prescription-number> <context-type> " +
            "<record-title> <summary>");
        global::System.Console.WriteLine(
            "       emf veterans evidence medication context supersede " +
            "<database-path> <superseded-context-id> " +
            "<replacement-context-id> <reason>");

        global::System.Console.WriteLine(
            "       emf veterans evidence medication current " +
            "<database-path> <veteran-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence medication " +
            "<database-path> <veteran-id> <source-artifact-id> " +
            "<yyyy-MM-dd> <page> <status> <medication-name> " +
            "<strength|-> <directions|-> <indication|-> " +
            "[source-designation|-]");

        global::System.Console.WriteLine(
            "       emf veterans evidence package add " +
            "<database-path> <package-id> <artifact-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence package pages " +
            "<database-path> <package-id> <artifact-id> <selection|all>");

        global::System.Console.WriteLine(
            "       emf veterans evidence package " +
            "<database-path> <package-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence package " +
            "<database-path> <package-id> <output.docx|output.pdf>");

        global::System.Console.WriteLine(
            "       emf veterans evidence package " +
            "<database-path> <package-id> --format <docx|pdf|both> " +
            "<output-path>");

        global::System.Console.WriteLine(
            "       emf veterans evidence prepare " +
            "<database-path> <claim-issue-id> <plan-id>");

        global::System.Console.WriteLine(
            "       emf veterans evidence execute " +
            "<database-path> <plan-id>");


        global::System.Console.WriteLine(
            "       emf veterans decision interpret " +
            "<database-path> <artifact-id>");

        global::System.Console.WriteLine(
            "       emf veterans decision history " +
            "<database-path> <claim-id>");

        global::System.Console.WriteLine(
            "       emf veterans decision review " +
            "<database-path> <claim-issue-id>");

        global::System.Console.WriteLine(
            "       emf veterans adjudication assess " +
            "<database-path> <claim-issue-id>");

        global::System.Console.WriteLine(
            "       emf veterans adjudication claim " +
            "<database-path> <claim-id>");
    }
}
