# Test results

Focused tests were run before the broader regression set.

```sh
dotnet test tests/EMF.Tests/EMF.Tests.csproj --filter 'FullyQualifiedName~VeteransReviewerPackageIntelligenceServiceTests|FullyQualifiedName~VeteransReviewerPackageClinicalProgressionTests|FullyQualifiedName~VeteransReviewerPackageDetailsServiceTests|FullyQualifiedName~VeteransEvidenceRecognitionAddConsoleTests' --no-restore --verbosity quiet
dotnet test tests/EMF.Tests/EMF.Tests.csproj --filter 'FullyQualifiedName~Veterans' --no-build --no-restore --verbosity quiet
git diff --check
```

- Focused: 51 passed, 0 failed, 0 skipped (2 seconds reported test duration).
- Broader Veterans set: 873 passed, 0 failed, 10 skipped, 883 total
  (7 minutes 42 seconds reported test duration).
- Whitespace validation: passed.
- Combined patch: application checked and applied using an isolated temporary
  index initialized from the base commit; all nine files reconstructed exactly.
- ZIP: CRC/integrity checked after writing.

The quiet broader log does not enumerate skipped tests; no claim is made that
those ten skipped tests executed. Captured logs are included unchanged.
No Azure OpenAI or paid reviewer run was invoked.
