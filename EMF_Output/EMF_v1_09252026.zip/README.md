# EMF reviewer progression change — September 25, 2026

This bundle contains the complete uncommitted working-tree change relative to
`d28af39ed953561c891ee7a34e8860355184a636`, including work already present before the review and the previously
untracked recognition-command regression test. It is a change bundle, not a full
repository backup or generated reviewer package.

## Contents

- `patches/EMF_v1_09252026.patch`: one combined Git patch for all nine changed files.
- `files/`: complete final versions of those source and test files.
- `CHANGE_EXPLANATION.md`: findings, implementation, and design implications.
- `TEST_RESULTS.md` and `logs/`: validation commands and captured results.
- `DIFF_STAT.txt`: full patch statistics, including the new test file.
- `manifest.json`: base commit and SHA-256 checksums of all other bundle entries.

## Applying the patch

Use a clean checkout at the base commit above. From the repository root:

```sh
git apply --check /path/to/patches/EMF_v1_09252026.patch
git apply /path/to/patches/EMF_v1_09252026.patch
```

The current development checkout already contains these changes; do not apply the
patch there again. Patch application was validated against the base commit using
an isolated temporary Git index, and every reconstructed file was compared with
its current working-tree contents. No commit was created.
