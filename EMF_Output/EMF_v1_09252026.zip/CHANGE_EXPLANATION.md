# Findings and changes

The initial working tree contained a pending recognition-term CLI command,
recognition/progression reuse-key changes, an additional progression-aware
summarization interface, an AI-summary progression appendix, and tests.

The package already had a deterministic clinical progression service and DOCX
renderer. Appending a second structured progression section to the AI summary
would introduce competing selection and presentation mechanisms. The revision
removes that pending appendix and overload, keeping the existing renderer as the
single deterministic progression presentation mechanism. The AI prompt still
asks for material supporting, contradictory, and contextual evidence without
making medical, legal, or adjudicative conclusions.

Clinical progression now requires the event's SourceArtifactId to be a stored
UnderlyingEvidence member of the reviewer package with matching artifact content.
A derived record alone no longer authorizes an event attached to an absent parent
artifact. Stable summary tie-breakers make ordering deterministic when date,
source locator, and event type are equal.

Loading an existing package previously could add currently reviewed medical
literature from claim data. That expansion was removed: current reviews can
classify existing package members, but cannot add later claim-only artifacts.
New packages still obtain their evidence through the existing source-selection
and package-creation flow.

The console loads recognition terms and package-scoped progression before
checking reuse. Recognition requirements match the scoped details used by the
projection service. The reuse strategy version is advanced. Canonically sorted
JSON values avoid free-text delimiter collisions and repository-order dependence.
Recognition term IDs and progression event IDs are excluded. Recognition values
and package-scoped event source, date, page range, title, type, and summary are
included. Out-of-package and other-claim progression events do not affect the
key. Duplicate rows remain significant because they can render twice.

The existing recognition-add command is retained and uses the existing
EvidenceRecognitionTermService rather than adding another persistence mechanism.

Reviewer-facing diagnosis text remains unchanged, including Bilateral pes planus.
The deterministic progression section explicitly states that factual observations
are not independent medical nexus opinions. It does not infer causation.

## Regression coverage

- Recognition-term addition invalidates reuse; term IDs and order do not.
- Progression content and page changes invalidate reuse; event IDs and ordering
  of tied events do not. Removing an in-package event changes the key.
- Outside-package and other-claim progression does not change the key.
- Later claim-only artifact content cannot introduce a clinical progression event
  into an existing package or its rendered DOCX.
- An absent parent source is excluded even when a derived record is packaged.
- Newly reviewed literature cannot expand stored package membership.
- Rendered output preserves Bilateral pes planus, excludes flat-feet shorthand,
  excludes later claim-only facts, and retains factual-versus-nexus wording.
- Recognition-add CLI remains idempotent and rejects a missing database.

## Design implications and limits

Strict parent-source membership is an intentional behavior change. Existing
parent-linked events will be omitted when only their derived record is packaged;
source attribution/package membership must be reviewed if those events are needed.

The deterministic guarantee applies to the existing structured reviewer section,
not to the wording of the AI-generated narrative. No second narrative appendix is
introduced.

This is not an immutable snapshot redesign of every enrichment service. Existing
metadata/review enrichment and progression data for already included sources are
still loaded from current repositories. Reuse invalidation detects the covered
input changes when requesting a package; this patch does not snapshot all other
claim-derived enrichment, such as medication data, into historical packages.

No Azure OpenAI call, paid reviewer run, or commit was performed.
